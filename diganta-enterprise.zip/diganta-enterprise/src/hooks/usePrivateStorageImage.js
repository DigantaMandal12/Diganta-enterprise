import { useEffect, useState } from 'react';
import { getPrivateRepairPhotoObjectUrl } from '../services/storageService.js';

/**
 * Custom hook that loads a private repair photograph via authenticated Storage bytes/blob
 * and manages revoking its temporary browser Object URL when unmounted or changed.
 */
export function usePrivateStorageImage(storagePath) {
  const [objectUrl, setObjectUrl] = useState(null);
  const [loading, setLoading] = useState(Boolean(storagePath));
  const [error, setError] = useState(null);

  useEffect(() => {
    let active = true;
    let revokeFn = null;

    if (!storagePath) {
      setObjectUrl(null);
      setLoading(false);
      setError(null);
      return () => {};
    }

    setLoading(true);
    setError(null);

    getPrivateRepairPhotoObjectUrl(storagePath)
      .then(({ objectUrl: url, revoke }) => {
        if (!active) {
          revoke();
          return;
        }
        revokeFn = revoke;
        setObjectUrl(url);
        setLoading(false);
      })
      .catch((err) => {
        if (!active) return;
        setError(err?.message || 'Could not load private repair photo.');
        setLoading(false);
      });

    return () => {
      active = false;
      if (typeof revokeFn === 'function') {
        revokeFn();
      }
    };
  }, [storagePath]);

  return { objectUrl, loading, error };
}
