import { useEffect } from 'react';
import { BUSINESS_INFO } from '../config/businessConfig.js';

/**
 * Sets the document title and optional meta description for SEO and usability.
 */
export function useDocumentTitle(pageTitle, metaDescription = '') {
  useEffect(() => {
    const baseTitle = `${BUSINESS_INFO.name} — ${BUSINESS_INFO.tagline}`;
    document.title = pageTitle ? `${pageTitle} | ${baseTitle}` : baseTitle;

    if (metaDescription) {
      const descTag = document.querySelector('meta[name="description"]');
      if (descTag) {
        descTag.setAttribute('content', metaDescription);
      }
    }
  }, [pageTitle, metaDescription]);
}
