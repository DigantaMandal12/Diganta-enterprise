/**
 * Input validation and phone normalisation utilities for public forms and admin forms.
 */

import { isValidISODateString } from './dates.js';
import { rupeesToPaise } from './currency.js';
import { BUSINESS_INFO } from '../config/businessConfig.js';

/**
 * Normalises an Indian or international phone number while preserving readability.
 * Accepts spaces, hyphens, parentheses, and optional +91 or 0 prefix.
 * Returns { isValid, normalized, digitsOnly, error }
 */
export function validateAndNormalizePhone(rawPhone) {
  if (!rawPhone || typeof rawPhone !== 'string') {
    return {
      isValid: false,
      normalized: '',
      digitsOnly: '',
      error: 'Enter a valid phone number.'
    };
  }

  const trimmed = rawPhone.trim();
  const digitsOnly = trimmed.replace(/\D/g, '');

  // Handle standard 10-digit Indian mobile/landline, 11-digit with leading 0, or 12-digit with 91
  let tenDigitCore = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('0')) {
    tenDigitCore = digitsOnly.slice(1);
  } else if (digitsOnly.length === 12 && digitsOnly.startsWith('91')) {
    tenDigitCore = digitsOnly.slice(2);
  }

  if (tenDigitCore.length === 10 && /^[6-9]\d{9}$/.test(tenDigitCore)) {
    return {
      isValid: true,
      normalized: `+91 ${tenDigitCore.slice(0, 5)} ${tenDigitCore.slice(5)}`,
      digitsOnly: `91${tenDigitCore}`,
      error: null
    };
  }

  // Also allow valid 10-to-15 digit numbers (e.g. STD landline)
  if (digitsOnly.length >= 10 && digitsOnly.length <= 15) {
    return {
      isValid: true,
      normalized: trimmed.replace(/\s+/g, ' '),
      digitsOnly,
      error: null
    };
  }

  return {
    isValid: false,
    normalized: trimmed,
    digitsOnly,
    error: 'Enter a valid 10-digit Indian phone number (e.g. +91 93302 50245 or 9330250245).'
  };
}

/**
 * Validates customer product enquiry inputs before saving to Firestore.
 */
export function validateProductEnquiryForm(formData, product) {
  const errors = {};

  if (!product || !product.id || !product.isPublished) {
    errors.product = 'The selected product is unavailable or no longer published.';
  }

  const customerName = (formData.customerName || '').trim();
  if (customerName.length < 2 || customerName.length > 120) {
    errors.customerName = 'Enter your name (between 2 and 120 characters).';
  }

  const phoneResult = validateAndNormalizePhone(formData.phone);
  if (!phoneResult.isValid) {
    errors.phone = phoneResult.error;
  }

  const quantity = Number(formData.quantity);
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 1000) {
    errors.quantity = 'Enter a whole-number quantity between 1 and 1,000.';
  }

  const allowedContactMethods = ['WhatsApp', 'Phone Call', 'Either'];
  if (!allowedContactMethods.includes(formData.preferredContactMethod)) {
    errors.preferredContactMethod = 'Select a preferred contact method.';
  }

  if ((formData.requiredCapacity || '').trim().length > 100) {
    errors.requiredCapacity = 'Required capacity must be 100 characters or fewer.';
  }

  if ((formData.requiredReadability || '').trim().length > 100) {
    errors.requiredReadability = 'Required readability must be 100 characters or fewer.';
  }

  const combinedNotes = [
    (formData.additionalRequirements || '').trim(),
    (formData.customerMessage || '').trim()
  ]
    .filter(Boolean)
    .join('\n');

  if (combinedNotes.length > 1500) {
    errors.additionalRequirements = 'Additional requirements and message must be under 1,500 characters.';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
    sanitized: {
      customerName,
      phone: phoneResult.normalized,
      preferredContactMethod: formData.preferredContactMethod,
      quantity,
      requiredCapacity: (formData.requiredCapacity || '').trim(),
      requiredReadability: (formData.requiredReadability || '').trim(),
      additionalRequirements: combinedNotes
    }
  };
}

/**
 * Validates product creation / editing inputs in the Admin panel.
 */
export function validateProductForm(formData) {
  const errors = {};

  const name = (formData.name || '').trim();
  if (name.length < 2 || name.length > 160) {
    errors.name = 'Product name is required (2–160 characters).';
  }

  const scaleType = (formData.scaleType || '').trim();
  if (scaleType.length < 2 || scaleType.length > 80) {
    errors.scaleType = 'Scale type is required.';
  }

  const pricingMode = formData.pricingMode;
  if (!['fixed', 'request'].includes(pricingMode)) {
    errors.pricingMode = 'Select a valid pricing mode.';
  }

  let displayPricePaise = null;
  if (pricingMode === 'fixed') {
    try {
      displayPricePaise = rupeesToPaise(formData.displayPriceRupees, {
        allowNull: false,
        allowZero: false
      });
    } catch (err) {
      errors.displayPriceRupees = err.message || 'Enter a valid reference price greater than ₹0.';
    }
  } else if (formData.displayPriceRupees && String(formData.displayPriceRupees).trim() !== '') {
    try {
      displayPricePaise = rupeesToPaise(formData.displayPriceRupees, {
        allowNull: true,
        allowZero: false
      });
    } catch (err) {
      errors.displayPriceRupees = err.message;
    }
  }

  const allowedAvailability = BUSINESS_INFO.availabilityStatuses.map((s) => s.value);
  if (!allowedAvailability.includes(formData.availabilityStatus)) {
    errors.availabilityStatus = 'Select a valid availability status.';
  }

  const description = (formData.description || '').trim();
  const specifications = (formData.specifications || '').trim();

  // Publishing check: a published product must have core name, scale type, and description or specs
  if (formData.isPublished && !description && !specifications && !formData.maximumCapacityValue) {
    errors.description =
      'Before publishing a product, provide a meaningful product description, technical specification, or capacity.';
  }

  let maximumCapacityValue = null;
  if (formData.maximumCapacityValue !== '' && formData.maximumCapacityValue !== null && formData.maximumCapacityValue !== undefined) {
    const cap = Number(formData.maximumCapacityValue);
    if (!Number.isFinite(cap) || cap <= 0) {
      errors.maximumCapacityValue = 'Maximum capacity must be a positive number.';
    } else {
      maximumCapacityValue = cap;
    }
  }

  let readabilityValue = null;
  if (formData.readabilityValue !== '' && formData.readabilityValue !== null && formData.readabilityValue !== undefined) {
    const readVal = Number(formData.readabilityValue);
    if (!Number.isFinite(readVal) || readVal <= 0) {
      errors.readabilityValue = 'Readability / division must be a positive number.';
    } else {
      readabilityValue = readVal;
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
    sanitized: {
      name,
      brand: (formData.brand || '').trim(),
      model: (formData.model || '').trim(),
      scaleType,
      maximumCapacityValue,
      maximumCapacityUnit: (formData.maximumCapacityUnit || 'kg').trim(),
      readabilityValue,
      readabilityUnit: (formData.readabilityUnit || 'g').trim(),
      platformDimensions: (formData.platformDimensions || '').trim(),
      powerSupply: (formData.powerSupply || '').trim(),
      specifications,
      description,
      pricingMode,
      displayPricePaise,
      availabilityStatus: formData.availabilityStatus,
      isPublished: Boolean(formData.isPublished)
    }
  };
}

/**
 * Validates repair record creation / editing inputs in the Admin panel.
 */
export function validateRepairForm(formData) {
  const errors = {};

  const customerName = (formData.customerName || '').trim();
  if (customerName.length < 2 || customerName.length > 120) {
    errors.customerName = 'Customer name is required (2–120 characters).';
  }

  const phoneCheck = validateAndNormalizePhone(formData.customerPhone);
  if (!phoneCheck.isValid) {
    errors.customerPhone = phoneCheck.error;
  }

  if (!isValidISODateString(formData.repairDate)) {
    errors.repairDate = 'Select a valid repair intake date (YYYY-MM-DD).';
  }

  const reportedFault = (formData.reportedFault || '').trim();
  if (reportedFault.length < 2 || reportedFault.length > 2000) {
    errors.reportedFault = 'Describe the reported fault (2–2,000 characters).';
  }

  if (!BUSINESS_INFO.repairStatuses.includes(formData.status)) {
    errors.status = 'Select a valid repair status.';
  }

  // Validate structured parts list
  const sanitizedParts = [];
  if (Array.isArray(formData.partsUsed)) {
    formData.partsUsed.forEach((part, index) => {
      const partName = (part.partName || '').trim();
      const hasAnyValue = partName !== '' || String(part.unitCostRupees ?? '').trim() !== '';
      if (!hasAnyValue) return;

      if (!partName) {
        errors[`part_${index}_name`] = `Part #${index + 1} requires a name.`;
      }
      const quantity = Number(part.quantity);
      if (!Number.isInteger(quantity) || quantity < 1 || quantity > 10000) {
        errors[`part_${index}_quantity`] = `Part #${index + 1} quantity must be a positive whole number.`;
      }
      let unitCostPaise = 0;
      try {
        unitCostPaise = rupeesToPaise(part.unitCostRupees ?? '0', {
          allowNull: false,
          allowZero: true
        });
      } catch (err) {
        errors[`part_${index}_cost`] = `Part #${index + 1}: ${err.message}`;
      }

      sanitizedParts.push({
        partName,
        quantity: Number.isInteger(quantity) && quantity > 0 ? quantity : 1,
        unitCostPaise
      });
    });
  }

  const parsePaiseField = (val, fieldKey, { allowNull = false } = {}) => {
    try {
      return rupeesToPaise(val, { allowNull, allowZero: true });
    } catch (err) {
      errors[fieldKey] = err.message;
      return allowNull ? null : 0;
    }
  };

  const labourAllocationPaise = parsePaiseField(formData.labourAllocationRupees || '0', 'labourAllocationRupees');
  const travelExpensePaise = parsePaiseField(formData.travelExpenseRupees || '0', 'travelExpenseRupees');
  const otherDirectExpensesPaise = parsePaiseField(formData.otherDirectExpensesRupees || '0', 'otherDirectExpensesRupees');
  const quotedAmountPaise = parsePaiseField(formData.quotedAmountRupees, 'quotedAmountRupees', { allowNull: true });
  const finalAmountChargedPaise = parsePaiseField(formData.finalAmountChargedRupees, 'finalAmountChargedRupees', { allowNull: true });

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
    sanitized: {
      repairDate: formData.repairDate,
      completedAt: formData.completedAt || null,
      deliveredAt: formData.deliveredAt || null,
      customerName,
      customerPhone: phoneCheck.normalized,
      equipmentBrand: (formData.equipmentBrand || '').trim(),
      equipmentModel: (formData.equipmentModel || '').trim(),
      equipmentCapacity: (formData.equipmentCapacity || '').trim(),
      serialNumber: (formData.serialNumber || '').trim(),
      reportedFault,
      diagnosis: (formData.diagnosis || '').trim(),
      workPerformed: (formData.workPerformed || '').trim(),
      partsUsed: sanitizedParts,
      labourAllocationPaise,
      travelExpensePaise,
      otherDirectExpensesPaise,
      quotedAmountPaise,
      finalAmountChargedPaise,
      status: formData.status,
      warrantyDetails: (formData.warrantyDetails || '').trim(),
      notes: (formData.notes || '').trim()
    }
  };
}

/**
 * Validates a payment or refund entry before saving under a repair record.
 */
export function validatePaymentForm(formData) {
  const errors = {};

  if (!isValidISODateString(formData.paymentDate)) {
    errors.paymentDate = 'Select a valid payment date (YYYY-MM-DD).';
  }

  if (!['received', 'refund'].includes(formData.type)) {
    errors.type = 'Select whether this entry is a payment received or a refund.';
  }

  let amountPaise = 0;
  try {
    amountPaise = rupeesToPaise(formData.amountRupees, {
      allowNull: false,
      allowZero: false
    });
  } catch (err) {
    errors.amountRupees = err.message;
  }

  if (!BUSINESS_INFO.paymentMethods.includes(formData.paymentMethod)) {
    errors.paymentMethod = 'Select a valid payment method.';
  }

  const notes = (formData.notes || '').trim();
  if (notes.length > 1000) {
    errors.notes = 'Notes must be 1,000 characters or fewer.';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
    sanitized: {
      paymentDate: formData.paymentDate,
      type: formData.type,
      amountPaise,
      paymentMethod: formData.paymentMethod,
      notes
    }
  };
}

/**
 * Validates a general business expense record.
 */
export function validateExpenseForm(formData) {
  const errors = {};

  if (!isValidISODateString(formData.date)) {
    errors.date = 'Select a valid expense date (YYYY-MM-DD).';
  }

  if (!BUSINESS_INFO.expenseCategories.includes(formData.category)) {
    errors.category = 'Select a valid expense category.';
  }

  const description = (formData.description || '').trim();
  if (description.length < 2 || description.length > 500) {
    errors.description = 'Enter an expense description (2–500 characters).';
  }

  let amountPaise = 0;
  try {
    amountPaise = rupeesToPaise(formData.amountRupees, {
      allowNull: false,
      allowZero: true
    });
  } catch (err) {
    errors.amountRupees = err.message;
  }

  const notes = (formData.notes || '').trim();
  if (notes.length > 1500) {
    errors.notes = 'Notes must be 1,500 characters or fewer.';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
    sanitized: {
      date: formData.date,
      category: formData.category,
      description,
      amountPaise,
      notes
    }
  };
}
