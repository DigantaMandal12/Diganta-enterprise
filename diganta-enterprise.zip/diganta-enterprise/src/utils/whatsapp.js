/**
 * WhatsApp URL and prefilled message builders for Diganta Enterprise.
 */

import { BUSINESS_INFO } from '../config/businessConfig.js';
import { formatPaiseToINR } from './currency.js';

/**
 * Builds a general WhatsApp contact link for Diganta Enterprise.
 */
export function buildBusinessWhatsAppUrl(customText = '') {
  if (!customText) {
    return BUSINESS_INFO.whatsappBaseUrl;
  }
  return `${BUSINESS_INFO.whatsappBaseUrl}?text=${encodeURIComponent(customText)}`;
}

/**
 * Builds a prefilled, URL-encoded WhatsApp link for a customer product enquiry.
 * Never describes the enquiry as a confirmed order or payment.
 */
export function buildEnquiryWhatsAppUrl({
  enquiryId,
  productName,
  productBrand,
  productModel,
  productSpecifications,
  productImageUrl,
  quantity,
  customerName,
  phone,
  preferredContactMethod,
  requiredCapacity,
  requiredReadability,
  additionalRequirements,
  quotedPricePaise
}) {
  const lines = [
    `Hello ${BUSINESS_INFO.name},`,
    'I have submitted a product enquiry on your website and would like to discuss availability and pricing:',
    '',
    `Enquiry Reference: ${enquiryId}`,
    `Product: ${productName}`
  ];

  const brandModel = [productBrand, productModel].filter(Boolean).join(' — ');
  if (brandModel) {
    lines.push(`Brand / Model: ${brandModel}`);
  }
  if (productSpecifications) {
    lines.push(`Product Specs: ${productSpecifications}`);
  }
  lines.push(`Quantity Needed: ${quantity}`);
  lines.push(`Customer Name: ${customerName}`);
  lines.push(`Contact Phone: ${phone}`);
  if (preferredContactMethod) {
    lines.push(`Preferred Contact: ${preferredContactMethod}`);
  }
  if (requiredCapacity) {
    lines.push(`Required Capacity: ${requiredCapacity}`);
  }
  if (requiredReadability) {
    lines.push(`Required Readability: ${requiredReadability}`);
  }
  if (quotedPricePaise !== null && quotedPricePaise !== undefined && quotedPricePaise > 0) {
    lines.push(`Recorded Quotation: ${formatPaiseToINR(quotedPricePaise)}`);
  }
  if (productImageUrl) {
    lines.push(`Product Photo: ${productImageUrl}`);
  }
  if (additionalRequirements) {
    lines.push(`Additional Requirements: ${additionalRequirements}`);
  }

  lines.push('', 'Please let me know the availability and quotation details.');

  return `${BUSINESS_INFO.whatsappBaseUrl}?text=${encodeURIComponent(lines.join('\n'))}`;
}

/**
 * Builds a WhatsApp link for the administrator to message a customer directly.
 */
export function buildCustomerWhatsAppUrl(customerPhone, messageText = '') {
  const digits = String(customerPhone || '').replace(/\D/g, '');
  let targetNumber = digits;
  if (digits.length === 10) {
    targetNumber = `91${digits}`;
  } else if (digits.length === 11 && digits.startsWith('0')) {
    targetNumber = `91${digits.slice(1)}`;
  }

  if (!targetNumber) return '';
  const base = `https://wa.me/${targetNumber}`;
  return messageText ? `${base}?text=${encodeURIComponent(messageText)}` : base;
}
