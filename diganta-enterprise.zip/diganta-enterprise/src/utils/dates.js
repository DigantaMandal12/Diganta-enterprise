/**
 * Date formatting and input helpers for Diganta Enterprise.
 */

const displayDateFormatter = new Intl.DateTimeFormat('en-IN', {
  day: '2-digit',
  month: 'short',
  year: 'numeric'
});

const displayDateTimeFormatter = new Intl.DateTimeFormat('en-IN', {
  day: '2-digit',
  month: 'short',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  hour12: true
});

/**
 * Returns today's date in YYYY-MM-DD local format for HTML date inputs.
 */
export function getTodayISODate() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

/**
 * Validates whether a string is a valid YYYY-MM-DD calendar date.
 */
export function isValidISODateString(dateStr) {
  if (typeof dateStr !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    return false;
  }
  const [y, m, d] = dateStr.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  return (
    dt.getUTCFullYear() === y &&
    dt.getUTCMonth() === m - 1 &&
    dt.getUTCDate() === d
  );
}

/**
 * Converts a Firestore Timestamp, Date, or ISO string into a readable Indian date.
 */
export function formatDate(value, fallback = '—') {
  if (!value) return fallback;
  try {
    if (typeof value?.toDate === 'function') {
      return displayDateFormatter.format(value.toDate());
    }
    if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
      const [y, m, d] = value.split('-').map(Number);
      return displayDateFormatter.format(new Date(y, m - 1, d));
    }
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime())) return fallback;
    return displayDateFormatter.format(parsed);
  } catch {
    return fallback;
  }
}

/**
 * Converts a Firestore Timestamp, Date, or ISO string into a readable date + time.
 */
export function formatDateTime(value, fallback = '—') {
  if (!value) return fallback;
  try {
    const dt = typeof value?.toDate === 'function' ? value.toDate() : new Date(value);
    if (Number.isNaN(dt.getTime())) return fallback;
    return displayDateTimeFormatter.format(dt);
  } catch {
    return fallback;
  }
}
