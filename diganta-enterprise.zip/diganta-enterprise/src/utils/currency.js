/**
 * Monetary and financial calculation utilities for Diganta Enterprise.
 *
 * All monetary figures in Firestore are stored as integer paise (1 INR = 100 paise)
 * to eliminate IEEE-754 floating-point drift across parts, payments, and expenses.
 */

const inrFormatter = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  minimumFractionDigits: 2,
  maximumFractionDigits: 2
});

const inrWholeFormatter = new Intl.NumberFormat('en-IN', {
  style: 'currency',
  currency: 'INR',
  minimumFractionDigits: 0,
  maximumFractionDigits: 2
});

/**
 * Validates and converts a rupee input (string or number) into integer paise.
 * Example: "125.50" -> 12550, 100 -> 10000
 * Throws an Error if the value is invalid, NaN, negative (when allowNegative is false),
 * or has more than 2 decimal places.
 */
export function rupeesToPaise(rupeesInput, { allowNull = false, allowZero = true } = {}) {
  if (rupeesInput === null || rupeesInput === undefined || rupeesInput === '') {
    if (allowNull) return null;
    throw new Error('Amount is required.');
  }

  const cleaned = typeof rupeesInput === 'string'
    ? rupeesInput.trim().replace(/,/g, '')
    : String(rupeesInput);

  if (!/^-?\d+(\.\d{1,2})?$/.test(cleaned)) {
    throw new Error('Enter a valid INR amount with at most 2 decimal places (e.g. 250 or 125.50).');
  }

  const numericValue = Number(cleaned);
  if (!Number.isFinite(numericValue)) {
    throw new Error('Amount must be a finite number.');
  }

  const paise = Math.round(numericValue * 100);

  if (paise < 0) {
    throw new Error('Amount cannot be negative.');
  }

  if (!allowZero && paise === 0) {
    throw new Error('Amount must be greater than zero.');
  }

  return paise;
}

/**
 * Converts integer paise to a plain rupee decimal string suitable for form inputs.
 * Example: 12550 -> "125.50", 10000 -> "100"
 */
export function paiseToRupeesInput(paise) {
  if (paise === null || paise === undefined || paise === '') {
    return '';
  }
  const num = Number(paise);
  if (!Number.isFinite(num)) return '';
  const rupees = num / 100;
  return Number.isInteger(rupees) ? String(rupees) : rupees.toFixed(2);
}

/**
 * Formats integer paise for display in Indian Rupees (e.g. ₹125.50).
 */
export function formatPaiseToINR(paise, { compactWhole = false, fallback = 'Not set' } = {}) {
  if (paise === null || paise === undefined || Number.isNaN(Number(paise))) {
    return fallback;
  }
  const intPaise = Math.round(Number(paise));
  const rupees = intPaise / 100;
  if (compactWhole && intPaise % 100 === 0) {
    return inrWholeFormatter.format(rupees);
  }
  return inrFormatter.format(rupees);
}

/**
 * Calculates the total parts cost in paise from structured part line items.
 * Each item: { partName, quantity, unitCostPaise }
 */
export function calculatePartsTotalPaise(partsUsed = []) {
  if (!Array.isArray(partsUsed)) {
    throw new Error('Parts list must be an array.');
  }

  return partsUsed.reduce((sum, part, idx) => {
    const qty = Number(part?.quantity);
    const unitCost = Number(part?.unitCostPaise);

    if (!Number.isInteger(qty) || qty <= 0) {
      throw new Error(`Part #${idx + 1} has an invalid quantity.`);
    }
    if (!Number.isInteger(unitCost) || unitCost < 0) {
      throw new Error(`Part #${idx + 1} has an invalid unit cost.`);
    }

    return sum + qty * unitCost;
  }, 0);
}

/**
 * Calculates total recorded direct repair cost in paise:
 * Total Recorded Repair Cost = Parts Cost + Labour Allocation + Travel Expense + Other Direct Expenses
 */
export function calculateDirectRepairCost(repair = {}) {
  const partsCostPaise = calculatePartsTotalPaise(repair.partsUsed || []);
  const labourAllocationPaise = Number(repair.labourAllocationPaise ?? 0);
  const travelExpensePaise = Number(repair.travelExpensePaise ?? 0);
  const otherDirectExpensesPaise = Number(repair.otherDirectExpensesPaise ?? 0);

  if (
    !Number.isInteger(labourAllocationPaise) || labourAllocationPaise < 0 ||
    !Number.isInteger(travelExpensePaise) || travelExpensePaise < 0 ||
    !Number.isInteger(otherDirectExpensesPaise) || otherDirectExpensesPaise < 0
  ) {
    throw new Error('Direct repair cost components must be non-negative integers in paise.');
  }

  const totalCostPaise =
    partsCostPaise +
    labourAllocationPaise +
    travelExpensePaise +
    otherDirectExpensesPaise;

  return {
    partsCostPaise,
    labourAllocationPaise,
    travelExpensePaise,
    otherDirectExpensesPaise,
    totalCostPaise
  };
}

/**
 * Calculates payment totals, net collected, outstanding balance, overpayment credit,
 * and payment status from a repair record and its payments array.
 *
 * Rules:
 * - Net Collected = Sum(received) - Sum(refund)
 * - Outstanding Balance = max(0, Final Amount Charged - Net Collected) when Final Amount Charged is set
 * - Overpayment Credit = max(0, Net Collected - Final Amount Charged)
 * - Quotations NEVER count as money received or final amount charged.
 * - Repair status (Completed / Delivered) NEVER automatically marks a repair as Paid.
 */
export function calculateRepairPaymentSummary(repair = {}, payments = []) {
  if (!Array.isArray(payments)) {
    throw new Error('Payments list must be an array.');
  }

  let totalReceivedPaise = 0;
  let totalRefundedPaise = 0;

  payments.forEach((entry, index) => {
    const amount = Number(entry?.amountPaise);
    if (!Number.isInteger(amount) || amount <= 0) {
      throw new Error(`Payment entry #${index + 1} must have a positive integer amount in paise.`);
    }
    if (entry.type === 'received') {
      totalReceivedPaise += amount;
    } else if (entry.type === 'refund') {
      totalRefundedPaise += amount;
    } else {
      throw new Error(`Payment entry #${index + 1} has an unsupported payment type "${entry?.type}".`);
    }
  });

  const netCollectedPaise = totalReceivedPaise - totalRefundedPaise;
  const hasFinalCharge =
    repair.finalAmountChargedPaise !== null &&
    repair.finalAmountChargedPaise !== undefined &&
    repair.finalAmountChargedPaise !== '';

  const finalAmountChargedPaise = hasFinalCharge
    ? Number(repair.finalAmountChargedPaise)
    : null;

  if (hasFinalCharge && (!Number.isInteger(finalAmountChargedPaise) || finalAmountChargedPaise < 0)) {
    throw new Error('Final amount charged must be a non-negative integer in paise.');
  }

  let outstandingBalancePaise = 0;
  let overpaymentCreditPaise = 0;
  let paymentStatus = 'Not Yet Charged';

  if (!hasFinalCharge) {
    if (netCollectedPaise > 0) {
      paymentStatus = 'Advance Collected (Final Charge Pending)';
      overpaymentCreditPaise = netCollectedPaise;
    } else if (netCollectedPaise < 0) {
      paymentStatus = 'Net Refunded';
    } else {
      paymentStatus = 'Not Yet Charged';
    }
  } else if (finalAmountChargedPaise === 0) {
    if (netCollectedPaise > 0) {
      paymentStatus = 'Overpaid / Customer Credit';
      overpaymentCreditPaise = netCollectedPaise;
    } else {
      paymentStatus = 'No Charge (₹0)';
    }
  } else {
    const rawDiff = finalAmountChargedPaise - netCollectedPaise;
    if (rawDiff > 0) {
      outstandingBalancePaise = rawDiff;
      paymentStatus = netCollectedPaise > 0 ? 'Partially Paid' : 'Unpaid';
    } else if (rawDiff === 0) {
      outstandingBalancePaise = 0;
      paymentStatus = 'Paid';
    } else {
      outstandingBalancePaise = 0;
      overpaymentCreditPaise = Math.abs(rawDiff);
      paymentStatus = 'Overpaid / Customer Credit';
    }
  }

  return {
    totalReceivedPaise,
    totalRefundedPaise,
    netCollectedPaise,
    finalAmountChargedPaise,
    outstandingBalancePaise,
    overpaymentCreditPaise,
    paymentStatus
  };
}

/**
 * Calculates the financial summary for a single repair:
 * - Estimated Repair Profit (Collection-based) = Net Collected - Total Recorded Repair Cost
 * - Billed Margin (Charge-based, when final charge is set) = Final Amount Charged - Total Recorded Repair Cost
 */
export function calculateRepairFinancials(repair = {}, payments = []) {
  const costBreakdown = calculateDirectRepairCost(repair);
  const paymentSummary = calculateRepairPaymentSummary(repair, payments);

  const estimatedCollectionProfitPaise =
    paymentSummary.netCollectedPaise - costBreakdown.totalCostPaise;

  const billedMarginPaise =
    paymentSummary.finalAmountChargedPaise !== null
      ? paymentSummary.finalAmountChargedPaise - costBreakdown.totalCostPaise
      : null;

  return {
    ...costBreakdown,
    ...paymentSummary,
    quotedAmountPaise:
      repair.quotedAmountPaise !== null && repair.quotedAmountPaise !== undefined
        ? Number(repair.quotedAmountPaise)
        : null,
    estimatedCollectionProfitPaise,
    billedMarginPaise
  };
}

/**
 * Calculates aggregate business financial metrics across repairs, payments, and general expenses.
 *
 * Date basis rules (explicitly separated so metrics are accurate):
 * - Collections: filtered by payment.paymentDate
 * - Direct repair costs & charges: filtered by repair.repairDate
 * - General business expenses: filtered by expense.date
 *
 * Formula:
 * Estimated Business Result =
 *   Recorded Net Customer Collections
 * - Recorded Direct Repair Costs
 * - Recorded General Business Expenses
 */
export function calculateBusinessSummary({
  repairs = [],
  paymentsByRepairId = {},
  expenses = [],
  startDate = null,
  endDate = null
} = {}) {
  const inDateRange = (dateStr) => {
    if (!startDate && !endDate) return true;
    if (!dateStr || typeof dateStr !== 'string') return false;
    const normalized = dateStr.slice(0, 10);
    if (startDate && normalized < startDate) return false;
    if (endDate && normalized > endDate) return false;
    return true;
  };

  let totalRepairsCount = 0;
  let pendingRepairsCount = 0;
  let completedRepairsCount = 0;
  let totalChargedPaise = 0;
  let totalDirectRepairCostPaise = 0;
  let totalOutstandingBalancePaise = 0;
  let totalOverpaymentCreditPaise = 0;

  repairs.forEach((repair) => {
    const repairInPeriod = inDateRange(repair.repairDate);
    const repairPayments = paymentsByRepairId[repair.id] || [];
    const financials = calculateRepairFinancials(repair, repairPayments);

    if (repairInPeriod) {
      totalRepairsCount += 1;
      if (['Completed', 'Delivered'].includes(repair.status)) {
        completedRepairsCount += 1;
      } else {
        pendingRepairsCount += 1;
      }

      if (financials.finalAmountChargedPaise !== null) {
        totalChargedPaise += financials.finalAmountChargedPaise;
      }
      totalDirectRepairCostPaise += financials.totalCostPaise;
      totalOutstandingBalancePaise += financials.outstandingBalancePaise;
      totalOverpaymentCreditPaise += financials.overpaymentCreditPaise;
    }
  });

  // Collections are aggregated by paymentDate across all payment records
  let grossCollectedPaise = 0;
  let totalRefundsPaise = 0;

  Object.values(paymentsByRepairId).forEach((paymentList) => {
    (paymentList || []).forEach((payment) => {
      if (inDateRange(payment.paymentDate)) {
        const amt = Number(payment.amountPaise || 0);
        if (payment.type === 'received') {
          grossCollectedPaise += amt;
        } else if (payment.type === 'refund') {
          totalRefundsPaise += amt;
        }
      }
    });
  });

  const netCustomerCollectionsPaise = grossCollectedPaise - totalRefundsPaise;

  // General business expenses are aggregated by expense.date
  let totalGeneralExpensesPaise = 0;
  const expensesByCategoryPaise = {};

  expenses.forEach((expense) => {
    if (inDateRange(expense.date)) {
      const amount = Number(expense.amountPaise || 0);
      if (!Number.isInteger(amount) || amount < 0) {
        throw new Error('Expense amount must be a non-negative integer in paise.');
      }
      totalGeneralExpensesPaise += amount;
      const cat = expense.category || 'Other';
      expensesByCategoryPaise[cat] = (expensesByCategoryPaise[cat] || 0) + amount;
    }
  });

  const estimatedRepairProfitPaise =
    netCustomerCollectionsPaise - totalDirectRepairCostPaise;

  const estimatedBusinessResultPaise =
    netCustomerCollectionsPaise -
    totalDirectRepairCostPaise -
    totalGeneralExpensesPaise;

  return {
    totalRepairsCount,
    pendingRepairsCount,
    completedRepairsCount,
    totalChargedPaise,
    grossCollectedPaise,
    totalRefundsPaise,
    netCustomerCollectionsPaise,
    totalOutstandingBalancePaise,
    totalOverpaymentCreditPaise,
    totalDirectRepairCostPaise,
    totalGeneralExpensesPaise,
    expensesByCategoryPaise,
    estimatedRepairProfitPaise,
    estimatedBusinessResultPaise
  };
}
