import React, { createContext, useContext, useEffect, useState, useMemo } from 'react';
import {
  checkIsAdminUser,
  loginAdmin,
  logoutAdmin,
  subscribeToAuthChanges
} from '../services/authService.js';
import { isFirebaseConfigured } from '../services/firebase.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState(null);

  useEffect(() => {
    if (!isFirebaseConfigured) {
      setLoading(false);
      return () => {};
    }

    const unsubscribe = subscribeToAuthChanges(async (firebaseUser) => {
      setLoading(true);
      setAuthError(null);

      if (!firebaseUser) {
        setUser(null);
        setIsAdmin(false);
        setLoading(false);
        return;
      }

      setUser(firebaseUser);
      const allowed = await checkIsAdminUser(firebaseUser.uid);
      setIsAdmin(allowed);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signIn = async (email, password) => {
    setAuthError(null);
    const result = await loginAdmin(email, password);
    setUser(result.user);
    setIsAdmin(result.isAdmin);
    return result;
  };

  const signOutUser = async () => {
    await logoutAdmin();
    setUser(null);
    setIsAdmin(false);
  };

  const value = useMemo(
    () => ({
      user,
      isAdmin,
      loading,
      authError,
      signIn,
      signOutUser
    }),
    [user, isAdmin, loading, authError]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used inside an AuthProvider.');
  }
  return ctx;
}
