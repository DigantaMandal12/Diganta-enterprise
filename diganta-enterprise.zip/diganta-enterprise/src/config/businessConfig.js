/**
 * Centralised, verified business configuration for Diganta Enterprise.
 * Single source of truth for contact details, location, operating hours,
 * supported weighing capacities, and repair video configuration.
 *
 * IMPORTANT: Do not invent street addresses, postal codes, map coordinates,
 * email addresses, warranties, or official brand authorisation claims.
 */

export const BUSINESS_INFO = {
  name: 'Diganta Enterprise',
  tagline: 'Weighing Scale Repair & Sales',
  shortDescription:
    'Practical electronic weighing-scale repair, PCB and transformer troubleshooting, and weighing-scale sales serving Mohonpur, Ariabāṛā, and nearby areas.',
  location: 'Mohonpur, Ariabāṛā, West Bengal, India',
  serviceRadius: 'Approximately 10–20 km',
  phoneDisplay: '+91 93302 50245',
  phoneE164: '+919330250245',
  phoneHref: 'tel:+919330250245',
  whatsappDisplay: '+91 93302 50245',
  whatsappNumber: '919330250245',
  whatsappBaseUrl: 'https://wa.me/919330250245',
  businessHours: 'Monday–Sunday, 10:00 AM–10:00 PM',
  knownBrands: ['Vison Tech'],
  supportedCapacities: [
    '10 kg',
    '20 kg',
    '30 kg',
    '50 kg',
    '100 kg',
    '150–300 kg',
    'Other capacities where supported'
  ],
  scaleTypes: [
    'Tabletop Scale',
    'Platform Scale',
    'Price Computing Scale',
    'Bench Scale',
    'Hanging / Crane Scale',
    'Heavy-Duty Industrial Scale',
    'Other Weighing Equipment'
  ],
  pricingModes: [
    { value: 'fixed', label: 'Reference Display Price' },
    { value: 'request', label: 'Request Price / Quotation' }
  ],
  availabilityStatuses: [
    { value: 'available', label: 'Available' },
    { value: 'order-based', label: 'Available on Order' },
    { value: 'unavailable', label: 'Currently Unavailable' },
    { value: 'unknown', label: 'Check Availability' }
  ],
  enquiryStatuses: [
    'New',
    'Contacted',
    'Quotation Sent',
    'Converted',
    'Closed'
  ],
  repairStatuses: [
    'Received',
    'Diagnosing',
    'Waiting for Parts',
    'Repairing',
    'Completed',
    'Delivered'
  ],
  paymentMethods: [
    'Cash',
    'UPI',
    'Bank Transfer',
    'Other'
  ],
  expenseCategories: [
    'Transport',
    'Tools',
    'Workshop supplies',
    'Utilities',
    'Other'
  ]
};

/**
 * Editable configuration for genuine YouTube repair videos.
 * Leave this array empty until actual Diganta Enterprise YouTube video URLs or IDs are added.
 * Never populate with fake or third-party videos claiming to be Diganta Enterprise work.
 *
 * Example entry structure when the owner adds real videos:
 * {
 *   id: 'video-1',
 *   youtubeUrlOrId: 'https://www.youtube.com/watch?v=YOUR_VIDEO_ID',
 *   title: '100 kg Platform Scale Load-Cell & PCB Inspection',
 *   description: 'Workshop diagnostic and display calibration check on an electronic platform scale.'
 * }
 */
export const REPAIR_VIDEOS = [];
