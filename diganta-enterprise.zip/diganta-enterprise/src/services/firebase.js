/**
 * Centralised Firebase initialisation module using the modular Firebase v11 SDK.
 * Pre-configured for Firebase project: diganta-enterprise (diganta-enterprise.firebaseapp.com).
 */

import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth, connectAuthEmulator } from 'firebase/auth';
import { getFirestore, connectFirestoreEmulator } from 'firebase/firestore';
import { getStorage, connectStorageEmulator } from 'firebase/storage';
import { initializeAppCheck, ReCaptchaV3Provider } from 'firebase/app-check';

const env = import.meta.env || {};
export const RUNTIME_CONFIG_STORAGE_KEY = 'diganta_firebase_runtime_config';

function loadRuntimeConfig() {
  if (typeof window === 'undefined') return {};
  try {
    const raw = window.localStorage.getItem(RUNTIME_CONFIG_STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

const runtimeConfig = loadRuntimeConfig();

export const firebaseConfig = {
  apiKey:
    runtimeConfig.apiKey ||
    env.VITE_FIREBASE_API_KEY ||
    'AIzaSyC5zZmJ6gupoR00t2613FvzRaxEehIob78',
  authDomain:
    runtimeConfig.authDomain ||
    env.VITE_FIREBASE_AUTH_DOMAIN ||
    'diganta-enterprise.firebaseapp.com',
  projectId:
    runtimeConfig.projectId ||
    env.VITE_FIREBASE_PROJECT_ID ||
    'diganta-enterprise',
  storageBucket:
    runtimeConfig.storageBucket ||
    env.VITE_FIREBASE_STORAGE_BUCKET ||
    'diganta-enterprise.firebasestorage.app',
  messagingSenderId:
    runtimeConfig.messagingSenderId ||
    env.VITE_FIREBASE_MESSAGING_SENDER_ID ||
    '205335320819',
  appId:
    runtimeConfig.appId ||
    env.VITE_FIREBASE_APP_ID ||
    '1:205335320819:web:6cf0813b676b73d5d73f86',
  measurementId:
    runtimeConfig.measurementId ||
    env.VITE_FIREBASE_MEASUREMENT_ID ||
    'G-6PH6GC5ZPC'
};

const requiredConfigKeys = [
  'apiKey',
  'authDomain',
  'projectId',
  'storageBucket',
  'messagingSenderId',
  'appId'
];

function isPlaceholderValue(val) {
  if (!val) return true;
  const s = String(val).trim();
  return (
    s === '' ||
    s.startsWith('your_') ||
    s.startsWith('your-') ||
    s === '000000000000' ||
    s === '1:000000000000:web:0000000000000000'
  );
}

export const missingFirebaseConfigKeys = requiredConfigKeys.filter((key) =>
  isPlaceholderValue(firebaseConfig[key])
);

export const isFirebaseConfigured = missingFirebaseConfigKeys.length === 0;

export const appCheckSiteKey = (
  runtimeConfig.appCheckSiteKey ||
  env.VITE_FIREBASE_APPCHECK_SITE_KEY ||
  ''
).trim();

export const isAppCheckConfigured = Boolean(
  appCheckSiteKey && !appCheckSiteKey.startsWith('your_')
);

let app = null;
let auth = null;
let db = null;
let storage = null;
let appCheck = null;
let emulatorsConnected = false;

if (isFirebaseConfigured) {
  app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
  auth = getAuth(app);
  db = getFirestore(app);
  storage = getStorage(app);

  if (env.DEV && env.VITE_USE_FIREBASE_EMULATOR === 'true' && !emulatorsConnected) {
    connectAuthEmulator(auth, 'http://127.0.0.1:9099', { disableWarnings: true });
    connectFirestoreEmulator(db, '127.0.0.1', 8080);
    connectStorageEmulator(storage, '127.0.0.1', 9199);
    emulatorsConnected = true;
  }

  if (typeof window !== 'undefined' && isAppCheckConfigured) {
    try {
      appCheck = initializeAppCheck(app, {
        provider: new ReCaptchaV3Provider(appCheckSiteKey),
        isTokenAutoRefreshEnabled: true
      });
    } catch (err) {
      console.warn('[Diganta Enterprise] App Check initialisation warning:', err);
    }
  }
}

export function saveRuntimeFirebaseConfig(newConfig) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(RUNTIME_CONFIG_STORAGE_KEY, JSON.stringify(newConfig));
  window.location.reload();
}

export function clearRuntimeFirebaseConfig() {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem(RUNTIME_CONFIG_STORAGE_KEY);
  window.location.reload();
}

export function assertFirebaseConfigured() {
  if (!isFirebaseConfigured || !db || !auth || !storage) {
    throw new Error(
      `Firebase is not configured yet. Missing keys: ${missingFirebaseConfigKeys.join(', ')}.`
    );
  }
}

export { app, auth, db, storage, appCheck };
