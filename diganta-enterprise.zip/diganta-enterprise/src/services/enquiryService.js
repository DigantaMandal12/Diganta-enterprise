/**
 * Customer Product Enquiry & Admin Enquiry Management Service.
 *
 * Public submission sequence:
 * 1. Generate a document reference with a known ID (`doc(collection(db, 'enquiries'))`).
 * 2. Construct validated snapshot payload with `status: 'New'`, `quotedPricePaise: null`,
 *    `notes: ''`, and `serverTimestamp()` for `createdAt` and `updatedAt`.
 * 3. Await `setDoc(docRef, payload)` (note: public users have `create` permission only,
 *    never `read` permission, so we do NOT call `getDoc` after saving).
 * 4. Return the confirmed `enquiryId` for the customer confirmation screen and WhatsApp link.
 */

import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp
} from 'firebase/firestore';
import { db, assertFirebaseConfigured } from './firebase.js';

const ENQUIRIES_COLLECTION = 'enquiries';

function normalizeEnquiryDoc(snapshot) {
  if (!snapshot.exists()) return null;
  const d = snapshot.data();
  return {
    id: snapshot.id,
    createdAt: d.createdAt || null,
    updatedAt: d.updatedAt || null,
    customerName: d.customerName || '',
    phone: d.phone || '',
    preferredContactMethod: d.preferredContactMethod || 'WhatsApp',
    productId: d.productId || '',
    productNameSnapshot: d.productNameSnapshot || '',
    productBrandSnapshot: d.productBrandSnapshot || '',
    productModelSnapshot: d.productModelSnapshot || '',
    productSpecificationsSnapshot: d.productSpecificationsSnapshot || '',
    productImageUrlSnapshot: d.productImageUrlSnapshot || '',
    quantity: Number(d.quantity || 1),
    requiredCapacity: d.requiredCapacity || '',
    requiredReadability: d.requiredReadability || '',
    additionalRequirements: d.additionalRequirements || '',
    status: d.status || 'New',
    quotedPricePaise: d.quotedPricePaise ?? null,
    notes: d.notes || ''
  };
}

/**
 * Formats a concise product specification summary for the enquiry snapshot.
 */
export function buildProductSpecsSnapshot(product) {
  if (!product) return '';
  const parts = [];
  if (product.scaleType) parts.push(`Type: ${product.scaleType}`);
  if (product.maximumCapacityValue) {
    parts.push(`Max Capacity: ${product.maximumCapacityValue} ${product.maximumCapacityUnit || 'kg'}`);
  }
  if (product.readabilityValue) {
    parts.push(`Readability: ${product.readabilityValue} ${product.readabilityUnit || 'g'}`);
  }
  if (product.platformDimensions) {
    parts.push(`Platform: ${product.platformDimensions}`);
  }
  if (product.powerSupply) {
    parts.push(`Power: ${product.powerSupply}`);
  }
  return parts.join(' | ').slice(0, 950);
}

/**
 * Submits a validated public customer product enquiry to Firestore.
 */
export async function submitPublicProductEnquiry({
  product,
  productImageUrl = '',
  sanitizedInput
}) {
  assertFirebaseConfigured();
  if (!product || !product.id || !product.isPublished) {
    throw new Error('Selected product is not available for enquiry.');
  }

  const enquiryRef = doc(collection(db, ENQUIRIES_COLLECTION));
  const specsSnapshot = buildProductSpecsSnapshot(product);

  const payload = {
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
    customerName: sanitizedInput.customerName,
    phone: sanitizedInput.phone,
    preferredContactMethod: sanitizedInput.preferredContactMethod,
    productId: product.id,
    productNameSnapshot: product.name,
    productBrandSnapshot: product.brand || '',
    productModelSnapshot: product.model || '',
    productSpecificationsSnapshot: specsSnapshot,
    productImageUrlSnapshot: productImageUrl || '',
    quantity: sanitizedInput.quantity,
    requiredCapacity: sanitizedInput.requiredCapacity || '',
    requiredReadability: sanitizedInput.requiredReadability || '',
    additionalRequirements: sanitizedInput.additionalRequirements || '',
    status: 'New',
    quotedPricePaise: null,
    notes: ''
  };

  await setDoc(enquiryRef, payload);

  return {
    enquiryId: enquiryRef.id,
    ...payload
  };
}

/**
 * Lists product enquiries for the administrator, optionally filtered by status.
 */
export async function listEnquiriesAdmin({ statusFilter = 'ALL' } = {}) {
  assertFirebaseConfigured();
  let q;
  if (statusFilter && statusFilter !== 'ALL') {
    q = query(
      collection(db, ENQUIRIES_COLLECTION),
      where('status', '==', statusFilter),
      orderBy('createdAt', 'desc')
    );
  } else {
    q = query(collection(db, ENQUIRIES_COLLECTION), orderBy('createdAt', 'desc'));
  }
  const snap = await getDocs(q);
  return snap.docs.map(normalizeEnquiryDoc);
}

/**
 * Fetches a single enquiry document for the administrator.
 */
export async function getEnquiryByIdAdmin(enquiryId) {
  assertFirebaseConfigured();
  if (!enquiryId) return null;
  const snap = await getDoc(doc(db, ENQUIRIES_COLLECTION, enquiryId));
  return normalizeEnquiryDoc(snap);
}

/**
 * Updates status, quotedPricePaise, and admin notes on an enquiry record.
 */
export async function updateEnquiryAdmin(enquiryId, { status, quotedPricePaise, notes }) {
  assertFirebaseConfigured();
  const docRef = doc(db, ENQUIRIES_COLLECTION, enquiryId);
  await updateDoc(docRef, {
    status,
    quotedPricePaise: quotedPricePaise ?? null,
    notes: (notes || '').trim(),
    updatedAt: serverTimestamp()
  });
}

/**
 * Deletes an enquiry record (admin only).
 */
export async function deleteEnquiryAdmin(enquiryId) {
  assertFirebaseConfigured();
  await deleteDoc(doc(db, ENQUIRIES_COLLECTION, enquiryId));
}
