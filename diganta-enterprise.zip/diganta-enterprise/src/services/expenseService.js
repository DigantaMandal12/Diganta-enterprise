/**
 * General Business Expense Management Service (`expenses/{expenseId}`).
 *
 * Note: Direct repair expenses (parts, labour allocation, travel for a specific repair)
 * are recorded on the individual repair document and must NOT be duplicated here.
 */

import {
  collection,
  doc,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp
} from 'firebase/firestore';
import { db, assertFirebaseConfigured } from './firebase.js';

const EXPENSES_COLLECTION = 'expenses';

function normalizeExpenseDoc(snapshot) {
  if (!snapshot.exists()) return null;
  const d = snapshot.data();
  return {
    id: snapshot.id,
    createdAt: d.createdAt || null,
    updatedAt: d.updatedAt || null,
    date: d.date || '',
    category: d.category || 'Other',
    description: d.description || '',
    amountPaise: Number(d.amountPaise || 0),
    notes: d.notes || ''
  };
}

/**
 * Lists general business expenses, optionally filtered by category.
 */
export async function listExpensesAdmin({ categoryFilter = 'ALL' } = {}) {
  assertFirebaseConfigured();
  let q;
  if (categoryFilter && categoryFilter !== 'ALL') {
    q = query(
      collection(db, EXPENSES_COLLECTION),
      where('category', '==', categoryFilter),
      orderBy('date', 'desc')
    );
  } else {
    q = query(collection(db, EXPENSES_COLLECTION), orderBy('date', 'desc'));
  }
  const snap = await getDocs(q);
  return snap.docs.map(normalizeExpenseDoc);
}

/**
 * Creates a new general business expense record.
 */
export async function createExpenseAdmin(sanitizedExpense) {
  assertFirebaseConfigured();
  const docRef = await addDoc(collection(db, EXPENSES_COLLECTION), {
    ...sanitizedExpense,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
  return docRef.id;
}

/**
 * Updates an existing general business expense record.
 */
export async function updateExpenseAdmin(expenseId, sanitizedExpense) {
  assertFirebaseConfigured();
  const docRef = doc(db, EXPENSES_COLLECTION, expenseId);
  await updateDoc(docRef, {
    ...sanitizedExpense,
    updatedAt: serverTimestamp()
  });
}

/**
 * Deletes a general business expense record.
 */
export async function deleteExpenseAdmin(expenseId) {
  assertFirebaseConfigured();
  await deleteDoc(doc(db, EXPENSES_COLLECTION, expenseId));
}
