/**
 * Repair Payment & Refund Subcollection Service (`repairs/{repairId}/payments/{paymentId}`).
 *
 * Business & Security Rules:
 * - Associated repair record must exist before creating a payment entry.
 * - Both 'received' and 'refund' store positive integer `amountPaise`; refunds reduce net collections.
 * - Payment history is append-oriented so collections and refunds remain auditable.
 */

import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  deleteDoc,
  query,
  orderBy,
  serverTimestamp
} from 'firebase/firestore';
import { db, assertFirebaseConfigured } from './firebase.js';

function normalizePaymentDoc(snapshot) {
  if (!snapshot.exists()) return null;
  const d = snapshot.data();
  return {
    id: snapshot.id,
    createdAt: d.createdAt || null,
    paymentDate: d.paymentDate || '',
    type: d.type || 'received',
    amountPaise: Number(d.amountPaise || 0),
    paymentMethod: d.paymentMethod || 'Cash',
    notes: d.notes || ''
  };
}

/**
 * Lists all payment and refund records for a specific repair ordered by paymentDate.
 */
export async function listPaymentsForRepair(repairId) {
  assertFirebaseConfigured();
  if (!repairId) return [];
  const paymentsRef = collection(db, 'repairs', repairId, 'payments');
  const q = query(paymentsRef, orderBy('paymentDate', 'asc'));
  const snap = await getDocs(q);
  return snap.docs.map(normalizePaymentDoc);
}

/**
 * Loads payments for multiple repairs and returns a map `{ [repairId]: Payment[] }`.
 */
export async function listPaymentsMapForRepairs(repairs = []) {
  assertFirebaseConfigured();
  const entries = await Promise.all(
    repairs.map(async (repair) => {
      const list = await listPaymentsForRepair(repair.id);
      return [repair.id, list];
    })
  );
  return Object.fromEntries(entries);
}

/**
 * Adds a validated payment ('received') or refund ('refund') entry to a repair.
 * Verifies that the parent repair document exists before writing.
 */
export async function addPaymentForRepair(repairId, sanitizedPayment) {
  assertFirebaseConfigured();
  if (!repairId) {
    throw new Error('Repair ID is required to record a payment.');
  }

  const repairSnap = await getDoc(doc(db, 'repairs', repairId));
  if (!repairSnap.exists()) {
    throw new Error('Cannot record payment: the associated repair record does not exist.');
  }

  const paymentsRef = collection(db, 'repairs', repairId, 'payments');
  const docRef = await addDoc(paymentsRef, {
    ...sanitizedPayment,
    createdAt: serverTimestamp()
  });

  return docRef.id;
}

/**
 * Deletes a payment entry (used only when deleting an entire repair record).
 */
export async function deletePaymentRecord(repairId, paymentId) {
  assertFirebaseConfigured();
  await deleteDoc(doc(db, 'repairs', repairId, 'payments', paymentId));
}
