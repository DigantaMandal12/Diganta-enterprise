/**
 * Firebase Cloud Storage Service for public product photos and private repair photos.
 *
 * Privacy separation:
 * 1. Product photos (`products/{productId}/{uniqueFileName}`):
 *    - Publicly readable for the product catalogue.
 *    - Resolved via `getDownloadURL` for public viewing.
 *    - Only the authorised administrator can upload, replace, or delete.
 * 2. Private repair photos (`repairs/{repairId}/{uniqueFileName}`):
 *    - Strictly private to the authorised administrator.
 *    - Never converted into public long-lived download URLs or stored in public documents.
 *    - Retrieved via authenticated `getBytes()` / `getBlob()` and rendered using temporary
 *      `URL.createObjectURL(blob)` that is revoked on cleanup.
 */

import {
  ref,
  uploadBytesResumable,
  getDownloadURL,
  getBlob,
  deleteObject
} from 'firebase/storage';
import { storage, assertFirebaseConfigured } from './firebase.js';

export const MAX_IMAGE_SIZE_BYTES = 5 * 1024 * 1024; // 5 MiB
export const ALLOWED_IMAGE_MIME_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

const MIME_TO_EXT = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp'
};

/**
 * Validates an image file before starting a Storage upload.
 */
export function validateImageFile(file) {
  if (!file) {
    throw new Error('No image file selected.');
  }
  if (!ALLOWED_IMAGE_MIME_TYPES.includes(file.type)) {
    throw new Error('Unsupported file format. Please upload a JPEG, PNG, or WebP image.');
  }
  if (file.size <= 0) {
    throw new Error('Selected image file is empty.');
  }
  if (file.size > MAX_IMAGE_SIZE_BYTES) {
    const sizeMb = (file.size / (1024 * 1024)).toFixed(2);
    throw new Error(`Image file (${sizeMb} MiB) exceeds the 5 MiB maximum upload limit.`);
  }
  return true;
}

/**
 * Builds a clean, collision-resistant Storage path without customer PII.
 */
export function createSafeStoragePath(folder, recordId, file) {
  const safeRecordId = String(recordId || '').replace(/[^a-zA-Z0-9_-]/g, '');
  if (!safeRecordId) {
    throw new Error('A valid record ID is required for Storage uploads.');
  }
  const ext = MIME_TO_EXT[file.type] || 'jpg';
  const timestamp = Date.now();
  const randomSuffix = Math.random().toString(36).slice(2, 10);
  return `${folder}/${safeRecordId}/${timestamp}-${randomSuffix}.${ext}`;
}

/**
 * Uploads an image file to Firebase Cloud Storage with progress callback support.
 * Returns the canonical Storage object path (e.g. `products/abc123/173000-xyz.jpg`).
 */
export function uploadStorageImage({ folder, recordId, file, onProgress }) {
  assertFirebaseConfigured();
  validateImageFile(file);

  if (!['products', 'repairs'].includes(folder)) {
    throw new Error('Invalid Storage target folder.');
  }

  const storagePath = createSafeStoragePath(folder, recordId, file);
  const storageRef = ref(storage, storagePath);

  return new Promise((resolve, reject) => {
    const uploadTask = uploadBytesResumable(storageRef, file, {
      contentType: file.type,
      customMetadata: {
        uploadedBy: 'admin',
        category: folder
      }
    });

    uploadTask.on(
      'state_changed',
      (snapshot) => {
        if (typeof onProgress === 'function' && snapshot.totalBytes > 0) {
          const percent = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
          onProgress(percent);
        }
      },
      (error) => {
        const code = error?.code || '';
        if (code === 'storage/unauthorized') {
          reject(new Error('Permission denied by Storage Security Rules. Confirm you are signed in as the administrator.'));
        } else {
          reject(new Error(error?.message || 'Image upload failed.'));
        }
      },
      () => {
        resolve(storagePath);
      }
    );
  });
}

// In-memory cache for public product image download URLs to avoid redundant lookups
const publicUrlCache = new Map();

/**
 * Resolves a public download URL for a product image path.
 * Only permitted for `products/...` paths.
 */
export async function getPublicProductImageUrl(storagePath) {
  assertFirebaseConfigured();
  if (!storagePath || typeof storagePath !== 'string') return null;
  if (!storagePath.startsWith('products/')) {
    throw new Error('Public download URLs can only be requested for product catalogue images.');
  }
  if (publicUrlCache.has(storagePath)) {
    return publicUrlCache.get(storagePath);
  }
  const fileRef = ref(storage, storagePath);
  const url = await getDownloadURL(fileRef);
  publicUrlCache.set(storagePath, url);
  return url;
}

/**
 * Retrieves a private repair photograph via authenticated Storage SDK download (`getBlob`)
 * and returns a temporary local `blob:` Object URL along with a revoke callback.
 * Never generates a persistent public token URL.
 */
export async function getPrivateRepairPhotoObjectUrl(storagePath) {
  assertFirebaseConfigured();
  if (!storagePath || typeof storagePath !== 'string') {
    throw new Error('Invalid repair photo storage path.');
  }
  const fileRef = ref(storage, storagePath);
  const blob = await getBlob(fileRef);
  const objectUrl = URL.createObjectURL(blob);
  return {
    objectUrl,
    revoke: () => URL.revokeObjectURL(objectUrl)
  };
}

/**
 * Deletes a file from Firebase Cloud Storage by its canonical Storage path.
 */
export async function deleteStorageFile(storagePath) {
  assertFirebaseConfigured();
  if (!storagePath) return;
  try {
    const fileRef = ref(storage, storagePath);
    await deleteObject(fileRef);
    publicUrlCache.delete(storagePath);
  } catch (err) {
    // Ignore object-not-found during cleanup
    if (err?.code !== 'storage/object-not-found') {
      throw err;
    }
  }
}
