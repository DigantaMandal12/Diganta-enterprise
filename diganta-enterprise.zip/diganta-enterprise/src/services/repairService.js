/**
 * Private Repair Record Management Service (Administrator Only).
 */

import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp
} from 'firebase/firestore';
import { db, assertFirebaseConfigured } from './firebase.js';
import { deleteStorageFile } from './storageService.js';
import { listPaymentsForRepair, deletePaymentRecord } from './paymentService.js';

const REPAIRS_COLLECTION = 'repairs';

function normalizeRepairDoc(snapshot) {
  if (!snapshot.exists()) return null;
  const d = snapshot.data();
  return {
    id: snapshot.id,
    createdAt: d.createdAt || null,
    updatedAt: d.updatedAt || null,
    repairDate: d.repairDate || '',
    completedAt: d.completedAt || null,
    deliveredAt: d.deliveredAt || null,
    customerName: d.customerName || '',
    customerPhone: d.customerPhone || '',
    equipmentBrand: d.equipmentBrand || '',
    equipmentModel: d.equipmentModel || '',
    equipmentCapacity: d.equipmentCapacity || '',
    serialNumber: d.serialNumber || '',
    reportedFault: d.reportedFault || '',
    diagnosis: d.diagnosis || '',
    workPerformed: d.workPerformed || '',
    partsUsed: Array.isArray(d.partsUsed) ? d.partsUsed : [],
    labourAllocationPaise: Number(d.labourAllocationPaise ?? 0),
    travelExpensePaise: Number(d.travelExpensePaise ?? 0),
    otherDirectExpensesPaise: Number(d.otherDirectExpensesPaise ?? 0),
    quotedAmountPaise: d.quotedAmountPaise ?? null,
    finalAmountChargedPaise: d.finalAmountChargedPaise ?? null,
    status: d.status || 'Received',
    warrantyDetails: d.warrantyDetails || '',
    notes: d.notes || '',
    repairPhotoPaths: Array.isArray(d.repairPhotoPaths) ? d.repairPhotoPaths : []
  };
}

/**
 * Generates a new unique Firestore document ID for a repair before uploading private photos.
 */
export function generateNewRepairId() {
  assertFirebaseConfigured();
  return doc(collection(db, REPAIRS_COLLECTION)).id;
}

/**
 * Lists all repair records for the administrator, optionally filtered by status.
 */
export async function listRepairsAdmin({ statusFilter = 'ALL' } = {}) {
  assertFirebaseConfigured();
  let q;
  if (statusFilter && statusFilter !== 'ALL') {
    q = query(
      collection(db, REPAIRS_COLLECTION),
      where('status', '==', statusFilter),
      orderBy('repairDate', 'desc')
    );
  } else {
    q = query(collection(db, REPAIRS_COLLECTION), orderBy('repairDate', 'desc'));
  }
  const snap = await getDocs(q);
  return snap.docs.map(normalizeRepairDoc);
}

/**
 * Gets a single repair record by ID.
 */
export async function getRepairByIdAdmin(repairId) {
  assertFirebaseConfigured();
  if (!repairId) return null;
  const snap = await getDoc(doc(db, REPAIRS_COLLECTION, repairId));
  return normalizeRepairDoc(snap);
}

/**
 * Creates a new repair record with a known document ID.
 */
export async function createRepairRecord(repairId, sanitizedRepair, repairPhotoPaths = []) {
  assertFirebaseConfigured();
  const docRef = doc(db, REPAIRS_COLLECTION, repairId);
  await setDoc(docRef, {
    ...sanitizedRepair,
    repairPhotoPaths,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });
  return repairId;
}

/**
 * Updates an existing repair record.
 */
export async function updateRepairRecord(repairId, sanitizedRepair, repairPhotoPaths = []) {
  assertFirebaseConfigured();
  const docRef = doc(db, REPAIRS_COLLECTION, repairId);
  await updateDoc(docRef, {
    ...sanitizedRepair,
    repairPhotoPaths,
    updatedAt: serverTimestamp()
  });
}

/**
 * Deletes a repair record along with its nested payment entries and private Storage photos.
 */
export async function deleteRepairRecordCompletely(repair) {
  assertFirebaseConfigured();
  if (!repair?.id) return;

  // 1. Delete private repair photos from Storage
  const photoPaths = Array.isArray(repair.repairPhotoPaths) ? repair.repairPhotoPaths : [];
  for (const path of photoPaths) {
    try {
      await deleteStorageFile(path);
    } catch (err) {
      console.warn('Could not delete private repair photo:', path, err);
    }
  }

  // 2. Delete nested payment subcollection documents
  const payments = await listPaymentsForRepair(repair.id);
  for (const payment of payments) {
    await deletePaymentRecord(repair.id, payment.id);
  }

  // 3. Delete the repair document itself
  await deleteDoc(doc(db, REPAIRS_COLLECTION, repair.id));
}
