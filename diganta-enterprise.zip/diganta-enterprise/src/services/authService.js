/**
 * Single-Administrator Authentication & Allowlist Verification Service.
 *
 * Security model:
 * - No public sign-up or registration route exists.
 * - Authentication is only step 1; step 2 checks `admins/{uid}` in Firestore where `role == "admin"`.
 * - Firestore and Storage security rules independently enforce the exact same allowlist check.
 */

import {
  signInWithEmailAndPassword,
  signOut,
  onAuthStateChanged
} from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { auth, db, assertFirebaseConfigured } from './firebase.js';

/**
 * Checks whether the given UID exists in `admins/{uid}` with `role === "admin"`.
 */
export async function checkIsAdminUser(uid) {
  assertFirebaseConfigured();
  if (!uid) return false;
  try {
    const adminDocRef = doc(db, 'admins', uid);
    const snapshot = await getDoc(adminDocRef);
    return snapshot.exists() && snapshot.data()?.role === 'admin';
  } catch (err) {
    console.error('Failed to verify administrator allowlist record:', err);
    return false;
  }
}

/**
 * Signs in with email and password, and verifies that the user is on the administrator allowlist.
 */
export async function loginAdmin(email, password) {
  assertFirebaseConfigured();
  const trimmedEmail = (email || '').trim();
  if (!trimmedEmail || !password) {
    throw new Error('Enter both administrator email and password.');
  }

  try {
    const credential = await signInWithEmailAndPassword(auth, trimmedEmail, password);
    const isAdmin = await checkIsAdminUser(credential.user.uid);
    return {
      user: credential.user,
      isAdmin
    };
  } catch (err) {
    const code = err?.code || '';
    if (
      code === 'auth/invalid-credential' ||
      code === 'auth/wrong-password' ||
      code === 'auth/user-not-found' ||
      code === 'auth/invalid-email'
    ) {
      throw new Error('Invalid administrator email or password.');
    }
    if (code === 'auth/too-many-requests') {
      throw new Error('Too many failed sign-in attempts. Please wait a few minutes and try again.');
    }
    throw new Error(err?.message || 'Unable to sign in. Check your network connection and try again.');
  }
}

/**
 * Signs out the current user.
 */
export async function logoutAdmin() {
  if (!auth) return;
  await signOut(auth);
}

/**
 * Subscribes to Firebase Authentication state changes.
 */
export function subscribeToAuthChanges(callback) {
  if (!auth) {
    callback(null);
    return () => {};
  }
  return onAuthStateChanged(auth, callback);
}
