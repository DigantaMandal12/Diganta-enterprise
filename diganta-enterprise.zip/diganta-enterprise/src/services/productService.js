/**
 * Product Catalogue & Admin Product Management Service.
 *
 * Security rule compliance:
 * - Every public product query explicitly includes `where('isPublished', '==', true)`
 *   because Firestore Security Rules are not filters and reject unscoped public reads.
 */

import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  serverTimestamp
} from 'firebase/firestore';
import { db, assertFirebaseConfigured } from './firebase.js';
import { deleteStorageFile } from './storageService.js';

const PRODUCTS_COLLECTION = 'products';

function normalizeProductDoc(snapshot) {
  if (!snapshot.exists()) return null;
  const data = snapshot.data();
  return {
    id: snapshot.id,
    name: data.name || '',
    brand: data.brand || '',
    model: data.model || '',
    scaleType: data.scaleType || '',
    maximumCapacityValue: data.maximumCapacityValue ?? null,
    maximumCapacityUnit: data.maximumCapacityUnit || 'kg',
    readabilityValue: data.readabilityValue ?? null,
    readabilityUnit: data.readabilityUnit || 'g',
    platformDimensions: data.platformDimensions || '',
    powerSupply: data.powerSupply || '',
    specifications: data.specifications || '',
    description: data.description || '',
    imagePaths: Array.isArray(data.imagePaths) ? data.imagePaths : [],
    mainImagePath: data.mainImagePath || '',
    pricingMode: data.pricingMode || 'request',
    displayPricePaise: data.displayPricePaise ?? null,
    availabilityStatus: data.availabilityStatus || 'unknown',
    isPublished: Boolean(data.isPublished),
    createdAt: data.createdAt || null,
    updatedAt: data.updatedAt || null
  };
}

/**
 * Lists all published products for the public catalogue.
 */
export async function listPublishedProducts() {
  assertFirebaseConfigured();
  const q = query(
    collection(db, PRODUCTS_COLLECTION),
    where('isPublished', '==', true),
    orderBy('name', 'asc')
  );
  const snap = await getDocs(q);
  return snap.docs.map(normalizeProductDoc);
}

/**
 * Fetches a single product by ID.
 * Note: For unauthenticated users, Firestore rules only allow reading if `isPublished == true`.
 */
export async function getProductById(productId) {
  assertFirebaseConfigured();
  if (!productId) return null;
  const docRef = doc(db, PRODUCTS_COLLECTION, productId);
  const snap = await getDoc(docRef);
  return normalizeProductDoc(snap);
}

/**
 * Lists all products (both published and unpublished) for the administrator.
 */
export async function listAllProductsAdmin() {
  assertFirebaseConfigured();
  const q = query(collection(db, PRODUCTS_COLLECTION), orderBy('name', 'asc'));
  const snap = await getDocs(q);
  return snap.docs.map(normalizeProductDoc);
}

/**
 * Generates a new Firestore document reference with a known unique ID before uploading images.
 */
export function generateNewProductId() {
  assertFirebaseConfigured();
  return doc(collection(db, PRODUCTS_COLLECTION)).id;
}

/**
 * Creates a new product document using the specified productId.
 */
export async function createProduct(productId, sanitizedData, imagePaths = [], mainImagePath = '') {
  assertFirebaseConfigured();
  const docRef = doc(db, PRODUCTS_COLLECTION, productId);
  const effectiveMainImage = mainImagePath || (imagePaths.length > 0 ? imagePaths[0] : '');

  const payload = {
    ...sanitizedData,
    imagePaths,
    mainImagePath: effectiveMainImage,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  };

  await setDoc(docRef, payload);
  return productId;
}

/**
 * Updates an existing product document.
 */
export async function updateProduct(productId, sanitizedData, imagePaths = [], mainImagePath = '') {
  assertFirebaseConfigured();
  const docRef = doc(db, PRODUCTS_COLLECTION, productId);
  const effectiveMainImage =
    mainImagePath && imagePaths.includes(mainImagePath)
      ? mainImagePath
      : imagePaths.length > 0
      ? imagePaths[0]
      : '';

  const payload = {
    ...sanitizedData,
    imagePaths,
    mainImagePath: effectiveMainImage,
    updatedAt: serverTimestamp()
  };

  await updateDoc(docRef, payload);
}

/**
 * Toggles the publication status of a product after verifying minimum required fields.
 */
export async function setProductPublicationStatus(product, isPublished) {
  assertFirebaseConfigured();
  if (
    isPublished &&
    (!product.name ||
      !product.scaleType ||
      (!product.description && !product.specifications && !product.maximumCapacityValue))
  ) {
    throw new Error(
      'Cannot publish product: ensure it has a name, scale type, and description, specification, or capacity.'
    );
  }
  const docRef = doc(db, PRODUCTS_COLLECTION, product.id);
  await updateDoc(docRef, {
    isPublished: Boolean(isPublished),
    updatedAt: serverTimestamp()
  });
}

/**
 * Deletes a product record and cleans up its associated product images from Storage.
 */
export async function deleteProductAndImages(product) {
  assertFirebaseConfigured();
  if (!product?.id) return;

  const paths = Array.isArray(product.imagePaths) ? product.imagePaths : [];
  for (const path of paths) {
    try {
      await deleteStorageFile(path);
    } catch (err) {
      console.warn('Could not delete product image during product removal:', path, err);
    }
  }

  await deleteDoc(doc(db, PRODUCTS_COLLECTION, product.id));
}
