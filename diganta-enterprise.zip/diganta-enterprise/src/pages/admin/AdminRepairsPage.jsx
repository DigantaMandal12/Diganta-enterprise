import React, { useEffect, useMemo, useState } from 'react';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import { listRepairsAdmin } from '../../services/repairService.js';
import { listPaymentsMapForRepairs } from '../../services/paymentService.js';
import { calculateRepairFinancials, formatPaiseToINR } from '../../utils/currency.js';
import { formatDate } from '../../utils/dates.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import Button from '../../components/common/Button.jsx';
import StatusBadge from '../../components/common/StatusBadge.jsx';
import Pagination from '../../components/common/Pagination.jsx';
import { LoadingState, ErrorState, EmptyState } from '../../components/common/StateFeedback.jsx';

const PAGE_SIZE = 10;

export default function AdminRepairsPage() {
  useDocumentTitle('Repair Management');

  const [repairs, setRepairs] = useState([]);
  const [paymentsByRepairId, setPaymentsByRepairId] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  const loadRepairs = async () => {
    setLoading(true);
    setError(null);
    try {
      const list = await listRepairsAdmin({ statusFilter });
      const paymentsMap = await listPaymentsMapForRepairs(list);
      setRepairs(list);
      setPaymentsByRepairId(paymentsMap);
    } catch (err) {
      setError(err?.message || 'Could not load repair records.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRepairs();
  }, [statusFilter]);

  const filteredRepairs = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return repairs.filter((r) => {
      if (startDate && r.repairDate < startDate) return false;
      if (endDate && r.repairDate > endDate) return false;
      if (!q) return true;
      const haystack = [
        r.id,
        r.customerName,
        r.customerPhone,
        r.equipmentBrand,
        r.equipmentModel,
        r.equipmentCapacity,
        r.serialNumber,
        r.reportedFault
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return haystack.includes(q);
    });
  }, [repairs, searchQuery, startDate, endDate]);

  // Complete totals across ALL matching filtered records (never just the current page)
  const filteredTotals = useMemo(() => {
    let totalCostPaise = 0;
    let totalChargedPaise = 0;
    let totalNetCollectedPaise = 0;
    let totalOutstandingPaise = 0;

    filteredRepairs.forEach((r) => {
      const fin = calculateRepairFinancials(r, paymentsByRepairId[r.id] || []);
      totalCostPaise += fin.totalCostPaise;
      if (fin.finalAmountChargedPaise !== null) {
        totalChargedPaise += fin.finalAmountChargedPaise;
      }
      totalNetCollectedPaise += fin.netCollectedPaise;
      totalOutstandingPaise += fin.outstandingBalancePaise;
    });

    return {
      totalCostPaise,
      totalChargedPaise,
      totalNetCollectedPaise,
      totalOutstandingPaise
    };
  }, [filteredRepairs, paymentsByRepairId]);

  const paginatedRepairs = useMemo(() => {
    const start = (currentPage - 1) * PAGE_SIZE;
    return filteredRepairs.slice(start, start + PAGE_SIZE);
  }, [filteredRepairs, currentPage]);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, statusFilter, startDate, endDate]);

  return (
    <div>
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: '1rem',
          marginBottom: '1.25rem'
        }}
      >
        <div>
          <h1 style={{ margin: 0, color: 'var(--color-navy)', fontSize: '1.6rem' }}>
            Repair Management
          </h1>
          <p style={{ margin: '0.25rem 0 0 0', color: 'var(--color-text-muted)', fontSize: '0.92rem' }}>
            Track weighing-scale repair jobs, structured parts, direct costs, customer payments, and private repair photos.
          </p>
        </div>
        <Button variant="primary" to="/admin/repairs/new">
          + Create Repair Record
        </Button>
      </div>

      {/* Filters */}
      <div className="card" style={{ marginBottom: '1.25rem' }}>
        <div className="grid-4" style={{ alignItems: 'end' }}>
          <div>
            <label htmlFor="repair-search" className="form-label">
              Search Customer, Phone, ID, or Scale
            </label>
            <input
              id="repair-search"
              type="search"
              className="form-input"
              placeholder="Name, phone, serial, or ID…"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <div>
            <label htmlFor="repair-status-filter" className="form-label">
              Repair Status
            </label>
            <select
              id="repair-status-filter"
              className="form-select"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="ALL">All Statuses</option>
              {BUSINESS_INFO.repairStatuses.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="repair-from-date" className="form-label">
              Intake Date From
            </label>
            <input
              id="repair-from-date"
              type="date"
              className="form-input"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
            />
          </div>

          <div>
            <label htmlFor="repair-to-date" className="form-label">
              Intake Date To
            </label>
            <input
              id="repair-to-date"
              type="date"
              className="form-input"
              value={endDate}
              onChange={(e) => setEndDate(e.target.value)}
            />
          </div>
        </div>
      </div>

      {/* Summary bar across all matching filtered repairs */}
      {!loading && !error && filteredRepairs.length > 0 && (
        <div className="card" style={{ marginBottom: '1.25rem', backgroundColor: '#F8FAFC' }}>
          <div style={{ fontSize: '0.82rem', fontWeight: 700, color: 'var(--color-text-muted)', marginBottom: '0.4rem' }}>
            Totals across all {filteredRepairs.length} matching repair record(s) (not limited to current page):
          </div>
          <div className="grid-4">
            <div>
              <span style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)' }}>Direct Cost: </span>
              <strong>{formatPaiseToINR(filteredTotals.totalCostPaise)}</strong>
            </div>
            <div>
              <span style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)' }}>Total Charged: </span>
              <strong>{formatPaiseToINR(filteredTotals.totalChargedPaise)}</strong>
            </div>
            <div>
              <span style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)' }}>Net Collected: </span>
              <strong style={{ color: 'var(--color-success-text)' }}>
                {formatPaiseToINR(filteredTotals.totalNetCollectedPaise)}
              </strong>
            </div>
            <div>
              <span style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)' }}>Outstanding: </span>
              <strong style={{ color: 'var(--color-warning-text)' }}>
                {formatPaiseToINR(filteredTotals.totalOutstandingPaise)}
              </strong>
            </div>
          </div>
        </div>
      )}

      {loading && <LoadingState message="Loading repair records…" />}
      {!loading && error && <ErrorState message={error} onRetry={loadRepairs} />}

      {!loading && !error && filteredRepairs.length === 0 && (
        <EmptyState
          title="No matching repair records"
          description="Create a new repair record or adjust your search and status filters."
          actionLabel="Create Repair Record"
          actionTo="/admin/repairs/new"
        />
      )}

      {!loading && !error && filteredRepairs.length > 0 && (
        <div className="card">
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Repair ID</th>
                  <th>Intake Date</th>
                  <th>Customer</th>
                  <th>Scale &amp; Fault</th>
                  <th>Status</th>
                  <th>Direct Cost</th>
                  <th>Charged</th>
                  <th>Net Collected</th>
                  <th>Balance / Payment</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {paginatedRepairs.map((repair) => {
                  const fin = calculateRepairFinancials(
                    repair,
                    paymentsByRepairId[repair.id] || []
                  );
                  return (
                    <tr key={repair.id}>
                      <td>
                        <code>{repair.id}</code>
                      </td>
                      <td>{formatDate(repair.repairDate)}</td>
                      <td>
                        <strong>{repair.customerName}</strong>
                        <div style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)' }}>
                          {repair.customerPhone}
                        </div>
                      </td>
                      <td>
                        <div style={{ fontWeight: 600 }}>
                          {[repair.equipmentBrand, repair.equipmentModel, repair.equipmentCapacity]
                            .filter(Boolean)
                            .join(' • ') || 'Weighing Scale'}
                        </div>
                        <div style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)' }}>
                          {repair.reportedFault.slice(0, 70)}
                          {repair.reportedFault.length > 70 ? '…' : ''}
                        </div>
                      </td>
                      <td>
                        <StatusBadge status={repair.status} />
                      </td>
                      <td>{formatPaiseToINR(fin.totalCostPaise)}</td>
                      <td>{formatPaiseToINR(fin.finalAmountChargedPaise)}</td>
                      <td>{formatPaiseToINR(fin.netCollectedPaise)}</td>
                      <td>
                        <div>
                          <StatusBadge status={fin.paymentStatus} />
                        </div>
                        {fin.outstandingBalancePaise > 0 && (
                          <div style={{ fontSize: '0.8rem', color: 'var(--color-error-text)', marginTop: '0.2rem', fontWeight: 700 }}>
                            Due: {formatPaiseToINR(fin.outstandingBalancePaise)}
                          </div>
                        )}
                        {fin.overpaymentCreditPaise > 0 && (
                          <div style={{ fontSize: '0.8rem', color: 'var(--color-warning-text)', marginTop: '0.2rem', fontWeight: 700 }}>
                            Credit: {formatPaiseToINR(fin.overpaymentCreditPaise)}
                          </div>
                        )}
                      </td>
                      <td>
                        <Button variant="secondary" size="sm" to={`/admin/repairs/${repair.id}`}>
                          Details / Edit
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <Pagination
            currentPage={currentPage}
            totalItems={filteredRepairs.length}
            pageSize={PAGE_SIZE}
            onPageChange={setCurrentPage}
          />
        </div>
      )}
    </div>
  );
}
