import React, { useEffect, useMemo, useState } from 'react';
import {
  listAllProductsAdmin,
  setProductPublicationStatus,
  deleteProductAndImages
} from '../../services/productService.js';
import { formatPaiseToINR } from '../../utils/currency.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import Button from '../../components/common/Button.jsx';
import StatusBadge, { formatAvailabilityLabel } from '../../components/common/StatusBadge.jsx';
import ConfirmDialog from '../../components/common/ConfirmDialog.jsx';
import { LoadingState, ErrorState, EmptyState } from '../../components/common/StateFeedback.jsx';

export default function AdminProductsPage() {
  useDocumentTitle('Product Catalogue Management');

  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [actionError, setActionError] = useState(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [publishFilter, setPublishFilter] = useState('ALL');
  const [productToDelete, setProductToDelete] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const loadProducts = async () => {
    setLoading(true);
    setError(null);
    try {
      const list = await listAllProductsAdmin();
      setProducts(list);
    } catch (err) {
      setError(err?.message || 'Could not load products.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const filteredProducts = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return products.filter((p) => {
      if (publishFilter === 'PUBLISHED' && !p.isPublished) return false;
      if (publishFilter === 'UNPUBLISHED' && p.isPublished) return false;
      if (!q) return true;
      const hay = [p.name, p.brand, p.model, p.scaleType, p.id].filter(Boolean).join(' ').toLowerCase();
      return hay.includes(q);
    });
  }, [products, searchQuery, publishFilter]);

  const handleTogglePublish = async (product) => {
    setActionError(null);
    try {
      await setProductPublicationStatus(product, !product.isPublished);
      await loadProducts();
    } catch (err) {
      setActionError(err?.message || 'Could not change publication status.');
    }
  };

  const handleConfirmDelete = async () => {
    if (!productToDelete || isDeleting) return;
    setIsDeleting(true);
    setActionError(null);
    try {
      await deleteProductAndImages(productToDelete);
      setProductToDelete(null);
      await loadProducts();
    } catch (err) {
      setActionError(err?.message || 'Could not delete product.');
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div>
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: '1rem',
          marginBottom: '1.25rem'
        }}
      >
        <div>
          <h1 style={{ margin: 0, color: 'var(--color-navy)', fontSize: '1.6rem' }}>
            Product Catalogue Management
          </h1>
          <p style={{ margin: '0.25rem 0 0 0', color: 'var(--color-text-muted)', fontSize: '0.92rem' }}>
            Create, edit, publish, or hide weighing scales without losing past customer enquiries.
          </p>
        </div>
        <Button variant="primary" to="/admin/products/new">
          + Add New Product
        </Button>
      </div>

      {actionError && <div className="alert alert-error">{actionError}</div>}

      <div className="card" style={{ marginBottom: '1.25rem' }}>
        <div className="grid-2">
          <div>
            <label htmlFor="admin-product-search" className="form-label">
              Search Products
            </label>
            <input
              id="admin-product-search"
              type="search"
              className="form-input"
              placeholder="Search by name, brand, model, or ID…"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="admin-publish-filter" className="form-label">
              Publication Status
            </label>
            <select
              id="admin-publish-filter"
              className="form-select"
              value={publishFilter}
              onChange={(e) => setPublishFilter(e.target.value)}
            >
              <option value="ALL">All Products ({products.length})</option>
              <option value="PUBLISHED">Published Only</option>
              <option value="UNPUBLISHED">Hidden / Draft Only</option>
            </select>
          </div>
        </div>
      </div>

      {loading && <LoadingState message="Loading product catalogue…" />}
      {!loading && error && <ErrorState message={error} onRetry={loadProducts} />}

      {!loading && !error && filteredProducts.length === 0 && (
        <EmptyState
          title="No products found"
          description="Add a weighing scale product to display it in your catalogue."
          actionLabel="Create First Product"
          actionTo="/admin/products/new"
        />
      )}

      {!loading && !error && filteredProducts.length > 0 && (
        <div className="card">
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Name &amp; Brand</th>
                  <th>Scale Type</th>
                  <th>Capacity</th>
                  <th>Pricing</th>
                  <th>Availability</th>
                  <th>Photos</th>
                  <th>Catalogue Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.map((p) => (
                  <tr key={p.id}>
                    <td>
                      <strong>{p.name}</strong>
                      <div style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>
                        {[p.brand, p.model].filter(Boolean).join(' • ') || `ID: ${p.id.slice(0, 8)}`}
                      </div>
                    </td>
                    <td>{p.scaleType}</td>
                    <td>
                      {p.maximumCapacityValue
                        ? `${p.maximumCapacityValue} ${p.maximumCapacityUnit || 'kg'}`
                        : '—'}
                    </td>
                    <td>
                      {p.pricingMode === 'fixed' && p.displayPricePaise
                        ? formatPaiseToINR(p.displayPricePaise)
                        : 'Request Price'}
                    </td>
                    <td>
                      <StatusBadge
                        status={p.availabilityStatus}
                        label={formatAvailabilityLabel(p.availabilityStatus)}
                      />
                    </td>
                    <td>{(p.imagePaths || []).length}</td>
                    <td>
                      <span className={`badge ${p.isPublished ? 'badge-success' : 'badge-neutral'}`}>
                        {p.isPublished ? 'Published' : 'Unpublished (Hidden)'}
                      </span>
                    </td>
                    <td>
                      <div className="cta-row">
                        <Button variant="secondary" size="sm" to={`/admin/products/${p.id}/edit`}>
                          Edit
                        </Button>
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => handleTogglePublish(p)}
                        >
                          {p.isPublished ? 'Unpublish' : 'Publish'}
                        </Button>
                        <Button
                          variant="danger"
                          size="sm"
                          onClick={() => setProductToDelete(p)}
                        >
                          Delete
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <ConfirmDialog
        isOpen={Boolean(productToDelete)}
        title="Delete Product from Catalogue?"
        message={
          productToDelete
            ? `Are you sure you want to permanently delete "${productToDelete.name}" and its uploaded product photographs? If you only want to hide it from the public website while keeping the product record, click Cancel and use "Unpublish" instead. Existing enquiries will keep their product snapshot.`
            : ''
        }
        confirmLabel="Delete Product"
        isProcessing={isDeleting}
        onConfirm={handleConfirmDelete}
        onCancel={() => setProductToDelete(null)}
      />
    </div>
  );
}
