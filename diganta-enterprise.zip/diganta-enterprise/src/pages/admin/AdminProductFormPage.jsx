import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import {
  generateNewProductId,
  getProductById,
  createProduct,
  updateProduct
} from '../../services/productService.js';
import {
  uploadStorageImage,
  getPublicProductImageUrl,
  deleteStorageFile
} from '../../services/storageService.js';
import { paiseToRupeesInput } from '../../utils/currency.js';
import { validateProductForm } from '../../utils/validation.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import FormField from '../../components/forms/FormField.jsx';
import Button from '../../components/common/Button.jsx';
import { LoadingState, ErrorState } from '../../components/common/StateFeedback.jsx';

export default function AdminProductFormPage() {
  const { productId } = useParams();
  const isEditMode = Boolean(productId);
  const navigate = useNavigate();

  useDocumentTitle(isEditMode ? 'Edit Product' : 'Create Product');

  const [effectiveProductId, setEffectiveProductId] = useState(productId || '');
  const [loading, setLoading] = useState(isEditMode);
  const [loadError, setLoadError] = useState(null);

  const [formData, setFormData] = useState({
    name: '',
    brand: '',
    model: '',
    scaleType: 'Tabletop Scale',
    maximumCapacityValue: '',
    maximumCapacityUnit: 'kg',
    readabilityValue: '',
    readabilityUnit: 'g',
    platformDimensions: '',
    powerSupply: '',
    specifications: '',
    description: '',
    pricingMode: 'request',
    displayPriceRupees: '',
    availabilityStatus: 'available',
    isPublished: false
  });

  const [imagePaths, setImagePaths] = useState([]);
  const [mainImagePath, setMainImagePath] = useState('');
  const [previewUrlsByPath, setPreviewUrlsByPath] = useState({});
  const [newlyUploadedPaths, setNewlyUploadedPaths] = useState([]);

  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState(null);

  const [fieldErrors, setFieldErrors] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [saveError, setSaveError] = useState(null);
  const [saveSuccess, setSaveSuccess] = useState(null);

  useEffect(() => {
    if (!isEditMode) {
      try {
        setEffectiveProductId(generateNewProductId());
      } catch {
        setEffectiveProductId('');
      }
      return;
    }

    let active = true;
    setLoading(true);
    setLoadError(null);

    getProductById(productId)
      .then((item) => {
        if (!active) return;
        if (!item) {
          setLoadError('Product not found.');
          setLoading(false);
          return;
        }
        setEffectiveProductId(item.id);
        setFormData({
          name: item.name || '',
          brand: item.brand || '',
          model: item.model || '',
          scaleType: item.scaleType || 'Tabletop Scale',
          maximumCapacityValue: item.maximumCapacityValue ?? '',
          maximumCapacityUnit: item.maximumCapacityUnit || 'kg',
          readabilityValue: item.readabilityValue ?? '',
          readabilityUnit: item.readabilityUnit || 'g',
          platformDimensions: item.platformDimensions || '',
          powerSupply: item.powerSupply || '',
          specifications: item.specifications || '',
          description: item.description || '',
          pricingMode: item.pricingMode || 'request',
          displayPriceRupees: paiseToRupeesInput(item.displayPricePaise),
          availabilityStatus: item.availabilityStatus || 'unknown',
          isPublished: Boolean(item.isPublished)
        });
        setImagePaths(item.imagePaths || []);
        setMainImagePath(item.mainImagePath || (item.imagePaths?.[0] ?? ''));
        setLoading(false);
      })
      .catch((err) => {
        if (!active) return;
        setLoadError(err?.message || 'Failed to load product.');
        setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [isEditMode, productId]);

  useEffect(() => {
    let active = true;
    Promise.all(
      imagePaths.map(async (p) => {
        try {
          const url = await getPublicProductImageUrl(p);
          return [p, url];
        } catch {
          return [p, null];
        }
      })
    ).then((pairs) => {
      if (!active) return;
      setPreviewUrlsByPath(Object.fromEntries(pairs));
    });
    return () => {
      active = false;
    };
  }, [imagePaths]);

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setSaveSuccess(null);
  };

  const handleImageUpload = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    if (imagePaths.length >= 10) {
      setUploadError('Maximum 10 photographs allowed per product.');
      return;
    }

    setUploadError(null);
    setUploading(true);
    setUploadProgress(0);

    try {
      const targetId = effectiveProductId || generateNewProductId();
      if (!effectiveProductId) setEffectiveProductId(targetId);

      const path = await uploadStorageImage({
        folder: 'products',
        recordId: targetId,
        file,
        onProgress: setUploadProgress
      });

      const nextPaths = [...imagePaths, path];
      const nextMain = mainImagePath || path;
      setImagePaths(nextPaths);
      setMainImagePath(nextMain);
      setNewlyUploadedPaths((prev) => [...prev, path]);
    } catch (err) {
      setUploadError(err?.message || 'Product image upload failed.');
    } finally {
      setUploading(false);
    }
  };

  const handleReplaceImage = async (oldPath, e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setUploadError(null);
    setUploading(true);
    setUploadProgress(0);

    try {
      const targetId = effectiveProductId || generateNewProductId();
      if (!effectiveProductId) setEffectiveProductId(targetId);

      const newPath = await uploadStorageImage({
        folder: 'products',
        recordId: targetId,
        file,
        onProgress: setUploadProgress
      });

      await deleteStorageFile(oldPath);
      const nextPaths = imagePaths.map((p) => (p === oldPath ? newPath : p));
      setImagePaths(nextPaths);
      if (mainImagePath === oldPath) {
        setMainImagePath(newPath);
      }
      setNewlyUploadedPaths((prev) => [...prev.filter((p) => p !== oldPath), newPath]);
    } catch (err) {
      setUploadError(err?.message || 'Failed to replace product image.');
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveImage = async (pathToRemove) => {
    setUploadError(null);
    try {
      await deleteStorageFile(pathToRemove);
      const nextPaths = imagePaths.filter((p) => p !== pathToRemove);
      setImagePaths(nextPaths);
      if (mainImagePath === pathToRemove) {
        setMainImagePath(nextPaths[0] || '');
      }
    } catch (err) {
      setUploadError(err?.message || 'Could not remove image.');
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSaving) return;

    setSaveError(null);
    setSaveSuccess(null);

    const validation = validateProductForm(formData);
    if (!validation.isValid) {
      setFieldErrors(validation.errors);
      setSaveError('Please correct the highlighted fields.');
      return;
    }

    setFieldErrors({});
    setIsSaving(true);

    const targetId = effectiveProductId || generateNewProductId();
    try {
      if (isEditMode) {
        await updateProduct(targetId, validation.sanitized, imagePaths, mainImagePath);
        setNewlyUploadedPaths([]);
        setSaveSuccess('Product updated.');
      } else {
        await createProduct(targetId, validation.sanitized, imagePaths, mainImagePath);
        setNewlyUploadedPaths([]);
        navigate('/admin/products');
      }
    } catch (err) {
      if (!isEditMode && newlyUploadedPaths.length > 0) {
        for (const orphan of newlyUploadedPaths) {
          try {
            await deleteStorageFile(orphan);
          } catch {
            // ignore
          }
        }
        setImagePaths((prev) => prev.filter((p) => !newlyUploadedPaths.includes(p)));
        setNewlyUploadedPaths([]);
      }
      setSaveError(err?.message || 'Failed to save product.');
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) {
    return <LoadingState message="Loading product record…" />;
  }

  if (loadError) {
    return <ErrorState title="Could not load product" message={loadError} />;
  }

  return (
    <div>
      <div style={{ marginBottom: '1rem' }}>
        <Link to="/admin/products">&larr; Back to Product Management</Link>
      </div>

      <div className="card" style={{ marginBottom: '1.25rem' }}>
        <h1 style={{ margin: 0, color: 'var(--color-navy)', fontSize: '1.5rem' }}>
          {isEditMode ? `Edit Product: ${formData.name}` : 'Create New Weighing Scale Product'}
        </h1>
        <p style={{ margin: '0.25rem 0 0 0', fontSize: '0.86rem', color: 'var(--color-text-muted)' }}>
          Product ID: <code>{effectiveProductId}</code> (Only enter public catalogue data; never place private procurement costs here.)
        </p>
      </div>

      {saveSuccess && <div className="alert alert-success">{saveSuccess}</div>}
      {saveError && <div className="alert alert-error">{saveError}</div>}

      <form onSubmit={handleSubmit} noValidate>
        <div className="grid-2" style={{ marginBottom: '1.5rem' }}>
          <div className="card">
            <h2 style={{ marginTop: 0, fontSize: '1.15rem', color: 'var(--color-navy)' }}>
              Core Details &amp; Pricing
            </h2>

            <FormField id="prod-name" label="Product Name" required error={fieldErrors.name}>
              <input
                id="prod-name"
                type="text"
                className="form-input"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="e.g. Vison Tech 30 kg Tabletop Weighing Scale"
              />
            </FormField>

            <div className="grid-2">
              <FormField id="prod-brand" label="Brand">
                <input
                  id="prod-brand"
                  type="text"
                  className="form-input"
                  value={formData.brand}
                  onChange={(e) => handleChange('brand', e.target.value)}
                  placeholder="e.g. Vison Tech"
                />
              </FormField>

              <FormField id="prod-model" label="Model">
                <input
                  id="prod-model"
                  type="text"
                  className="form-input"
                  value={formData.model}
                  onChange={(e) => handleChange('model', e.target.value)}
                  placeholder="e.g. VT-30T"
                />
              </FormField>
            </div>

            <FormField id="prod-scale-type" label="Scale Type" required error={fieldErrors.scaleType}>
              <select
                id="prod-scale-type"
                className="form-select"
                value={formData.scaleType}
                onChange={(e) => handleChange('scaleType', e.target.value)}
              >
                {BUSINESS_INFO.scaleTypes.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </FormField>

            <div className="grid-2">
              <FormField id="prod-pricing-mode" label="Pricing Mode" required error={fieldErrors.pricingMode}>
                <select
                  id="prod-pricing-mode"
                  className="form-select"
                  value={formData.pricingMode}
                  onChange={(e) => handleChange('pricingMode', e.target.value)}
                >
                  {BUSINESS_INFO.pricingModes.map((pm) => (
                    <option key={pm.value} value={pm.value}>
                      {pm.label}
                    </option>
                  ))}
                </select>
              </FormField>

              <FormField
                id="prod-price"
                label="Reference Display Price (₹)"
                required={formData.pricingMode === 'fixed'}
                hint="Required only if Pricing Mode is Reference Display Price"
                error={fieldErrors.displayPriceRupees}
              >
                <input
                  id="prod-price"
                  type="text"
                  inputMode="decimal"
                  className="form-input"
                  value={formData.displayPriceRupees}
                  onChange={(e) => handleChange('displayPriceRupees', e.target.value)}
                  placeholder="e.g. 2850"
                />
              </FormField>
            </div>

            <div className="grid-2">
              <FormField id="prod-availability" label="Availability Status" required error={fieldErrors.availabilityStatus}>
                <select
                  id="prod-availability"
                  className="form-select"
                  value={formData.availabilityStatus}
                  onChange={(e) => handleChange('availabilityStatus', e.target.value)}
                >
                  {BUSINESS_INFO.availabilityStatuses.map((av) => (
                    <option key={av.value} value={av.value}>
                      {av.label}
                    </option>
                  ))}
                </select>
              </FormField>

              <div className="form-group" style={{ paddingTop: '1.6rem' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', fontWeight: 700, cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={formData.isPublished}
                    onChange={(e) => handleChange('isPublished', e.target.checked)}
                    style={{ width: '18px', height: '18px' }}
                  />
                  Publish in Public Catalogue
                </label>
              </div>
            </div>
          </div>

          <div className="card">
            <h2 style={{ marginTop: 0, fontSize: '1.15rem', color: 'var(--color-navy)' }}>
              Technical Specifications
            </h2>

            <div className="grid-2">
              <FormField
                id="prod-cap-val"
                label="Maximum Capacity Value"
                error={fieldErrors.maximumCapacityValue}
              >
                <input
                  id="prod-cap-val"
                  type="number"
                  step="any"
                  className="form-input"
                  value={formData.maximumCapacityValue}
                  onChange={(e) => handleChange('maximumCapacityValue', e.target.value)}
                  placeholder="e.g. 30, 100, 300"
                />
              </FormField>

              <FormField id="prod-cap-unit" label="Capacity Unit">
                <select
                  id="prod-cap-unit"
                  className="form-select"
                  value={formData.maximumCapacityUnit}
                  onChange={(e) => handleChange('maximumCapacityUnit', e.target.value)}
                >
                  <option value="kg">kg</option>
                  <option value="g">g</option>
                  <option value="ton">ton</option>
                </select>
              </FormField>
            </div>

            <div className="grid-2">
              <FormField
                id="prod-read-val"
                label="Readability / Division Value"
                error={fieldErrors.readabilityValue}
              >
                <input
                  id="prod-read-val"
                  type="number"
                  step="any"
                  className="form-input"
                  value={formData.readabilityValue}
                  onChange={(e) => handleChange('readabilityValue', e.target.value)}
                  placeholder="e.g. 1, 2, 5, 10, 50"
                />
              </FormField>

              <FormField id="prod-read-unit" label="Readability Unit">
                <select
                  id="prod-read-unit"
                  className="form-select"
                  value={formData.readabilityUnit}
                  onChange={(e) => handleChange('readabilityUnit', e.target.value)}
                >
                  <option value="g">g</option>
                  <option value="kg">kg</option>
                  <option value="mg">mg</option>
                </select>
              </FormField>
            </div>

            <div className="grid-2">
              <FormField id="prod-platform" label="Platform Dimensions">
                <input
                  id="prod-platform"
                  type="text"
                  className="form-input"
                  value={formData.platformDimensions}
                  onChange={(e) => handleChange('platformDimensions', e.target.value)}
                  placeholder="e.g. 400 mm × 400 mm"
                />
              </FormField>

              <FormField id="prod-power" label="Power Supply">
                <input
                  id="prod-power"
                  type="text"
                  className="form-input"
                  value={formData.powerSupply}
                  onChange={(e) => handleChange('powerSupply', e.target.value)}
                  placeholder="e.g. 230V AC + Rechargeable Battery"
                />
              </FormField>
            </div>

            <FormField id="prod-specs" label="Additional Specifications">
              <textarea
                id="prod-specs"
                className="form-textarea"
                value={formData.specifications}
                onChange={(e) => handleChange('specifications', e.target.value)}
                placeholder="Display type, pan material, tare range, etc."
              />
            </FormField>

            <FormField
              id="prod-desc"
              label="Product Description"
              error={fieldErrors.description}
            >
              <textarea
                id="prod-desc"
                className="form-textarea"
                value={formData.description}
                onChange={(e) => handleChange('description', e.target.value)}
                placeholder="Describe suitable applications (grocery, hardware, wholesale platform weighing, etc.)"
              />
            </FormField>
          </div>
        </div>

        <div className="card" style={{ marginBottom: '1.5rem' }}>
          <h2 style={{ marginTop: 0, fontSize: '1.15rem', color: 'var(--color-navy)' }}>
            Product Photographs (Public Catalogue Assets)
          </h2>
          <p style={{ fontSize: '0.86rem', color: 'var(--color-text-muted)', marginTop: 0 }}>
            Upload genuine photographs of this weighing scale (JPEG, PNG, or WebP, max 5 MiB per file).
            If no photograph is uploaded, a clean &ldquo;Product photo not added&rdquo; placeholder is shown.
          </p>

          {uploadError && <div className="alert alert-error">{uploadError}</div>}

          <div style={{ marginBottom: '1rem' }}>
            <label
              htmlFor="product-photo-upload"
              className="btn btn-secondary btn-sm"
              style={{ cursor: uploading ? 'not-allowed' : 'pointer' }}
            >
              {uploading ? `Uploading (${uploadProgress}%)…` : '+ Upload Product Photograph'}
            </label>
            <input
              id="product-photo-upload"
              type="file"
              accept="image/jpeg,image/png,image/webp"
              disabled={uploading}
              onChange={handleImageUpload}
              style={{ display: 'none' }}
            />
          </div>

          {imagePaths.length === 0 ? (
            <p style={{ color: 'var(--color-text-muted)', margin: 0 }}>
              No photographs uploaded for this product yet.
            </p>
          ) : (
            <div className="grid-4">
              {imagePaths.map((path) => {
                const isMain = mainImagePath === path;
                const url = previewUrlsByPath[path];
                return (
                  <div key={path} className="card" style={{ padding: '0.6rem' }}>
                    <div className="product-photo-box" style={{ marginBottom: '0.5rem' }}>
                      {url ? (
                        <img src={url} alt="Uploaded product preview" />
                      ) : (
                        <div className="photo-placeholder">Loading preview…</div>
                      )}
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '0.35rem', flexWrap: 'wrap' }}>
                      {isMain ? (
                        <span className="badge badge-success">Main Photo</span>
                      ) : (
                        <Button
                          variant="secondary"
                          size="sm"
                          onClick={() => setMainImagePath(path)}
                        >
                          Set as Main
                        </Button>
                      )}
                      <label
                        className="btn btn-secondary btn-sm"
                        style={{ cursor: uploading ? 'not-allowed' : 'pointer' }}
                      >
                        Replace
                        <input
                          type="file"
                          accept="image/jpeg,image/png,image/webp"
                          disabled={uploading}
                          onChange={(e) => handleReplaceImage(path, e)}
                          style={{ display: 'none' }}
                        />
                      </label>
                      <Button
                        variant="danger"
                        size="sm"
                        onClick={() => handleRemoveImage(path)}
                      >
                        Delete
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="cta-row">
          <Button type="submit" variant="primary" disabled={isSaving || uploading}>
            {isSaving
              ? 'Saving Product…'
              : isEditMode
              ? 'Save Product Changes'
              : 'Create Product'}
          </Button>
          <Button variant="secondary" to="/admin/products">
            Cancel
          </Button>
        </div>
      </form>
    </div>
  );
}
