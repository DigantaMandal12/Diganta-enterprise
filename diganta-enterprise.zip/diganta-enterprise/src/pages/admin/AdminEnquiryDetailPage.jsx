import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import {
  getEnquiryByIdAdmin,
  updateEnquiryAdmin
} from '../../services/enquiryService.js';
import {
  paiseToRupeesInput,
  rupeesToPaise,
  formatPaiseToINR
} from '../../utils/currency.js';
import { formatDateTime } from '../../utils/dates.js';
import { buildCustomerWhatsAppUrl } from '../../utils/whatsapp.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import FormField from '../../components/forms/FormField.jsx';
import Button from '../../components/common/Button.jsx';
import StatusBadge from '../../components/common/StatusBadge.jsx';
import { LoadingState, ErrorState, EmptyState } from '../../components/common/StateFeedback.jsx';

export default function AdminEnquiryDetailPage() {
  const { enquiryId } = useParams();
  useDocumentTitle(`Enquiry ${enquiryId}`);

  const [enquiry, setEnquiry] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [status, setStatus] = useState('New');
  const [quotedPriceRupees, setQuotedPriceRupees] = useState('');
  const [notes, setNotes] = useState('');

  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState(null);
  const [saveError, setSaveError] = useState(null);

  const loadEnquiry = async () => {
    setLoading(true);
    setError(null);
    try {
      const item = await getEnquiryByIdAdmin(enquiryId);
      setEnquiry(item);
      if (item) {
        setStatus(item.status || 'New');
        setQuotedPriceRupees(paiseToRupeesInput(item.quotedPricePaise));
        setNotes(item.notes || '');
      }
    } catch (err) {
      setError(err?.message || 'Could not load enquiry details.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEnquiry();
  }, [enquiryId]);

  const handleSave = async (e) => {
    e.preventDefault();
    if (isSaving || !enquiry) return;

    setSaveError(null);
    setSaveMessage(null);

    let quotedPricePaise = null;
    try {
      quotedPricePaise = rupeesToPaise(quotedPriceRupees, {
        allowNull: true,
        allowZero: false
      });
    } catch (err) {
      setSaveError(err.message);
      return;
    }

    setIsSaving(true);
    try {
      await updateEnquiryAdmin(enquiry.id, {
        status,
        quotedPricePaise,
        notes
      });
      await loadEnquiry();
      setSaveMessage('Enquiry status, quotation, and notes saved.');
    } catch (err) {
      setSaveError(err?.message || 'Failed to update enquiry.');
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) return <LoadingState message="Loading enquiry details…" />;
  if (error) return <ErrorState message={error} onRetry={loadEnquiry} />;
  if (!enquiry) {
    return (
      <EmptyState
        title="Enquiry Not Found"
        description="The requested enquiry record does not exist."
        actionLabel="Back to Enquiries"
        actionTo="/admin/enquiries"
      />
    );
  }

  const quoteLine =
    enquiry.quotedPricePaise && enquiry.quotedPricePaise > 0
      ? ` Our quoted price for ${enquiry.quantity} unit(s) is ${formatPaiseToINR(enquiry.quotedPricePaise)}.`
      : '';

  const customerWhatsappHref = buildCustomerWhatsAppUrl(
    enquiry.phone,
    `Hello ${enquiry.customerName}, thank you for your enquiry (Ref: ${enquiry.id}) for "${enquiry.productNameSnapshot}" at ${BUSINESS_INFO.name}.${quoteLine} Please let us know if you have any questions.`
  );

  const phoneDigits = String(enquiry.phone || '').replace(/[^0-9+]/g, '');

  return (
    <div>
      <div style={{ marginBottom: '1rem' }}>
        <Link to="/admin/enquiries">&larr; Back to Enquiries List</Link>
      </div>

      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '0.75rem' }}>
          <div>
            <h1 style={{ margin: 0, color: 'var(--color-navy)', fontSize: '1.5rem' }}>
              Enquiry Reference: <code>{enquiry.id}</code>
            </h1>
            <p style={{ margin: '0.25rem 0 0 0', fontSize: '0.86rem', color: 'var(--color-text-muted)' }}>
              Submitted: {formatDateTime(enquiry.createdAt)} • Last Updated:{' '}
              {formatDateTime(enquiry.updatedAt)}
            </p>
          </div>
          <StatusBadge status={enquiry.status} />
        </div>
      </div>

      {saveMessage && <div className="alert alert-success">{saveMessage}</div>}
      {saveError && <div className="alert alert-error">{saveError}</div>}

      <div className="grid-2">
        <div className="card">
          <h2 style={{ marginTop: 0, fontSize: '1.2rem', color: 'var(--color-navy)' }}>
            Customer &amp; Product Snapshot
          </h2>
          <table className="data-table" style={{ marginBottom: '1.25rem' }}>
            <tbody>
              <tr>
                <th style={{ width: '40%' }}>Customer Name</th>
                <td><strong>{enquiry.customerName}</strong></td>
              </tr>
              <tr>
                <th>Phone Number</th>
                <td>
                  <a href={`tel:${phoneDigits}`}>{enquiry.phone}</a>
                </td>
              </tr>
              <tr>
                <th>Preferred Contact</th>
                <td>{enquiry.preferredContactMethod}</td>
              </tr>
              <tr>
                <th>Selected Product</th>
                <td>
                  <strong>{enquiry.productNameSnapshot}</strong>
                  <div style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>
                    Product ID: <code>{enquiry.productId}</code>
                  </div>
                </td>
              </tr>
              {(enquiry.productBrandSnapshot || enquiry.productModelSnapshot) && (
                <tr>
                  <th>Brand / Model Snapshot</th>
                  <td>
                    {[enquiry.productBrandSnapshot, enquiry.productModelSnapshot]
                      .filter(Boolean)
                      .join(' — ')}
                  </td>
                </tr>
              )}
              {enquiry.productSpecificationsSnapshot && (
                <tr>
                  <th>Product Specs Snapshot</th>
                  <td>{enquiry.productSpecificationsSnapshot}</td>
                </tr>
              )}
              <tr>
                <th>Quantity Requested</th>
                <td><strong>{enquiry.quantity}</strong></td>
              </tr>
              {enquiry.requiredCapacity && (
                <tr>
                  <th>Required Capacity</th>
                  <td>{enquiry.requiredCapacity}</td>
                </tr>
              )}
              {enquiry.requiredReadability && (
                <tr>
                  <th>Required Readability</th>
                  <td>{enquiry.requiredReadability}</td>
                </tr>
              )}
              {enquiry.additionalRequirements && (
                <tr>
                  <th>Additional Requirements / Message</th>
                  <td style={{ whiteSpace: 'pre-line' }}>{enquiry.additionalRequirements}</td>
                </tr>
              )}
            </tbody>
          </table>

          <div className="cta-row">
            {customerWhatsappHref && (
              <Button
                variant="whatsapp"
                href={customerWhatsappHref}
                target="_blank"
                rel="noopener noreferrer"
              >
                Message Customer on WhatsApp
              </Button>
            )}
            <Button variant="primary" href={`tel:${phoneDigits}`}>
              Call Customer ({enquiry.phone})
            </Button>
          </div>
        </div>

        <div className="card">
          <h2 style={{ marginTop: 0, fontSize: '1.2rem', color: 'var(--color-navy)' }}>
            Admin Quotation &amp; Status Management
          </h2>
          <div className="alert alert-info" style={{ fontSize: '0.86rem' }}>
            <strong>Accounting Note:</strong> Recording a quoted price or setting the status to{' '}
            <strong>Converted</strong> tracks your sales pipeline only — it does not automatically
            add to repair collections.
          </div>

          <form onSubmit={handleSave} noValidate>
            <FormField id="enq-status" label="Enquiry Status" required>
              <select
                id="enq-status"
                className="form-select"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              >
                {BUSINESS_INFO.enquiryStatuses.map((st) => (
                  <option key={st} value={st}>
                    {st}
                  </option>
                ))}
              </select>
            </FormField>

            <FormField
              id="enq-quote"
              label="Quoted Price (₹, Optional)"
              hint="Enter the quotation offered to the customer in INR."
            >
              <input
                id="enq-quote"
                type="text"
                inputMode="decimal"
                className="form-input"
                placeholder="e.g. 3200"
                value={quotedPriceRupees}
                onChange={(e) => setQuotedPriceRupees(e.target.value)}
              />
            </FormField>

            <FormField id="enq-notes" label="Administrator Notes">
              <textarea
                id="enq-notes"
                className="form-textarea"
                placeholder="Record discussion notes, delivery terms, or follow-up details…"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </FormField>

            <Button type="submit" variant="primary" disabled={isSaving}>
              {isSaving ? 'Saving…' : 'Save Enquiry Updates'}
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
