import React, { useEffect, useMemo, useState } from 'react';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import { listEnquiriesAdmin } from '../../services/enquiryService.js';
import { formatPaiseToINR } from '../../utils/currency.js';
import { formatDateTime } from '../../utils/dates.js';
import { buildCustomerWhatsAppUrl } from '../../utils/whatsapp.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import Button from '../../components/common/Button.jsx';
import StatusBadge from '../../components/common/StatusBadge.jsx';
import Pagination from '../../components/common/Pagination.jsx';
import { LoadingState, ErrorState, EmptyState } from '../../components/common/StateFeedback.jsx';

const PAGE_SIZE = 12;

export default function AdminEnquiriesPage() {
  useDocumentTitle('Product Enquiries Management');

  const [enquiries, setEnquiries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [currentPage, setCurrentPage] = useState(1);

  const loadEnquiries = async () => {
    setLoading(true);
    setError(null);
    try {
      const list = await listEnquiriesAdmin({ statusFilter });
      setEnquiries(list);
    } catch (err) {
      setError(err?.message || 'Could not load product enquiries.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEnquiries();
  }, [statusFilter]);

  const filteredEnquiries = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return enquiries.filter((e) => {
      if (!q) return true;
      const hay = [
        e.id,
        e.customerName,
        e.phone,
        e.productNameSnapshot,
        e.productBrandSnapshot,
        e.productModelSnapshot
      ]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return hay.includes(q);
    });
  }, [enquiries, searchQuery]);

  const paginated = useMemo(() => {
    const start = (currentPage - 1) * PAGE_SIZE;
    return filteredEnquiries.slice(start, start + PAGE_SIZE);
  }, [filteredEnquiries, currentPage]);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchQuery, statusFilter]);

  return (
    <div>
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: '1rem',
          marginBottom: '1.25rem'
        }}
      >
        <div>
          <h1 style={{ margin: 0, color: 'var(--color-navy)', fontSize: '1.6rem' }}>
            Customer Product Enquiries
          </h1>
          <p style={{ margin: '0.25rem 0 0 0', color: 'var(--color-text-muted)', fontSize: '0.92rem' }}>
            Review incoming product enquiries, record quotations, and contact customers via WhatsApp or phone.
            Note: Marking an enquiry &ldquo;Converted&rdquo; does not automatically record payment received.
          </p>
        </div>
        <Button variant="secondary" onClick={loadEnquiries}>
          Refresh
        </Button>
      </div>

      <div className="card" style={{ marginBottom: '1.25rem' }}>
        <div className="grid-2">
          <div>
            <label htmlFor="enquiry-search" className="form-label">
              Search by Reference, Customer Name, Phone, or Product
            </label>
            <input
              id="enquiry-search"
              type="search"
              className="form-input"
              placeholder="Search enquiries…"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
          <div>
            <label htmlFor="enquiry-status-filter" className="form-label">
              Enquiry Status
            </label>
            <select
              id="enquiry-status-filter"
              className="form-select"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            >
              <option value="ALL">All Statuses</option>
              {BUSINESS_INFO.enquiryStatuses.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {loading && <LoadingState message="Loading customer enquiries…" />}
      {!loading && error && <ErrorState message={error} onRetry={loadEnquiries} />}

      {!loading && !error && filteredEnquiries.length === 0 && (
        <EmptyState
          title="No product enquiries found"
          description="Incoming customer product enquiries submitted on the public website will appear here."
        />
      )}

      {!loading && !error && filteredEnquiries.length > 0 && (
        <div className="card">
          <div className="table-responsive">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Reference</th>
                  <th>Submitted</th>
                  <th>Customer</th>
                  <th>Product Snapshot</th>
                  <th>Qty</th>
                  <th>Quoted Price</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {paginated.map((enq) => {
                  const waUrl = buildCustomerWhatsAppUrl(
                    enq.phone,
                    `Hello ${enq.customerName}, regarding your enquiry (Ref: ${enq.id}) for ${enq.productNameSnapshot} at ${BUSINESS_INFO.name}:`
                  );
                  return (
                    <tr key={enq.id}>
                      <td>
                        <code>{enq.id.slice(0, 8)}</code>
                      </td>
                      <td>{formatDateTime(enq.createdAt)}</td>
                      <td>
                        <strong>{enq.customerName}</strong>
                        <div style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)' }}>
                          {enq.phone} ({enq.preferredContactMethod})
                        </div>
                      </td>
                      <td>
                        <strong>{enq.productNameSnapshot}</strong>
                        <div style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>
                          {[enq.productBrandSnapshot, enq.productModelSnapshot]
                            .filter(Boolean)
                            .join(' • ')}
                        </div>
                      </td>
                      <td>{enq.quantity}</td>
                      <td>
                        {enq.quotedPricePaise
                          ? formatPaiseToINR(enq.quotedPricePaise)
                          : 'Not quoted'}
                      </td>
                      <td>
                        <StatusBadge status={enq.status} />
                      </td>
                      <td>
                        <div className="cta-row">
                          <Button variant="secondary" size="sm" to={`/admin/enquiries/${enq.id}`}>
                            Manage
                          </Button>
                          {waUrl && (
                            <Button
                              variant="whatsapp"
                              size="sm"
                              href={waUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                            >
                              WhatsApp
                            </Button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <Pagination
            currentPage={currentPage}
            totalItems={filteredEnquiries.length}
            pageSize={PAGE_SIZE}
            onPageChange={setCurrentPage}
          />
        </div>
      )}
    </div>
  );
}
