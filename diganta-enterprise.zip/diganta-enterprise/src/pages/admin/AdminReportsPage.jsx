import React, { useEffect, useMemo, useState } from 'react';
import { listRepairsAdmin } from '../../services/repairService.js';
import { listPaymentsMapForRepairs } from '../../services/paymentService.js';
import { listExpensesAdmin } from '../../services/expenseService.js';
import { calculateBusinessSummary, formatPaiseToINR } from '../../utils/currency.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import DateRangeFilter from '../../components/forms/DateRangeFilter.jsx';
import Button from '../../components/common/Button.jsx';
import { LoadingState, ErrorState } from '../../components/common/StateFeedback.jsx';

export default function AdminReportsPage() {
  useDocumentTitle('Financial Summary Report');

  const [repairs, setRepairs] = useState([]);
  const [paymentsByRepairId, setPaymentsByRepairId] = useState({});
  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [repairsData, expensesData] = await Promise.all([
        listRepairsAdmin(),
        listExpensesAdmin()
      ]);
      const paymentsMap = await listPaymentsMapForRepairs(repairsData);
      setRepairs(repairsData);
      setPaymentsByRepairId(paymentsMap);
      setExpenses(expensesData);
    } catch (err) {
      setError(err?.message || 'Could not load financial report data.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const summary = useMemo(
    () =>
      calculateBusinessSummary({
        repairs,
        paymentsByRepairId,
        expenses,
        startDate: startDate || null,
        endDate: endDate || null
      }),
    [repairs, paymentsByRepairId, expenses, startDate, endDate]
  );

  return (
    <div>
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: '1rem',
          marginBottom: '1.25rem'
        }}
      >
        <div>
          <h1 style={{ margin: 0, color: 'var(--color-navy)', fontSize: '1.6rem' }}>
            Financial Summary &amp; Operational Calculation Report
          </h1>
          <p style={{ margin: '0.25rem 0 0 0', color: 'var(--color-text-muted)', fontSize: '0.92rem' }}>
            Transparent operational figures derived from actual stored repairs, payment entries, and general expenses.
          </p>
        </div>
        <Button variant="secondary" onClick={loadData}>
          Refresh Data
        </Button>
      </div>

      <div className="alert alert-info">
        <strong>Important Accounting Disclaimer:</strong> These figures are operational management
        estimates calculated from recorded entries in Firestore. They are not audited financial
        statements or formal tax filings.
      </div>

      <DateRangeFilter
        startDate={startDate}
        endDate={endDate}
        onStartDateChange={setStartDate}
        onEndDateChange={setEndDate}
        onClear={() => {
          setStartDate('');
          setEndDate('');
        }}
        label="Filter Report Period"
      />

      {loading && <LoadingState message="Computing financial summary…" />}
      {!loading && error && <ErrorState message={error} onRetry={loadData} />}

      {!loading && !error && (
        <div className="grid-2">
          <div className="card">
            <h2 style={{ marginTop: 0, fontSize: '1.2rem', color: 'var(--color-navy)' }}>
              1. Collections, Costs &amp; Estimated Business Result
            </h2>
            <table className="data-table">
              <tbody>
                <tr>
                  <th>
                    Gross Customer Payments Received
                    <div style={{ fontSize: '0.78rem', fontWeight: 400, color: 'var(--color-text-muted)' }}>
                      Date basis: paymentDate (type = &quot;received&quot;)
                    </div>
                  </th>
                  <td style={{ textAlign: 'right', fontWeight: 700 }}>
                    {formatPaiseToINR(summary.grossCollectedPaise)}
                  </td>
                </tr>
                <tr>
                  <th>
                    Less: Recorded Customer Refunds
                    <div style={{ fontSize: '0.78rem', fontWeight: 400, color: 'var(--color-text-muted)' }}>
                      Date basis: paymentDate (type = &quot;refund&quot;)
                    </div>
                  </th>
                  <td style={{ textAlign: 'right', color: 'var(--color-error-text)', fontWeight: 700 }}>
                    −{formatPaiseToINR(summary.totalRefundsPaise)}
                  </td>
                </tr>
                <tr style={{ backgroundColor: '#F8FAFC' }}>
                  <th>
                    Recorded Net Customer Collections (A)
                    <div style={{ fontSize: '0.78rem', fontWeight: 400, color: 'var(--color-text-muted)' }}>
                      Gross Received − Refunds
                    </div>
                  </th>
                  <td style={{ textAlign: 'right', fontWeight: 800, color: 'var(--color-success-text)' }}>
                    {formatPaiseToINR(summary.netCustomerCollectionsPaise)}
                  </td>
                </tr>
                <tr>
                  <th>
                    Less: Recorded Direct Repair Costs (B)
                    <div style={{ fontSize: '0.78rem', fontWeight: 400, color: 'var(--color-text-muted)' }}>
                      Date basis: repairDate (Parts + Labour + Travel + Other direct repair costs)
                    </div>
                  </th>
                  <td style={{ textAlign: 'right', fontWeight: 700 }}>
                    −{formatPaiseToINR(summary.totalDirectRepairCostPaise)}
                  </td>
                </tr>
                <tr style={{ backgroundColor: '#F8FAFC' }}>
                  <th>
                    Estimated Repair Profit (A − B)
                    <div style={{ fontSize: '0.78rem', fontWeight: 400, color: 'var(--color-text-muted)' }}>
                      Collection-based repair estimate
                    </div>
                  </th>
                  <td style={{ textAlign: 'right', fontWeight: 800 }}>
                    {formatPaiseToINR(summary.estimatedRepairProfitPaise)}
                  </td>
                </tr>
                <tr>
                  <th>
                    Less: Recorded General Business Expenses (C)
                    <div style={{ fontSize: '0.78rem', fontWeight: 400, color: 'var(--color-text-muted)' }}>
                      Date basis: expense.date (Non-repair general expenses)
                    </div>
                  </th>
                  <td style={{ textAlign: 'right', fontWeight: 700 }}>
                    −{formatPaiseToINR(summary.totalGeneralExpensesPaise)}
                  </td>
                </tr>
                <tr style={{ backgroundColor: '#EEF2F6' }}>
                  <th>
                    Estimated Business Result (A − B − C)
                    <div style={{ fontSize: '0.78rem', fontWeight: 400, color: 'var(--color-text-muted)' }}>
                      Net Customer Collections − Direct Repair Costs − General Expenses
                    </div>
                  </th>
                  <td
                    style={{
                      textAlign: 'right',
                      fontSize: '1.15rem',
                      fontWeight: 800,
                      color:
                        summary.estimatedBusinessResultPaise >= 0
                          ? 'var(--color-success-text)'
                          : 'var(--color-error-text)'
                    }}
                  >
                    {formatPaiseToINR(summary.estimatedBusinessResultPaise)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div>
            <div className="card" style={{ marginBottom: '1.25rem' }}>
              <h2 style={{ marginTop: 0, fontSize: '1.2rem', color: 'var(--color-navy)' }}>
                2. Billed Charges &amp; Receivables (Repair Date Basis)
              </h2>
              <table className="data-table">
                <tbody>
                  <tr>
                    <th>Total Repairs in Selected Period</th>
                    <td style={{ textAlign: 'right', fontWeight: 700 }}>{summary.totalRepairsCount}</td>
                  </tr>
                  <tr>
                    <th>Total Final Amount Charged</th>
                    <td style={{ textAlign: 'right', fontWeight: 700 }}>
                      {formatPaiseToINR(summary.totalChargedPaise)}
                    </td>
                  </tr>
                  <tr>
                    <th>Total Outstanding Customer Balances</th>
                    <td style={{ textAlign: 'right', fontWeight: 700, color: 'var(--color-warning-text)' }}>
                      {formatPaiseToINR(summary.totalOutstandingBalancePaise)}
                    </td>
                  </tr>
                  <tr>
                    <th>Customer Overpayment / Advance Credit</th>
                    <td style={{ textAlign: 'right', fontWeight: 700 }}>
                      {formatPaiseToINR(summary.totalOverpaymentCreditPaise)}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            <div className="card">
              <h2 style={{ marginTop: 0, fontSize: '1.2rem', color: 'var(--color-navy)' }}>
                3. General Expenses by Category (Expense Date Basis)
              </h2>
              {Object.keys(summary.expensesByCategoryPaise).length === 0 ? (
                <p style={{ color: 'var(--color-text-muted)', margin: 0 }}>
                  No general business expenses recorded in the selected date range.
                </p>
              ) : (
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Category</th>
                      <th style={{ textAlign: 'right' }}>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {Object.entries(summary.expensesByCategoryPaise).map(([cat, paise]) => (
                      <tr key={cat}>
                        <td>{cat}</td>
                        <td style={{ textAlign: 'right', fontWeight: 700 }}>
                          {formatPaiseToINR(paise)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
