import React, { useEffect, useMemo, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import {
  generateNewRepairId,
  getRepairByIdAdmin,
  createRepairRecord,
  updateRepairRecord,
  deleteRepairRecordCompletely
} from '../../services/repairService.js';
import {
  listPaymentsForRepair,
  addPaymentForRepair
} from '../../services/paymentService.js';
import {
  uploadStorageImage,
  deleteStorageFile
} from '../../services/storageService.js';
import {
  paiseToRupeesInput,
  rupeesToPaise,
  calculateRepairFinancials,
  formatPaiseToINR
} from '../../utils/currency.js';
import { getTodayISODate, formatDate } from '../../utils/dates.js';
import { validateRepairForm, validatePaymentForm } from '../../utils/validation.js';
import { buildCustomerWhatsAppUrl } from '../../utils/whatsapp.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import FormField from '../../components/forms/FormField.jsx';
import Button from '../../components/common/Button.jsx';
import StatusBadge from '../../components/common/StatusBadge.jsx';
import ConfirmDialog from '../../components/common/ConfirmDialog.jsx';
import PrivateRepairPhotoGrid from '../../components/admin/PrivateRepairPhotoGrid.jsx';
import { LoadingState, ErrorState } from '../../components/common/StateFeedback.jsx';

export default function AdminRepairFormPage() {
  const { repairId } = useParams();
  const isEditMode = Boolean(repairId);
  const navigate = useNavigate();

  useDocumentTitle(isEditMode ? `Repair ${repairId}` : 'Create Repair Record');

  const [effectiveRepairId, setEffectiveRepairId] = useState(repairId || '');
  const [loading, setLoading] = useState(isEditMode);
  const [loadError, setLoadError] = useState(null);

  const [formData, setFormData] = useState({
    repairDate: getTodayISODate(),
    completedAt: '',
    deliveredAt: '',
    customerName: '',
    customerPhone: '',
    equipmentBrand: '',
    equipmentModel: '',
    equipmentCapacity: '',
    serialNumber: '',
    reportedFault: '',
    diagnosis: '',
    workPerformed: '',
    partsUsed: [],
    labourAllocationRupees: '0',
    travelExpenseRupees: '0',
    otherDirectExpensesRupees: '0',
    quotedAmountRupees: '',
    finalAmountChargedRupees: '',
    status: 'Received',
    warrantyDetails: '',
    notes: ''
  });

  const [repairPhotoPaths, setRepairPhotoPaths] = useState([]);
  const [newlyUploadedPaths, setNewlyUploadedPaths] = useState([]);
  const [payments, setPayments] = useState([]);

  const [fieldErrors, setFieldErrors] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState(null);
  const [saveError, setSaveError] = useState(null);

  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadError, setUploadError] = useState(null);

  const [paymentForm, setPaymentForm] = useState({
    paymentDate: getTodayISODate(),
    type: 'received',
    amountRupees: '',
    paymentMethod: 'Cash',
    notes: ''
  });
  const [paymentErrors, setPaymentErrors] = useState({});
  const [isRecordingPayment, setIsRecordingPayment] = useState(false);
  const [paymentFeedback, setPaymentFeedback] = useState(null);

  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    if (!isEditMode) {
      try {
        setEffectiveRepairId(generateNewRepairId());
      } catch {
        setEffectiveRepairId('');
      }
      return;
    }

    let active = true;
    setLoading(true);
    setLoadError(null);

    Promise.all([getRepairByIdAdmin(repairId), listPaymentsForRepair(repairId)])
      .then(([record, paymentList]) => {
        if (!active) return;
        if (!record) {
          setLoadError('Repair record not found.');
          setLoading(false);
          return;
        }
        setEffectiveRepairId(record.id);
        setFormData({
          repairDate: record.repairDate || getTodayISODate(),
          completedAt: record.completedAt || '',
          deliveredAt: record.deliveredAt || '',
          customerName: record.customerName || '',
          customerPhone: record.customerPhone || '',
          equipmentBrand: record.equipmentBrand || '',
          equipmentModel: record.equipmentModel || '',
          equipmentCapacity: record.equipmentCapacity || '',
          serialNumber: record.serialNumber || '',
          reportedFault: record.reportedFault || '',
          diagnosis: record.diagnosis || '',
          workPerformed: record.workPerformed || '',
          partsUsed: (record.partsUsed || []).map((p) => ({
            partName: p.partName || '',
            quantity: p.quantity ?? 1,
            unitCostRupees: paiseToRupeesInput(p.unitCostPaise ?? 0)
          })),
          labourAllocationRupees: paiseToRupeesInput(record.labourAllocationPaise ?? 0),
          travelExpenseRupees: paiseToRupeesInput(record.travelExpensePaise ?? 0),
          otherDirectExpensesRupees: paiseToRupeesInput(record.otherDirectExpensesPaise ?? 0),
          quotedAmountRupees: paiseToRupeesInput(record.quotedAmountPaise),
          finalAmountChargedRupees: paiseToRupeesInput(record.finalAmountChargedPaise),
          status: record.status || 'Received',
          warrantyDetails: record.warrantyDetails || '',
          notes: record.notes || ''
        });
        setRepairPhotoPaths(record.repairPhotoPaths || []);
        setPayments(paymentList || []);
        setLoading(false);
      })
      .catch((err) => {
        if (!active) return;
        setLoadError(err?.message || 'Could not load repair record.');
        setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [isEditMode, repairId]);

  const liveFinancials = useMemo(() => {
    const safePaise = (val, allowNull = false) => {
      try {
        return rupeesToPaise(val, { allowNull, allowZero: true });
      } catch {
        return allowNull ? null : 0;
      }
    };
    const previewParts = (formData.partsUsed || [])
      .filter((p) => (p.partName || '').trim() !== '' || String(p.unitCostRupees || '').trim() !== '')
      .map((p) => ({
        partName: p.partName || 'Part',
        quantity: Math.max(1, parseInt(p.quantity, 10) || 1),
        unitCostPaise: safePaise(p.unitCostRupees || '0')
      }));

    return calculateRepairFinancials(
      {
        partsUsed: previewParts,
        labourAllocationPaise: safePaise(formData.labourAllocationRupees || '0'),
        travelExpensePaise: safePaise(formData.travelExpenseRupees || '0'),
        otherDirectExpensesPaise: safePaise(formData.otherDirectExpensesRupees || '0'),
        quotedAmountPaise: safePaise(formData.quotedAmountRupees, true),
        finalAmountChargedPaise: safePaise(formData.finalAmountChargedRupees, true),
        status: formData.status
      },
      payments
    );
  }, [formData, payments]);

  const handleFieldChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setSaveMessage(null);
  };

  const handleAddPartRow = () => {
    setFormData((prev) => ({
      ...prev,
      partsUsed: [...prev.partsUsed, { partName: '', quantity: 1, unitCostRupees: '' }]
    }));
  };

  const handlePartChange = (index, key, value) => {
    setFormData((prev) => {
      const updated = [...prev.partsUsed];
      updated[index] = { ...updated[index], [key]: value };
      return { ...prev, partsUsed: updated };
    });
  };

  const handleRemovePartRow = (index) => {
    setFormData((prev) => ({
      ...prev,
      partsUsed: prev.partsUsed.filter((_, i) => i !== index)
    }));
  };

  const handleUploadPrivatePhoto = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    setUploadError(null);
    setUploadingPhoto(true);
    setUploadProgress(0);

    try {
      const targetId = effectiveRepairId || generateNewRepairId();
      if (!effectiveRepairId) setEffectiveRepairId(targetId);

      const storagePath = await uploadStorageImage({
        folder: 'repairs',
        recordId: targetId,
        file,
        onProgress: setUploadProgress
      });

      const updatedPaths = [...repairPhotoPaths, storagePath];
      setRepairPhotoPaths(updatedPaths);
      setNewlyUploadedPaths((prev) => [...prev, storagePath]);

      if (isEditMode) {
        const check = validateRepairForm(formData);
        if (check.isValid) {
          await updateRepairRecord(targetId, check.sanitized, updatedPaths);
        }
      }
    } catch (err) {
      setUploadError(err?.message || 'Private repair photo upload failed.');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const handleRemovePrivatePhoto = async (pathToRemove) => {
    try {
      await deleteStorageFile(pathToRemove);
      const updatedPaths = repairPhotoPaths.filter((p) => p !== pathToRemove);
      setRepairPhotoPaths(updatedPaths);
      if (isEditMode) {
        const check = validateRepairForm(formData);
        if (check.isValid) {
          await updateRepairRecord(effectiveRepairId, check.sanitized, updatedPaths);
        }
      }
    } catch (err) {
      setUploadError(err?.message || 'Could not remove private photo.');
    }
  };

  const handleSaveRepair = async (e) => {
    e.preventDefault();
    if (isSaving) return;

    setSaveError(null);
    setSaveMessage(null);

    const validation = validateRepairForm(formData);
    if (!validation.isValid) {
      setFieldErrors(validation.errors);
      setSaveError('Please fix the highlighted validation errors before saving.');
      return;
    }

    setFieldErrors({});
    setIsSaving(true);

    const targetId = effectiveRepairId || generateNewRepairId();
    try {
      if (isEditMode) {
        await updateRepairRecord(targetId, validation.sanitized, repairPhotoPaths);
        setNewlyUploadedPaths([]);
        setSaveMessage('Repair record updated.');
      } else {
        await createRepairRecord(targetId, validation.sanitized, repairPhotoPaths);
        setNewlyUploadedPaths([]);
        navigate(`/admin/repairs/${targetId}`, { replace: true });
      }
    } catch (err) {
      if (!isEditMode && newlyUploadedPaths.length > 0) {
        for (const orphanPath of newlyUploadedPaths) {
          try {
            await deleteStorageFile(orphanPath);
          } catch {
            // ignore cleanup error
          }
        }
        setRepairPhotoPaths((prev) => prev.filter((p) => !newlyUploadedPaths.includes(p)));
        setNewlyUploadedPaths([]);
      }
      setSaveError(err?.message || 'Could not save repair record.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleRecordPayment = async (e) => {
    e.preventDefault();
    if (!isEditMode || isRecordingPayment) return;

    setPaymentFeedback(null);
    const validation = validatePaymentForm(paymentForm);
    if (!validation.isValid) {
      setPaymentErrors(validation.errors);
      return;
    }

    setPaymentErrors({});
    setIsRecordingPayment(true);

    try {
      await addPaymentForRepair(effectiveRepairId, validation.sanitized);
      const updatedPayments = await listPaymentsForRepair(effectiveRepairId);
      setPayments(updatedPayments);
      setPaymentForm({
        paymentDate: getTodayISODate(),
        type: 'received',
        amountRupees: '',
        paymentMethod: 'Cash',
        notes: ''
      });
      setPaymentFeedback({
        type: 'success',
        text: `Recorded ${validation.sanitized.type === 'refund' ? 'refund' : 'payment'} of ${formatPaiseToINR(
          validation.sanitized.amountPaise
        )}.`
      });
    } catch (err) {
      setPaymentFeedback({
        type: 'error',
        text: err?.message || 'Failed to record payment entry.'
      });
    } finally {
      setIsRecordingPayment(false);
    }
  };

  const handleDeleteRepair = async () => {
    if (!isEditMode || isDeleting) return;
    setIsDeleting(true);
    try {
      await deleteRepairRecordCompletely({
        id: effectiveRepairId,
        repairPhotoPaths
      });
      navigate('/admin/repairs', { replace: true });
    } catch (err) {
      setSaveError(err?.message || 'Failed to delete repair record.');
      setShowDeleteConfirm(false);
    } finally {
      setIsDeleting(false);
    }
  };

  if (loading) {
    return <LoadingState message="Loading repair record and payment history…" />;
  }

  if (loadError) {
    return <ErrorState title="Could not load repair record" message={loadError} />;
  }

  const customerWhatsappUrl = buildCustomerWhatsAppUrl(
    formData.customerPhone,
    `Hello ${formData.customerName}, regarding your weighing scale repair (Ref: ${effectiveRepairId}) at ${BUSINESS_INFO.name}:`
  );

  return (
    <div>
      <div style={{ marginBottom: '1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
        <Link to="/admin/repairs">&larr; Back to Repair List</Link>
        {isEditMode && (
          <div className="cta-row">
            {customerWhatsappUrl && (
              <Button
                variant="whatsapp"
                size="sm"
                href={customerWhatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
              >
                WhatsApp Customer
              </Button>
            )}
            <Button
              variant="danger"
              size="sm"
              onClick={() => setShowDeleteConfirm(true)}
            >
              Delete Repair Record
            </Button>
          </div>
        )}
      </div>

      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '0.75rem' }}>
          <div>
            <h1 style={{ margin: 0, color: 'var(--color-navy)', fontSize: '1.5rem' }}>
              {isEditMode ? 'Repair Details & Editing' : 'Create New Repair Record'}
            </h1>
            <p style={{ margin: '0.25rem 0 0 0', fontSize: '0.88rem', color: 'var(--color-text-muted)' }}>
              Authoritative Repair ID: <code>{effectiveRepairId || 'Assigned on save'}</code>
            </p>
          </div>
          <div className="cta-row">
            <StatusBadge status={formData.status} />
            <StatusBadge status={liveFinancials.paymentStatus} />
          </div>
        </div>
      </div>

      {saveMessage && <div className="alert alert-success">{saveMessage}</div>}
      {saveError && <div className="alert alert-error">{saveError}</div>}

      <div className="grid-4" style={{ marginBottom: '1.5rem' }}>
        <div className="card">
          <div style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)', fontWeight: 700 }}>
            Total Recorded Repair Cost
          </div>
          <div style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--color-navy)', margin: '0.25rem 0' }}>
            {formatPaiseToINR(liveFinancials.totalCostPaise)}
          </div>
          <div style={{ fontSize: '0.78rem', color: 'var(--color-text-muted)' }}>
            Parts: {formatPaiseToINR(liveFinancials.partsCostPaise)} | Labour:{' '}
            {formatPaiseToINR(liveFinancials.labourAllocationPaise)}
          </div>
        </div>

        <div className="card">
          <div style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)', fontWeight: 700 }}>
            Quoted / Final Charged
          </div>
          <div style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--color-navy)', margin: '0.25rem 0' }}>
            {formatPaiseToINR(liveFinancials.finalAmountChargedPaise, { fallback: 'Not billed yet' })}
          </div>
          <div style={{ fontSize: '0.78rem', color: 'var(--color-text-muted)' }}>
            Quote: {formatPaiseToINR(liveFinancials.quotedAmountPaise, { fallback: 'None' })} (Never counted as collected)
          </div>
        </div>

        <div className="card">
          <div style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)', fontWeight: 700 }}>
            Net Collected &amp; Balance
          </div>
          <div style={{ fontSize: '1.35rem', fontWeight: 800, color: 'var(--color-success-text)', margin: '0.25rem 0' }}>
            {formatPaiseToINR(liveFinancials.netCollectedPaise)}
          </div>
          <div style={{ fontSize: '0.78rem', color: 'var(--color-text-muted)' }}>
            {liveFinancials.overpaymentCreditPaise > 0
              ? `Customer Credit / Overpaid: ${formatPaiseToINR(liveFinancials.overpaymentCreditPaise)}`
              : `Outstanding Balance: ${formatPaiseToINR(liveFinancials.outstandingBalancePaise)}`}
          </div>
        </div>

        <div className="card">
          <div style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)', fontWeight: 700 }}>
            Estimated Repair Profit
          </div>
          <div
            style={{
              fontSize: '1.35rem',
              fontWeight: 800,
              color:
                liveFinancials.estimatedCollectionProfitPaise >= 0
                  ? 'var(--color-success-text)'
                  : 'var(--color-error-text)',
              margin: '0.25rem 0'
            }}
          >
            {formatPaiseToINR(liveFinancials.estimatedCollectionProfitPaise)}
          </div>
          <div style={{ fontSize: '0.78rem', color: 'var(--color-text-muted)' }}>
            Collection-based (Net Collected − Direct Cost)
            {liveFinancials.billedMarginPaise !== null &&
              ` | Billed Margin: ${formatPaiseToINR(liveFinancials.billedMarginPaise)}`}
          </div>
        </div>
      </div>

      <form onSubmit={handleSaveRepair} noValidate>
        <div className="grid-2" style={{ marginBottom: '1.5rem' }}>
          <div className="card">
            <h2 style={{ marginTop: 0, fontSize: '1.2rem', color: 'var(--color-navy)' }}>
              1. Customer &amp; Weighing Scale Identification
            </h2>

            <div className="grid-2">
              <FormField
                id="repair-date"
                label="Repair Intake Date"
                required
                error={fieldErrors.repairDate}
              >
                <input
                  id="repair-date"
                  type="date"
                  className="form-input"
                  value={formData.repairDate}
                  onChange={(e) => handleFieldChange('repairDate', e.target.value)}
                />
              </FormField>

              <FormField
                id="repair-status"
                label="Repair Status"
                required
                error={fieldErrors.status}
              >
                <select
                  id="repair-status"
                  className="form-select"
                  value={formData.status}
                  onChange={(e) => handleFieldChange('status', e.target.value)}
                >
                  {BUSINESS_INFO.repairStatuses.map((st) => (
                    <option key={st} value={st}>
                      {st}
                    </option>
                  ))}
                </select>
              </FormField>
            </div>

            <div className="grid-2">
              <FormField
                id="customer-name"
                label="Customer Name"
                required
                error={fieldErrors.customerName}
              >
                <input
                  id="customer-name"
                  type="text"
                  className="form-input"
                  value={formData.customerName}
                  onChange={(e) => handleFieldChange('customerName', e.target.value)}
                  placeholder="Customer full name"
                />
              </FormField>

              <FormField
                id="customer-phone"
                label="Customer Phone"
                required
                error={fieldErrors.customerPhone}
              >
                <input
                  id="customer-phone"
                  type="tel"
                  className="form-input"
                  value={formData.customerPhone}
                  onChange={(e) => handleFieldChange('customerPhone', e.target.value)}
                  placeholder="+91 98765 43210"
                />
              </FormField>
            </div>

            <div className="grid-2">
              <FormField id="equipment-brand" label="Scale Brand">
                <input
                  id="equipment-brand"
                  type="text"
                  className="form-input"
                  value={formData.equipmentBrand}
                  onChange={(e) => handleFieldChange('equipmentBrand', e.target.value)}
                  placeholder="e.g. Vison Tech"
                />
              </FormField>

              <FormField id="equipment-model" label="Scale Model">
                <input
                  id="equipment-model"
                  type="text"
                  className="form-input"
                  value={formData.equipmentModel}
                  onChange={(e) => handleFieldChange('equipmentModel', e.target.value)}
                  placeholder="e.g. VT-100P"
                />
              </FormField>
            </div>

            <div className="grid-2">
              <FormField id="equipment-capacity" label="Scale Capacity">
                <input
                  id="equipment-capacity"
                  type="text"
                  className="form-input"
                  value={formData.equipmentCapacity}
                  onChange={(e) => handleFieldChange('equipmentCapacity', e.target.value)}
                  placeholder="e.g. 30 kg, 100 kg, 300 kg"
                />
              </FormField>

              <FormField id="serial-number" label="Serial Number (Private)">
                <input
                  id="serial-number"
                  type="text"
                  className="form-input"
                  value={formData.serialNumber}
                  onChange={(e) => handleFieldChange('serialNumber', e.target.value)}
                  placeholder="Optional equipment serial number"
                />
              </FormField>
            </div>

            <div className="grid-2">
              <FormField id="completed-at" label="Completed Date (Optional)">
                <input
                  id="completed-at"
                  type="date"
                  className="form-input"
                  value={formData.completedAt}
                  onChange={(e) => handleFieldChange('completedAt', e.target.value)}
                />
              </FormField>

              <FormField id="delivered-at" label="Delivered Date (Optional)">
                <input
                  id="delivered-at"
                  type="date"
                  className="form-input"
                  value={formData.deliveredAt}
                  onChange={(e) => handleFieldChange('deliveredAt', e.target.value)}
                />
              </FormField>
            </div>
          </div>

          <div className="card">
            <h2 style={{ marginTop: 0, fontSize: '1.2rem', color: 'var(--color-navy)' }}>
              2. Fault, Diagnosis &amp; Technical Work
            </h2>

            <FormField
              id="reported-fault"
              label="Reported Fault"
              required
              error={fieldErrors.reportedFault}
            >
              <textarea
                id="reported-fault"
                className="form-textarea"
                value={formData.reportedFault}
                onChange={(e) => handleFieldChange('reportedFault', e.target.value)}
                placeholder="Describe the customer's reported weighing scale problem"
              />
            </FormField>

            <FormField id="diagnosis" label="Technical Diagnosis">
              <textarea
                id="diagnosis"
                className="form-textarea"
                value={formData.diagnosis}
                onChange={(e) => handleFieldChange('diagnosis', e.target.value)}
                placeholder="Findings from PCB, load-cell, transformer, or power inspection"
              />
            </FormField>

            <FormField id="work-performed" label="Work Performed">
              <textarea
                id="work-performed"
                className="form-textarea"
                value={formData.workPerformed}
                onChange={(e) => handleFieldChange('workPerformed', e.target.value)}
                placeholder="Details of repair, component replacement, soldering, or calibration"
              />
            </FormField>

            <div className="grid-2">
              <FormField id="warranty-details" label="Specific Job Warranty Notes (If Any)">
                <input
                  id="warranty-details"
                  type="text"
                  className="form-input"
                  value={formData.warrantyDetails}
                  onChange={(e) => handleFieldChange('warrantyDetails', e.target.value)}
                  placeholder="Leave blank if no warranty applies"
                />
              </FormField>

              <FormField id="repair-notes" label="Internal Notes">
                <input
                  id="repair-notes"
                  type="text"
                  className="form-input"
                  value={formData.notes}
                  onChange={(e) => handleFieldChange('notes', e.target.value)}
                  placeholder="Internal workshop notes"
                />
              </FormField>
            </div>
          </div>
        </div>

        <div className="card" style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '1rem' }}>
            <div>
              <h2 style={{ margin: 0, fontSize: '1.2rem', color: 'var(--color-navy)' }}>
                3. Parts Used, Direct Costs &amp; Customer Billing (INR ₹)
              </h2>
              <p style={{ margin: '0.2rem 0 0 0', fontSize: '0.85rem', color: 'var(--color-text-muted)' }}>
                Parts total is automatically calculated from line items. Do not re-enter these direct costs under General Business Expenses.
              </p>
            </div>
            <Button variant="secondary" size="sm" onClick={handleAddPartRow}>
              + Add Part Line Item
            </Button>
          </div>

          {formData.partsUsed.length === 0 ? (
            <p style={{ color: 'var(--color-text-muted)', fontSize: '0.9rem' }}>
              No replacement parts recorded for this repair yet. Click &ldquo;+ Add Part Line Item&rdquo; to add components.
            </p>
          ) : (
            <div className="table-responsive" style={{ marginBottom: '1rem' }}>
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Part Name</th>
                    <th style={{ width: '130px' }}>Quantity</th>
                    <th style={{ width: '180px' }}>Unit Cost (₹)</th>
                    <th style={{ width: '160px' }}>Line Total</th>
                    <th style={{ width: '100px' }}>Remove</th>
                  </tr>
                </thead>
                <tbody>
                  {formData.partsUsed.map((part, idx) => {
                    let linePaise = 0;
                    try {
                      const u = rupeesToPaise(part.unitCostRupees || '0', { allowZero: true });
                      const q = Math.max(0, parseInt(part.quantity, 10) || 0);
                      linePaise = u * q;
                    } catch {
                      linePaise = 0;
                    }
                    return (
                      <tr key={idx}>
                        <td>
                          <input
                            type="text"
                            className="form-input"
                            placeholder="e.g. Transformer 9V, Load Cell, Display IC"
                            value={part.partName}
                            onChange={(e) => handlePartChange(idx, 'partName', e.target.value)}
                          />
                          {fieldErrors[`part_${idx}_name`] && (
                            <span className="form-error">{fieldErrors[`part_${idx}_name`]}</span>
                          )}
                        </td>
                        <td>
                          <input
                            type="number"
                            min="1"
                            className="form-input"
                            value={part.quantity}
                            onChange={(e) => handlePartChange(idx, 'quantity', e.target.value)}
                          />
                          {fieldErrors[`part_${idx}_quantity`] && (
                            <span className="form-error">{fieldErrors[`part_${idx}_quantity`]}</span>
                          )}
                        </td>
                        <td>
                          <input
                            type="text"
                            inputMode="decimal"
                            className="form-input"
                            placeholder="0.00"
                            value={part.unitCostRupees}
                            onChange={(e) => handlePartChange(idx, 'unitCostRupees', e.target.value)}
                          />
                          {fieldErrors[`part_${idx}_cost`] && (
                            <span className="form-error">{fieldErrors[`part_${idx}_cost`]}</span>
                          )}
                        </td>
                        <td style={{ fontWeight: 700, verticalAlign: 'middle' }}>
                          {formatPaiseToINR(linePaise)}
                        </td>
                        <td style={{ verticalAlign: 'middle' }}>
                          <Button
                            variant="danger"
                            size="sm"
                            onClick={() => handleRemovePartRow(idx)}
                          >
                            Remove
                          </Button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}

          <div className="grid-3">
            <FormField
              id="labour-allocation"
              label="Labour Allocation (₹)"
              error={fieldErrors.labourAllocationRupees}
            >
              <input
                id="labour-allocation"
                type="text"
                inputMode="decimal"
                className="form-input"
                value={formData.labourAllocationRupees}
                onChange={(e) => handleFieldChange('labourAllocationRupees', e.target.value)}
              />
            </FormField>

            <FormField
              id="travel-expense"
              label="Direct Travel Expense for This Repair (₹)"
              error={fieldErrors.travelExpenseRupees}
            >
              <input
                id="travel-expense"
                type="text"
                inputMode="decimal"
                className="form-input"
                value={formData.travelExpenseRupees}
                onChange={(e) => handleFieldChange('travelExpenseRupees', e.target.value)}
              />
            </FormField>

            <FormField
              id="other-direct-expense"
              label="Other Direct Expenses (₹)"
              error={fieldErrors.otherDirectExpensesRupees}
            >
              <input
                id="other-direct-expense"
                type="text"
                inputMode="decimal"
                className="form-input"
                value={formData.otherDirectExpensesRupees}
                onChange={(e) => handleFieldChange('otherDirectExpensesRupees', e.target.value)}
              />
            </FormField>
          </div>

          <div className="grid-2" style={{ marginTop: '0.5rem' }}>
            <FormField
              id="quoted-amount"
              label="Quoted Amount (₹, Optional)"
              hint="Estimate given to customer; never counted as payment collected."
              error={fieldErrors.quotedAmountRupees}
            >
              <input
                id="quoted-amount"
                type="text"
                inputMode="decimal"
                className="form-input"
                placeholder="e.g. 450"
                value={formData.quotedAmountRupees}
                onChange={(e) => handleFieldChange('quotedAmountRupees', e.target.value)}
              />
            </FormField>

            <FormField
              id="final-amount-charged"
              label="Final Amount Charged to Customer (₹, Optional until billed)"
              hint="Used to calculate customer Outstanding Balance against Net Collected."
              error={fieldErrors.finalAmountChargedRupees}
            >
              <input
                id="final-amount-charged"
                type="text"
                inputMode="decimal"
                className="form-input"
                placeholder="e.g. 500"
                value={formData.finalAmountChargedRupees}
                onChange={(e) => handleFieldChange('finalAmountChargedRupees', e.target.value)}
              />
            </FormField>
          </div>

          <div className="cta-row" style={{ marginTop: '1rem' }}>
            <Button type="submit" variant="primary" disabled={isSaving}>
              {isSaving
                ? 'Saving Repair Record…'
                : isEditMode
                ? 'Save Changes to Repair Record'
                : 'Create Repair Record'}
            </Button>
          </div>
        </div>
      </form>

      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <h2 style={{ marginTop: 0, fontSize: '1.2rem', color: 'var(--color-navy)' }}>
          4. Private Repair Photographs (Admin-Only Access)
        </h2>
        <p style={{ fontSize: '0.86rem', color: 'var(--color-text-muted)', marginTop: 0 }}>
          Stored under <code>repairs/{effectiveRepairId}/…</code> and protected by Storage Security Rules.
          Loaded using authenticated byte/blob requests and temporary browser Object URLs (never public download links).
          Maximum 5 MiB per JPEG, PNG, or WebP file.
        </p>

        {uploadError && <div className="alert alert-error">{uploadError}</div>}

        <div style={{ marginBottom: '1rem' }}>
          <label htmlFor="repair-photo-upload" className="btn btn-secondary btn-sm" style={{ cursor: uploadingPhoto ? 'not-allowed' : 'pointer' }}>
            {uploadingPhoto ? `Uploading (${uploadProgress}%)…` : '+ Upload Private Repair Photo'}
          </label>
          <input
            id="repair-photo-upload"
            type="file"
            accept="image/jpeg,image/png,image/webp"
            disabled={uploadingPhoto}
            onChange={handleUploadPrivatePhoto}
            style={{ display: 'none' }}
          />
        </div>

        <PrivateRepairPhotoGrid
          photoPaths={repairPhotoPaths}
          onRemovePhoto={handleRemovePrivatePhoto}
          disabled={uploadingPhoto || isSaving}
        />
      </div>

      <div className="card">
        <h2 style={{ marginTop: 0, fontSize: '1.2rem', color: 'var(--color-navy)' }}>
          5. Customer Payments &amp; Refunds History
        </h2>

        {!isEditMode ? (
          <p style={{ color: 'var(--color-text-muted)', margin: 0 }}>
            Save this new repair record first to unlock payment and refund recording under{' '}
            <code>repairs/{effectiveRepairId}/payments</code>.
          </p>
        ) : (
          <div className="grid-2">
            <div>
              <h3 style={{ marginTop: 0, fontSize: '1.05rem', color: 'var(--color-navy)' }}>
                Record Payment or Refund
              </h3>
              {paymentFeedback && (
                <div className={`alert ${paymentFeedback.type === 'error' ? 'alert-error' : 'alert-success'}`}>
                  {paymentFeedback.text}
                </div>
              )}

              <form onSubmit={handleRecordPayment} noValidate>
                <div className="grid-2">
                  <FormField
                    id="payment-date"
                    label="Payment Date"
                    required
                    error={paymentErrors.paymentDate}
                  >
                    <input
                      id="payment-date"
                      type="date"
                      className="form-input"
                      value={paymentForm.paymentDate}
                      onChange={(e) =>
                        setPaymentForm((prev) => ({ ...prev, paymentDate: e.target.value }))
                      }
                    />
                  </FormField>

                  <FormField id="payment-type" label="Entry Type" required error={paymentErrors.type}>
                    <select
                      id="payment-type"
                      className="form-select"
                      value={paymentForm.type}
                      onChange={(e) =>
                        setPaymentForm((prev) => ({ ...prev, type: e.target.value }))
                      }
                    >
                      <option value="received">Payment Received (+)</option>
                      <option value="refund">Refund to Customer (−)</option>
                    </select>
                  </FormField>
                </div>

                <div className="grid-2">
                  <FormField
                    id="payment-amount"
                    label="Amount (₹)"
                    required
                    error={paymentErrors.amountRupees}
                  >
                    <input
                      id="payment-amount"
                      type="text"
                      inputMode="decimal"
                      className="form-input"
                      placeholder="e.g. 300"
                      value={paymentForm.amountRupees}
                      onChange={(e) =>
                        setPaymentForm((prev) => ({ ...prev, amountRupees: e.target.value }))
                      }
                    />
                  </FormField>

                  <FormField
                    id="payment-method"
                    label="Payment Method"
                    required
                    error={paymentErrors.paymentMethod}
                  >
                    <select
                      id="payment-method"
                      className="form-select"
                      value={paymentForm.paymentMethod}
                      onChange={(e) =>
                        setPaymentForm((prev) => ({ ...prev, paymentMethod: e.target.value }))
                      }
                    >
                      {BUSINESS_INFO.paymentMethods.map((m) => (
                        <option key={m} value={m}>
                          {m}
                        </option>
                      ))}
                    </select>
                  </FormField>
                </div>

                <FormField id="payment-notes" label="Notes (Optional)" error={paymentErrors.notes}>
                  <input
                    id="payment-notes"
                    type="text"
                    className="form-input"
                    placeholder="e.g. Advance payment, UPI reference, or correction note"
                    value={paymentForm.notes}
                    onChange={(e) =>
                      setPaymentForm((prev) => ({ ...prev, notes: e.target.value }))
                    }
                  />
                </FormField>

                <Button type="submit" variant="navy" disabled={isRecordingPayment}>
                  {isRecordingPayment ? 'Recording…' : 'Add Payment / Refund Entry'}
                </Button>
              </form>
            </div>

            <div>
              <h3 style={{ marginTop: 0, fontSize: '1.05rem', color: 'var(--color-navy)' }}>
                Recorded Payment Ledger ({payments.length})
              </h3>
              <p style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)', marginTop: 0 }}>
                Append-only audit trail. To correct an over-collection, record a Refund entry.
              </p>

              {payments.length === 0 ? (
                <p style={{ color: 'var(--color-text-muted)' }}>
                  No payments or refunds recorded for this repair yet.
                </p>
              ) : (
                <div className="table-responsive">
                  <table className="data-table">
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Type</th>
                        <th>Method</th>
                        <th>Amount</th>
                        <th>Notes</th>
                      </tr>
                    </thead>
                    <tbody>
                      {payments.map((p) => (
                        <tr key={p.id}>
                          <td>{formatDate(p.paymentDate)}</td>
                          <td>
                            <span
                              className={`badge ${
                                p.type === 'refund' ? 'badge-error' : 'badge-success'
                              }`}
                            >
                              {p.type === 'refund' ? 'Refund (−)' : 'Received (+)'}
                            </span>
                          </td>
                          <td>{p.paymentMethod}</td>
                          <td style={{ fontWeight: 700 }}>
                            {p.type === 'refund' ? '−' : '+'}
                            {formatPaiseToINR(p.amountPaise)}
                          </td>
                          <td>{p.notes || '—'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              <div
                style={{
                  marginTop: '1rem',
                  padding: '0.75rem',
                  backgroundColor: 'var(--color-bg)',
                  borderRadius: 'var(--radius-sm)',
                  fontSize: '0.9rem'
                }}
              >
                <div>
                  <strong>Gross Received:</strong> {formatPaiseToINR(liveFinancials.totalReceivedPaise)} |{' '}
                  <strong>Refunds:</strong> {formatPaiseToINR(liveFinancials.totalRefundedPaise)}
                </div>
                <div style={{ marginTop: '0.25rem' }}>
                  <strong>Resulting Net Collection:</strong>{' '}
                  {formatPaiseToINR(liveFinancials.netCollectedPaise)} |{' '}
                  <strong>Remaining Balance:</strong>{' '}
                  {formatPaiseToINR(liveFinancials.outstandingBalancePaise)}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <ConfirmDialog
        isOpen={showDeleteConfirm}
        title="Delete Repair Record Permanently?"
        message={`Deleting repair ${effectiveRepairId} will permanently remove this repair record, its ${payments.length} payment ledger entry/entries, and ${repairPhotoPaths.length} private repair photograph(s). If you want to keep financial history, update the status to Delivered instead of deleting.`}
        confirmLabel="Delete Repair & Associated Data"
        isProcessing={isDeleting}
        onConfirm={handleDeleteRepair}
        onCancel={() => setShowDeleteConfirm(false)}
      />
    </div>
  );
}
