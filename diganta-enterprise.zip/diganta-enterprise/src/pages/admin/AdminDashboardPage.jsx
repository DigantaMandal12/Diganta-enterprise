import React, { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { listRepairsAdmin } from '../../services/repairService.js';
import { listPaymentsMapForRepairs } from '../../services/paymentService.js';
import { listExpensesAdmin } from '../../services/expenseService.js';
import { listEnquiriesAdmin } from '../../services/enquiryService.js';
import {
  calculateBusinessSummary,
  calculateRepairFinancials,
  formatPaiseToINR
} from '../../utils/currency.js';
import { formatDate } from '../../utils/dates.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import MetricCard from '../../components/common/MetricCard.jsx';
import StatusBadge from '../../components/common/StatusBadge.jsx';
import Button from '../../components/common/Button.jsx';
import DateRangeFilter from '../../components/forms/DateRangeFilter.jsx';
import { LoadingState, ErrorState, EmptyState } from '../../components/common/StateFeedback.jsx';

export default function AdminDashboardPage() {
  useDocumentTitle('Admin Dashboard Overview');

  const [repairs, setRepairs] = useState([]);
  const [paymentsByRepairId, setPaymentsByRepairId] = useState({});
  const [expenses, setExpenses] = useState([]);
  const [enquiries, setEnquiries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const loadDashboardData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [repairsData, expensesData, enquiriesData] = await Promise.all([
        listRepairsAdmin(),
        listExpensesAdmin(),
        listEnquiriesAdmin()
      ]);
      const paymentsMap = await listPaymentsMapForRepairs(repairsData);
      setRepairs(repairsData);
      setPaymentsByRepairId(paymentsMap);
      setExpenses(expensesData);
      setEnquiries(enquiriesData);
    } catch (err) {
      setError(err?.message || 'Could not load dashboard metrics.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  const summary = useMemo(
    () =>
      calculateBusinessSummary({
        repairs,
        paymentsByRepairId,
        expenses,
        startDate: startDate || null,
        endDate: endDate || null
      }),
    [repairs, paymentsByRepairId, expenses, startDate, endDate]
  );

  const openEnquiriesCount = useMemo(
    () => enquiries.filter((e) => !['Converted', 'Closed'].includes(e.status)).length,
    [enquiries]
  );

  const recentRepairs = useMemo(() => repairs.slice(0, 6), [repairs]);

  return (
    <div>
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'space-between',
          alignItems: 'center',
          gap: '1rem',
          marginBottom: '1.25rem'
        }}
      >
        <div>
          <h1 style={{ margin: 0, color: 'var(--color-navy)', fontSize: '1.65rem' }}>
            Business &amp; Repair Overview
          </h1>
          <p style={{ margin: '0.25rem 0 0 0', color: 'var(--color-text-muted)', fontSize: '0.92rem' }}>
            All metrics are calculated directly from stored Firestore records (never simulated or page-sliced).
          </p>
        </div>

        <div className="cta-row">
          <Button variant="primary" to="/admin/repairs/new">
            + New Repair Record
          </Button>
          <Button variant="navy" to="/admin/products/new">
            + Add Product
          </Button>
          <Button variant="secondary" onClick={loadDashboardData}>
            Refresh
          </Button>
        </div>
      </div>

      <DateRangeFilter
        startDate={startDate}
        endDate={endDate}
        onStartDateChange={setStartDate}
        onEndDateChange={setEndDate}
        onClear={() => {
          setStartDate('');
          setEndDate('');
        }}
        label="Filter Overview Metrics"
      />

      {loading && <LoadingState message="Calculating real-time business metrics from Firestore…" />}
      {!loading && error && <ErrorState message={error} onRetry={loadDashboardData} />}

      {!loading && !error && (
        <>
          <div className="grid-4" style={{ marginBottom: '1.25rem' }}>
            <MetricCard
              title="Total Repairs"
              value={summary.totalRepairsCount}
              subtitle="Date basis: Repair intake date (repairDate)"
              tone="default"
            />
            <MetricCard
              title="Pending Repairs"
              value={summary.pendingRepairsCount}
              subtitle="Statuses: Received, Diagnosing, Waiting for Parts, Repairing"
              tone="warning"
            />
            <MetricCard
              title="Completed Repairs"
              value={summary.completedRepairsCount}
              subtitle="Statuses: Completed or Delivered (repairDate)"
              tone="success"
            />
            <MetricCard
              title="Open Product Enquiries"
              value={openEnquiriesCount}
              subtitle="Enquiries in New, Contacted, or Quotation Sent status"
              tone="accent"
            />
          </div>

          <div className="grid-4" style={{ marginBottom: '1.25rem' }}>
            <MetricCard
              title="Total Amount Charged"
              value={formatPaiseToINR(summary.totalChargedPaise)}
              subtitle="Sum of finalAmountCharged on repairs (repairDate basis; excludes quotes)"
              tone="default"
            />
            <MetricCard
              title="Net Amount Collected"
              value={formatPaiseToINR(summary.netCustomerCollectionsPaise)}
              subtitle="Payments received minus refunds (paymentDate basis)"
              tone="success"
            />
            <MetricCard
              title="Outstanding Balances"
              value={formatPaiseToINR(summary.totalOutstandingBalancePaise)}
              subtitle="Unpaid balance on billed repairs (repairDate basis)"
              tone={summary.totalOutstandingBalancePaise > 0 ? 'warning' : 'default'}
            />
            <MetricCard
              title="Direct Repair Costs"
              value={formatPaiseToINR(summary.totalDirectRepairCostPaise)}
              subtitle="Parts + Labour + Travel + Other direct repair costs (repairDate basis)"
              tone="default"
            />
          </div>

          <div className="grid-3" style={{ marginBottom: '1.75rem' }}>
            <MetricCard
              title="General Business Expenses"
              value={formatPaiseToINR(summary.totalGeneralExpensesPaise)}
              subtitle="Non-repair workshop/general expenses (expense date basis)"
              tone="default"
            />
            <MetricCard
              title="Estimated Repair Profit"
              value={formatPaiseToINR(summary.estimatedRepairProfitPaise)}
              subtitle="Net Customer Collections minus Recorded Direct Repair Costs"
              tone={summary.estimatedRepairProfitPaise >= 0 ? 'success' : 'danger'}
            />
            <MetricCard
              title="Estimated Financial Result"
              value={formatPaiseToINR(summary.estimatedBusinessResultPaise)}
              subtitle="Net Collections − Direct Repair Costs − General Expenses (Operational estimate, not audited tax profit)"
              tone={summary.estimatedBusinessResultPaise >= 0 ? 'success' : 'danger'}
            />
          </div>

          {/* Recent Repair Records */}
          <div className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
              <h2 style={{ margin: 0, fontSize: '1.2rem', color: 'var(--color-navy)' }}>
                Recent Repair Records
              </h2>
              <Link to="/admin/repairs">View All Repairs &rarr;</Link>
            </div>

            {recentRepairs.length === 0 ? (
              <EmptyState
                title="No repair records recorded yet"
                description="Create your first repair job to start tracking parts, labour, customer payments, and balances."
                actionLabel="Create Repair Record"
                actionTo="/admin/repairs/new"
              />
            ) : (
              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Repair ID</th>
                      <th>Date</th>
                      <th>Customer</th>
                      <th>Equipment</th>
                      <th>Status</th>
                      <th>Charged</th>
                      <th>Net Collected</th>
                      <th>Payment Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentRepairs.map((repair) => {
                      const fin = calculateRepairFinancials(
                        repair,
                        paymentsByRepairId[repair.id] || []
                      );
                      return (
                        <tr key={repair.id}>
                          <td>
                            <code>{repair.id.slice(0, 8)}</code>
                          </td>
                          <td>{formatDate(repair.repairDate)}</td>
                          <td>
                            <strong>{repair.customerName}</strong>
                            <div style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>
                              {repair.customerPhone}
                            </div>
                          </td>
                          <td>
                            {[repair.equipmentBrand, repair.equipmentModel, repair.equipmentCapacity]
                              .filter(Boolean)
                              .join(' • ') || 'Weighing Scale'}
                          </td>
                          <td>
                            <StatusBadge status={repair.status} />
                          </td>
                          <td>{formatPaiseToINR(fin.finalAmountChargedPaise)}</td>
                          <td>{formatPaiseToINR(fin.netCollectedPaise)}</td>
                          <td>
                            <StatusBadge status={fin.paymentStatus} />
                          </td>
                          <td>
                            <Button variant="secondary" size="sm" to={`/admin/repairs/${repair.id}`}>
                              Manage
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
