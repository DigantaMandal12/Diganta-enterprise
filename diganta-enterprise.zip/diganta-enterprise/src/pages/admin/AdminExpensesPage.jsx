import React, { useEffect, useMemo, useState } from 'react';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import {
  listExpensesAdmin,
  createExpenseAdmin,
  updateExpenseAdmin,
  deleteExpenseAdmin
} from '../../services/expenseService.js';
import { paiseToRupeesInput, formatPaiseToINR } from '../../utils/currency.js';
import { getTodayISODate, formatDate } from '../../utils/dates.js';
import { validateExpenseForm } from '../../utils/validation.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import FormField from '../../components/forms/FormField.jsx';
import Button from '../../components/common/Button.jsx';
import ConfirmDialog from '../../components/common/ConfirmDialog.jsx';
import Pagination from '../../components/common/Pagination.jsx';
import { LoadingState, ErrorState, EmptyState } from '../../components/common/StateFeedback.jsx';

const PAGE_SIZE = 12;

export default function AdminExpensesPage() {
  useDocumentTitle('General Business Expenses');

  const [expenses, setExpenses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('ALL');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  const [editingExpenseId, setEditingExpenseId] = useState(null);
  const [formData, setFormData] = useState({
    date: getTodayISODate(),
    category: 'Workshop supplies',
    description: '',
    amountRupees: '',
    notes: ''
  });
  const [fieldErrors, setFieldErrors] = useState({});
  const [isSaving, setIsSaving] = useState(false);
  const [feedback, setFeedback] = useState(null);

  const [expenseToDelete, setExpenseToDelete] = useState(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const loadExpenses = async () => {
    setLoading(true);
    setError(null);
    try {
      const list = await listExpensesAdmin({ categoryFilter });
      setExpenses(list);
    } catch (err) {
      setError(err?.message || 'Could not load general expenses.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadExpenses();
  }, [categoryFilter]);

  const filteredExpenses = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return expenses.filter((exp) => {
      if (startDate && exp.date < startDate) return false;
      if (endDate && exp.date > endDate) return false;
      if (!q) return true;
      const hay = [exp.description, exp.category, exp.notes].filter(Boolean).join(' ').toLowerCase();
      return hay.includes(q);
    });
  }, [expenses, searchQuery, startDate, endDate]);

  const totalFilteredPaise = useMemo(
    () => filteredExpenses.reduce((sum, e) => sum + Number(e.amountPaise || 0), 0),
    [filteredExpenses]
  );

  const paginatedExpenses = useMemo(() => {
    const start = (currentPage - 1) * PAGE_SIZE;
    return filteredExpenses.slice(start, start + PAGE_SIZE);
  }, [filteredExpenses, currentPage]);

  const resetForm = () => {
    setEditingExpenseId(null);
    setFormData({
      date: getTodayISODate(),
      category: 'Workshop supplies',
      description: '',
      amountRupees: '',
      notes: ''
    });
    setFieldErrors({});
  };

  const handleEditClick = (exp) => {
    setEditingExpenseId(exp.id);
    setFormData({
      date: exp.date || getTodayISODate(),
      category: exp.category || 'Other',
      description: exp.description || '',
      amountRupees: paiseToRupeesInput(exp.amountPaise),
      notes: exp.notes || ''
    });
    setFieldErrors({});
    setFeedback(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSaving) return;

    setFeedback(null);
    const validation = validateExpenseForm(formData);
    if (!validation.isValid) {
      setFieldErrors(validation.errors);
      return;
    }

    setFieldErrors({});
    setIsSaving(true);
    try {
      if (editingExpenseId) {
        await updateExpenseAdmin(editingExpenseId, validation.sanitized);
        setFeedback({ type: 'success', text: 'General expense updated.' });
      } else {
        await createExpenseAdmin(validation.sanitized);
        setFeedback({ type: 'success', text: 'General expense recorded.' });
      }
      resetForm();
      await loadExpenses();
    } catch (err) {
      setFeedback({ type: 'error', text: err?.message || 'Failed to save expense.' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!expenseToDelete || isDeleting) return;
    setIsDeleting(true);
    try {
      await deleteExpenseAdmin(expenseToDelete.id);
      setExpenseToDelete(null);
      await loadExpenses();
    } catch (err) {
      setFeedback({ type: 'error', text: err?.message || 'Failed to delete expense.' });
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <div>
      <div className="section-header">
        <h1 style={{ margin: 0, color: 'var(--color-navy)', fontSize: '1.6rem' }}>
          General Business Expenses
        </h1>
        <p style={{ margin: '0.25rem 0 0 0', color: 'var(--color-text-muted)', fontSize: '0.92rem' }}>
          Record workshop electricity, general tools, solder/consumables, and general transport.
        </p>
      </div>

      <div className="alert alert-warning">
        <strong>Avoid Double-Counting Costs:</strong> Direct parts, labour allocation, and travel
        expenses already entered inside an individual Repair Record must <strong>not</strong> be
        re-entered here as general business expenses.
      </div>

      <div className="grid-2" style={{ alignItems: 'start' }}>
        <div className="card">
          <h2 style={{ marginTop: 0, fontSize: '1.2rem', color: 'var(--color-navy)' }}>
            {editingExpenseId ? 'Edit General Expense' : 'Record General Expense'}
          </h2>

          {feedback && (
            <div className={`alert ${feedback.type === 'error' ? 'alert-error' : 'alert-success'}`}>
              {feedback.text}
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            <div className="grid-2">
              <FormField id="exp-date" label="Expense Date" required error={fieldErrors.date}>
                <input
                  id="exp-date"
                  type="date"
                  className="form-input"
                  value={formData.date}
                  onChange={(e) => setFormData((prev) => ({ ...prev, date: e.target.value }))}
                />
              </FormField>

              <FormField id="exp-cat" label="Category" required error={fieldErrors.category}>
                <select
                  id="exp-cat"
                  className="form-select"
                  value={formData.category}
                  onChange={(e) => setFormData((prev) => ({ ...prev, category: e.target.value }))}
                >
                  {BUSINESS_INFO.expenseCategories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </FormField>
            </div>

            <FormField
              id="exp-desc"
              label="Description"
              required
              error={fieldErrors.description}
            >
              <input
                id="exp-desc"
                type="text"
                className="form-input"
                placeholder="e.g. Soldering wire & flux, multimeter leads, workshop electricity"
                value={formData.description}
                onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
              />
            </FormField>

            <FormField
              id="exp-amount"
              label="Amount (₹)"
              required
              error={fieldErrors.amountRupees}
            >
              <input
                id="exp-amount"
                type="text"
                inputMode="decimal"
                className="form-input"
                placeholder="e.g. 350.00"
                value={formData.amountRupees}
                onChange={(e) => setFormData((prev) => ({ ...prev, amountRupees: e.target.value }))}
              />
            </FormField>

            <FormField id="exp-notes" label="Notes (Optional)" error={fieldErrors.notes}>
              <input
                id="exp-notes"
                type="text"
                className="form-input"
                placeholder="Vendor or bill reference"
                value={formData.notes}
                onChange={(e) => setFormData((prev) => ({ ...prev, notes: e.target.value }))}
              />
            </FormField>

            <div className="cta-row">
              <Button type="submit" variant="primary" disabled={isSaving}>
                {isSaving
                  ? 'Saving…'
                  : editingExpenseId
                  ? 'Update Expense'
                  : 'Add Expense'}
              </Button>
              {editingExpenseId && (
                <Button variant="secondary" onClick={resetForm}>
                  Cancel Edit
                </Button>
              )}
            </div>
          </form>
        </div>

        <div>
          <div className="card" style={{ marginBottom: '1rem' }}>
            <div className="grid-2">
              <div>
                <label htmlFor="exp-search" className="form-label">
                  Search Description or Notes
                </label>
                <input
                  id="exp-search"
                  type="search"
                  className="form-input"
                  placeholder="Search expenses…"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>

              <div>
                <label htmlFor="exp-cat-filter" className="form-label">
                  Filter by Category
                </label>
                <select
                  id="exp-cat-filter"
                  className="form-select"
                  value={categoryFilter}
                  onChange={(e) => setCategoryFilter(e.target.value)}
                >
                  <option value="ALL">All Categories</option>
                  {BUSINESS_INFO.expenseCategories.map((c) => (
                    <option key={c} value={c}>
                      {c}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid-2" style={{ marginTop: '0.75rem' }}>
              <div>
                <label htmlFor="exp-from" className="form-label">
                  Date From
                </label>
                <input
                  id="exp-from"
                  type="date"
                  className="form-input"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>
              <div>
                <label htmlFor="exp-to" className="form-label">
                  Date To
                </label>
                <input
                  id="exp-to"
                  type="date"
                  className="form-input"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
            </div>

            <div
              style={{
                marginTop: '0.9rem',
                paddingTop: '0.75rem',
                borderTop: '1px solid var(--color-border)',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}
            >
              <span style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)' }}>
                Total across {filteredExpenses.length} matching expense(s):
              </span>
              <strong style={{ fontSize: '1.15rem', color: 'var(--color-navy)' }}>
                {formatPaiseToINR(totalFilteredPaise)}
              </strong>
            </div>
          </div>

          {loading && <LoadingState message="Loading general expenses…" />}
          {!loading && error && <ErrorState message={error} onRetry={loadExpenses} />}

          {!loading && !error && filteredExpenses.length === 0 && (
            <EmptyState
              title="No general expenses recorded"
              description="Use the form on the left to record general workshop supplies, tools, utilities, or transport."
            />
          )}

          {!loading && !error && filteredExpenses.length > 0 && (
            <div className="card">
              <div className="table-responsive">
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Category</th>
                      <th>Description</th>
                      <th>Amount</th>
                      <th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedExpenses.map((exp) => (
                      <tr key={exp.id}>
                        <td>{formatDate(exp.date)}</td>
                        <td>
                          <span className="badge badge-neutral">{exp.category}</span>
                        </td>
                        <td>
                          <strong>{exp.description}</strong>
                          {exp.notes && (
                            <div style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>
                              {exp.notes}
                            </div>
                          )}
                        </td>
                        <td style={{ fontWeight: 700 }}>{formatPaiseToINR(exp.amountPaise)}</td>
                        <td>
                          <div className="cta-row">
                            <Button
                              variant="secondary"
                              size="sm"
                              onClick={() => handleEditClick(exp)}
                            >
                              Edit
                            </Button>
                            <Button
                              variant="danger"
                              size="sm"
                              onClick={() => setExpenseToDelete(exp)}
                            >
                              Delete
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              <Pagination
                currentPage={currentPage}
                totalItems={filteredExpenses.length}
                pageSize={PAGE_SIZE}
                onPageChange={setCurrentPage}
              />
            </div>
          )}
        </div>
      </div>

      <ConfirmDialog
        isOpen={Boolean(expenseToDelete)}
        title="Delete General Expense?"
        message={
          expenseToDelete
            ? `Delete "${expenseToDelete.description}" (${formatPaiseToINR(
                expenseToDelete.amountPaise
              )}) on ${formatDate(expenseToDelete.date)}?`
            : ''
        }
        confirmLabel="Delete Expense"
        isProcessing={isDeleting}
        onConfirm={handleConfirmDelete}
        onCancel={() => setExpenseToDelete(null)}
      />
    </div>
  );
}
