import React, { useState } from 'react';
import { Navigate, useLocation, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import FormField from '../../components/forms/FormField.jsx';
import Button from '../../components/common/Button.jsx';
import FirebaseSetupBanner from '../../components/common/FirebaseSetupBanner.jsx';

export default function AdminLoginPage() {
  useDocumentTitle('Administrator Sign In');
  const { user, isAdmin, loading, signIn, signOutUser } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  if (!loading && user && isAdmin) {
    const target = location.state?.from?.pathname || '/admin';
    return <Navigate to={target} replace />;
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (submitting) return;
    setError(null);
    setSubmitting(true);

    try {
      const result = await signIn(email, password);
      if (!result.isAdmin) {
        setError(
          `Authenticated as ${result.user.email} (UID: ${result.user.uid}), but this UID is not in the Firestore admins/{uid} allowlist with role="admin".`
        );
      } else {
        const target = location.state?.from?.pathname || '/admin';
        navigate(target, { replace: true });
      }
    } catch (err) {
      setError(err?.message || 'Sign-in failed.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="container section">
      <div style={{ maxWidth: '460px', margin: '1.5rem auto' }}>
        <FirebaseSetupBanner />

        <div className="card" style={{ borderTop: '4px solid var(--color-navy)' }}>
          <h1 style={{ marginTop: 0, color: 'var(--color-navy)', fontSize: '1.5rem' }}>
            {BUSINESS_INFO.name} — Administrator Login
          </h1>
          <p style={{ color: 'var(--color-text-muted)', fontSize: '0.9rem', marginBottom: '1.25rem' }}>
            Restricted to the single authorised administrator account provisioned in Firebase
            Authentication and the Firestore <code>admins/{'{uid}'}</code> allowlist.
          </p>

          {user && !isAdmin && (
            <div className="alert alert-error" role="alert">
              <strong>Access Denied:</strong> Account <strong>{user.email}</strong> (UID:{' '}
              <code>{user.uid}</code>) is signed in, but is not authorised in{' '}
              <code>admins/{user.uid}</code>.
              <div style={{ marginTop: '0.75rem' }}>
                <Button variant="secondary" size="sm" onClick={signOutUser}>
                  Sign Out of This Account
                </Button>
              </div>
            </div>
          )}

          {error && (
            <div className="alert alert-error" role="alert">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            <FormField id="admin-email" label="Administrator Email" required>
              <input
                id="admin-email"
                type="email"
                className="form-input"
                autoComplete="username"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="admin@example.com"
              />
            </FormField>

            <FormField id="admin-password" label="Password" required>
              <input
                id="admin-password"
                type="password"
                className="form-input"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
              />
            </FormField>

            <div className="cta-row" style={{ marginTop: '1.25rem' }}>
              <Button type="submit" variant="primary" disabled={submitting} style={{ width: '100%' }}>
                {submitting ? 'Signing In…' : 'Sign In to Admin Dashboard'}
              </Button>
            </div>
          </form>

          <div style={{ marginTop: '1.25rem', textAlign: 'center', fontSize: '0.88rem' }}>
            <Link to="/">&larr; Return to Public Website</Link>
          </div>
        </div>
      </div>
    </div>
  );
}
