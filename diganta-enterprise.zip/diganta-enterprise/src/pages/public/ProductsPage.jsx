import React, { useEffect, useMemo, useState } from 'react';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import { listPublishedProducts } from '../../services/productService.js';
import { isFirebaseConfigured } from '../../services/firebase.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import ProductCard from '../../components/products/ProductCard.jsx';
import { LoadingState, ErrorState, EmptyState } from '../../components/common/StateFeedback.jsx';
import Button from '../../components/common/Button.jsx';
import FirebaseSetupBanner from '../../components/common/FirebaseSetupBanner.jsx';

export default function ProductsPage() {
  useDocumentTitle(
    'Weighing Scale Product Catalogue',
    `Browse published weighing scales from ${BUSINESS_INFO.name} in ${BUSINESS_INFO.location}. Filter by scale type and capacity, view specifications, and request a quote.`
  );

  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [searchTerm, setSearchTerm] = useState('');
  const [scaleTypeFilter, setScaleTypeFilter] = useState('ALL');
  const [capacityFilter, setCapacityFilter] = useState('ALL');

  const fetchProducts = async () => {
    if (!isFirebaseConfigured) {
      setProducts([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const data = await listPublishedProducts();
      setProducts(data);
    } catch (err) {
      setError(err?.message || 'Could not load published products.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const availableScaleTypes = useMemo(() => {
    const set = new Set();
    products.forEach((p) => {
      if (p.scaleType) set.add(p.scaleType);
    });
    return Array.from(set).sort();
  }, [products]);

  const availableCapacities = useMemo(() => {
    const set = new Set();
    products.forEach((p) => {
      if (p.maximumCapacityValue) {
        set.add(`${p.maximumCapacityValue} ${p.maximumCapacityUnit || 'kg'}`);
      }
    });
    return Array.from(set);
  }, [products]);

  const filteredProducts = useMemo(() => {
    const q = searchTerm.trim().toLowerCase();
    return products.filter((p) => {
      if (scaleTypeFilter !== 'ALL' && p.scaleType !== scaleTypeFilter) {
        return false;
      }
      if (capacityFilter !== 'ALL') {
        const capLabel = p.maximumCapacityValue
          ? `${p.maximumCapacityValue} ${p.maximumCapacityUnit || 'kg'}`
          : '';
        if (capLabel !== capacityFilter) return false;
      }
      if (!q) return true;
      const haystack = [p.name, p.brand, p.model, p.scaleType, p.specifications]
        .filter(Boolean)
        .join(' ')
        .toLowerCase();
      return haystack.includes(q);
    });
  }, [products, searchTerm, scaleTypeFilter, capacityFilter]);

  const clearFilters = () => {
    setSearchTerm('');
    setScaleTypeFilter('ALL');
    setCapacityFilter('ALL');
  };

  return (
    <div className="container section">
      <FirebaseSetupBanner />

      <div className="section-header">
        <h1 className="section-title">Weighing-Scale Product Catalogue</h1>
        <p className="section-subtitle">
          View specifications and submit a product enquiry for current pricing and availability.
          Supported capacities include {BUSINESS_INFO.supportedCapacities.join(', ')}.
        </p>
      </div>

      {/* Search & Filter Controls */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div className="grid-3" style={{ alignItems: 'end' }}>
          <div>
            <label htmlFor="product-search" className="form-label">
              Search by Name, Brand, or Model
            </label>
            <input
              id="product-search"
              type="search"
              className="form-input"
              placeholder="e.g. Vison Tech, 100 kg, Platform…"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>

          <div>
            <label htmlFor="scale-type-filter" className="form-label">
              Filter by Scale Type
            </label>
            <select
              id="scale-type-filter"
              className="form-select"
              value={scaleTypeFilter}
              onChange={(e) => setScaleTypeFilter(e.target.value)}
            >
              <option value="ALL">All Scale Types</option>
              {availableScaleTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="capacity-filter" className="form-label">
              Filter by Maximum Capacity
            </label>
            <select
              id="capacity-filter"
              className="form-select"
              value={capacityFilter}
              onChange={(e) => setCapacityFilter(e.target.value)}
            >
              <option value="ALL">All Capacities</option>
              {availableCapacities.map((cap) => (
                <option key={cap} value={cap}>
                  {cap}
                </option>
              ))}
            </select>
          </div>
        </div>

        {(searchTerm || scaleTypeFilter !== 'ALL' || capacityFilter !== 'ALL') && (
          <div style={{ marginTop: '0.9rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
            <span style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)' }}>
              Showing {filteredProducts.length} of {products.length} published products
            </span>
            <Button variant="secondary" size="sm" onClick={clearFilters}>
              Reset Search &amp; Filters
            </Button>
          </div>
        )}
      </div>

      {/* Product Grid States */}
      {loading && <LoadingState message="Loading product catalogue…" />}

      {!loading && error && (
        <ErrorState title="Could not load product catalogue" message={error} onRetry={fetchProducts} />
      )}

      {!loading && !error && products.length === 0 && (
        <EmptyState
          title="No published products in the catalogue right now"
          description="We are currently updating our online product listings. Please call or WhatsApp us to ask about available tabletop, bench, and platform weighing scales."
          actionLabel={`Call ${BUSINESS_INFO.phoneDisplay}`}
          onAction={() => {
            window.location.href = BUSINESS_INFO.phoneHref;
          }}
        />
      )}

      {!loading && !error && products.length > 0 && filteredProducts.length === 0 && (
        <EmptyState
          title="No matching weighing scales found"
          description="No published products matched your search or filter criteria. Try clearing the filters or contact us directly with your capacity requirement."
          actionLabel="Clear Filters"
          onAction={clearFilters}
        />
      )}

      {!loading && !error && filteredProducts.length > 0 && (
        <div className="grid-3">
          {filteredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
}
