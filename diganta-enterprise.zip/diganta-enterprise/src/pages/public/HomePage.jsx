import React, { useEffect, useState } from 'react';
import { BUSINESS_INFO, REPAIR_VIDEOS } from '../../config/businessConfig.js';
import { listPublishedProducts } from '../../services/productService.js';
import { isFirebaseConfigured } from '../../services/firebase.js';
import { buildBusinessWhatsAppUrl } from '../../utils/whatsapp.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import Button from '../../components/common/Button.jsx';
import ProductCard from '../../components/products/ProductCard.jsx';
import { LoadingState, ErrorState, EmptyState } from '../../components/common/StateFeedback.jsx';
import FirebaseSetupBanner from '../../components/common/FirebaseSetupBanner.jsx';

export default function HomePage() {
  useDocumentTitle(
    'Weighing Scale Repair & Sales in Mohonpur, West Bengal',
    `${BUSINESS_INFO.name} in ${BUSINESS_INFO.location} offers weighing-scale repair, electronic PCB and transformer troubleshooting, workshop and on-site scale repair, and weighing scale sales.`
  );

  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [productsError, setProductsError] = useState(null);

  const loadFeatured = async () => {
    if (!isFirebaseConfigured) {
      setFeaturedProducts([]);
      setLoadingProducts(false);
      return;
    }
    setLoadingProducts(true);
    setProductsError(null);
    try {
      const items = await listPublishedProducts();
      setFeaturedProducts(items.slice(0, 3));
    } catch (err) {
      setProductsError(err?.message || 'Unable to load featured weighing scales.');
    } finally {
      setLoadingProducts(false);
    }
  };

  useEffect(() => {
    loadFeatured();
  }, []);

  const repairWhatsappHref = buildBusinessWhatsAppUrl(
    `Hello ${BUSINESS_INFO.name}, I would like to enquire about weighing-scale repair or sales.`
  );

  return (
    <div>
      {/* Hero Banner */}
      <section className="hero-banner">
        <div className="container">
          <p style={{ color: 'var(--color-orange)', fontWeight: 700, margin: '0 0 0.4rem 0', textTransform: 'uppercase', fontSize: '0.88rem' }}>
            {BUSINESS_INFO.location} • {BUSINESS_INFO.serviceRadius} Service Area
          </p>
          <h1 className="hero-title">
            {BUSINESS_INFO.name} — {BUSINESS_INFO.tagline}
          </h1>
          <p className="hero-lead">
            Practical electronic weighing-scale repair, PCB and transformer troubleshooting, and
            dependable weighing equipment for shops, markets, and commercial operations across
            Mohonpur, Ariabāṛā, and surrounding areas.
          </p>
          <div className="cta-row">
            <Button variant="primary" href={BUSINESS_INFO.phoneHref}>
              Call Now: {BUSINESS_INFO.phoneDisplay}
            </Button>
            <Button
              variant="whatsapp"
              href={repairWhatsappHref}
              target="_blank"
              rel="noopener noreferrer"
            >
              WhatsApp Us
            </Button>
            <Button variant="secondary" to="/products">
              Browse Products
            </Button>
          </div>
        </div>
      </section>

      <div className="container">
        <div style={{ marginTop: '1.25rem' }}>
          <FirebaseSetupBanner />
        </div>

        {/* Core Capabilities Overview */}
        <section className="section">
          <div className="section-header">
            <h2 className="section-title">Weighing-Scale Repair &amp; Sales Capabilities</h2>
            <p className="section-subtitle">
              Focused exclusively on commercial, retail, and platform weighing scales — from 10 kg tabletop units to 150–300 kg platform scales.
            </p>
          </div>

          <div className="grid-3">
            <div className="card">
              <h3 style={{ marginTop: 0, color: 'var(--color-navy)' }}>Electronic Scale Troubleshooting</h3>
              <p style={{ color: 'var(--color-text-muted)', marginBottom: 0 }}>
                Diagnosis and repair of inaccurate weight readings, keypad faults, display issues,
                load-cell connection problems, and power instability across supported capacities
                ({BUSINESS_INFO.supportedCapacities.join(', ')}).
              </p>
            </div>

            <div className="card">
              <h3 style={{ marginTop: 0, color: 'var(--color-navy)' }}>PCB &amp; Transformer Work</h3>
              <p style={{ color: 'var(--color-text-muted)', marginBottom: 0 }}>
                Component-level PCB and motherboard repair or fabrication where appropriate, plus
                weighing-scale transformer repair or replacement for reliable power regulation.
              </p>
            </div>

            <div className="card">
              <h3 style={{ marginTop: 0, color: 'var(--color-navy)' }}>Weighing Scale Sales</h3>
              <p style={{ color: 'var(--color-text-muted)', marginBottom: 0 }}>
                Supply of commercial and industrial weighing scales (including known brands such as{' '}
                {BUSINESS_INFO.knownBrands.join(', ')}) with clear specifications and direct quotation support.
              </p>
            </div>
          </div>
        </section>

        {/* Workshop vs On-Site Weighing Scale Repair */}
        <section className="section" style={{ paddingTop: 0 }}>
          <div className="card" style={{ borderLeft: '5px solid var(--color-orange)' }}>
            <div className="grid-2" style={{ alignItems: 'center' }}>
              <div>
                <h2 style={{ marginTop: 0, color: 'var(--color-navy)' }}>
                  Workshop Repair &amp; On-Site Weighing-Scale Visits
                </h2>
                <p style={{ margin: '0 0 0.75rem 0' }}>
                  <strong>Workshop Service:</strong> Bring your tabletop, bench, or portable platform
                  weighing scale directly to our workshop in {BUSINESS_INFO.location} for bench
                  testing, soldering, PCB diagnostics, and calibration verification.
                </p>
                <p style={{ margin: 0 }}>
                  <strong>On-Site Scale Repair:</strong> For heavy platform scales or fixed commercial
                  weighing equipment within {BUSINESS_INFO.serviceRadius.toLowerCase()}, contact us by
                  phone or WhatsApp to discuss travelling to your premise to inspect and repair your
                  weighing scale on-site, depending on the job and location.
                </p>
              </div>
              <div className="card" style={{ backgroundColor: 'var(--color-bg)' }}>
                <h3 style={{ marginTop: 0, color: 'var(--color-navy)' }}>Need a Scale Repaired?</h3>
                <p style={{ fontSize: '0.92rem', color: 'var(--color-text-muted)' }}>
                  Repair enquiries are handled directly via phone or WhatsApp so we can discuss your
                  scale&apos;s capacity, fault symptoms, and whether workshop drop-off or an on-site
                  visit is best.
                </p>
                <div className="cta-row">
                  <Button variant="navy" href={BUSINESS_INFO.phoneHref}>
                    Call {BUSINESS_INFO.phoneDisplay}
                  </Button>
                  <Button
                    variant="whatsapp"
                    href={repairWhatsappHref}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Message on WhatsApp
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Published Products */}
        <section className="section" style={{ paddingTop: 0 }}>
          <div
            className="section-header"
            style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'flex-end', gap: '1rem' }}
          >
            <div>
              <h2 className="section-title">Featured Weighing Scales</h2>
              <p className="section-subtitle">
                Published models currently listed in our catalogue. Submit an enquiry for current pricing and availability.
              </p>
            </div>
            <Button variant="secondary" to="/products">
              View All Products
            </Button>
          </div>

          {loadingProducts && <LoadingState message="Loading published weighing scales…" />}
          {!loadingProducts && productsError && (
            <ErrorState message={productsError} onRetry={loadFeatured} />
          )}
          {!loadingProducts && !productsError && featuredProducts.length === 0 && (
            <EmptyState
              title="No published products in the catalogue yet"
              description="Our online product catalogue is being updated. Please call or message us on WhatsApp to ask about available 10 kg to 300 kg weighing scales."
              actionLabel={`Call ${BUSINESS_INFO.phoneDisplay}`}
              onAction={() => {
                window.location.href = BUSINESS_INFO.phoneHref;
              }}
            />
          )}
          {!loadingProducts && !productsError && featuredProducts.length > 0 && (
            <div className="grid-3">
              {featuredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </section>

        {/* Configured Repair Work & Videos Preview */}
        <section className="section" style={{ paddingTop: 0 }}>
          <div
            className="section-header"
            style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'flex-end', gap: '1rem' }}
          >
            <div>
              <h2 className="section-title">Actual Repair Work &amp; Technical Videos</h2>
              <p className="section-subtitle">
                Real workshop repairs, PCB diagnostics, and weighing-scale demonstrations.
              </p>
            </div>
            <Button variant="secondary" to="/our-work">
              Visit Our Work Page
            </Button>
          </div>

          {REPAIR_VIDEOS.length === 0 ? (
            <div className="card">
              <p style={{ margin: '0 0 0.75rem 0', color: 'var(--color-text-muted)' }}>
                No repair videos are currently configured in <code>src/config/businessConfig.js</code>.
                Check our <a href="/our-work">Our Work</a> page or contact us on WhatsApp to discuss
                your weighing scale fault.
              </p>
              <Button variant="secondary" size="sm" to="/services">
                Read About Our Repair Services
              </Button>
            </div>
          ) : (
            <div className="grid-2">
              {REPAIR_VIDEOS.slice(0, 2).map((video) => (
                <div key={video.id} className="card">
                  <h3 style={{ marginTop: 0 }}>{video.title}</h3>
                  <p style={{ color: 'var(--color-text-muted)' }}>{video.description}</p>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* Service Area & Hours Summary */}
        <section className="section" style={{ paddingTop: 0 }}>
          <div className="grid-2">
            <div className="card">
              <h3 style={{ marginTop: 0, color: 'var(--color-navy)' }}>Service Area &amp; Location</h3>
              <p>
                Based in <strong>{BUSINESS_INFO.location}</strong>, we serve local shops, traders,
                agricultural sellers, and commercial customers within{' '}
                <strong>{BUSINESS_INFO.serviceRadius.toLowerCase()}</strong>.
              </p>
              <p style={{ marginBottom: 0, color: 'var(--color-text-muted)', fontSize: '0.92rem' }}>
                Note: &ldquo;On-site service&rdquo; refers strictly to travelling to a customer&apos;s
                location to inspect or repair weighing scales. We do not repair mobile phones.
              </p>
            </div>

            <div className="card">
              <h3 style={{ marginTop: 0, color: 'var(--color-navy)' }}>Business Hours &amp; Direct Contact</h3>
              <ul style={{ listStyle: 'none', padding: 0, margin: '0 0 1rem 0', lineHeight: '1.8' }}>
                <li><strong>Opening Hours:</strong> {BUSINESS_INFO.businessHours}</li>
                <li>
                  <strong>Telephone:</strong>{' '}
                  <a href={BUSINESS_INFO.phoneHref}>{BUSINESS_INFO.phoneDisplay}</a>
                </li>
                <li>
                  <strong>WhatsApp:</strong>{' '}
                  <a href={BUSINESS_INFO.whatsappBaseUrl} target="_blank" rel="noopener noreferrer">
                    {BUSINESS_INFO.whatsappDisplay}
                  </a>
                </li>
              </ul>
              <Button variant="primary" to="/contact">
                View Full Contact Details
              </Button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}
