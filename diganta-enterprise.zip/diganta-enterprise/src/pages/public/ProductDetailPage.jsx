import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import { getProductById } from '../../services/productService.js';
import { isFirebaseConfigured } from '../../services/firebase.js';
import { formatPaiseToINR } from '../../utils/currency.js';
import { buildBusinessWhatsAppUrl } from '../../utils/whatsapp.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import ProductImageGallery from '../../components/products/ProductImageGallery.jsx';
import StatusBadge, { formatAvailabilityLabel } from '../../components/common/StatusBadge.jsx';
import Button from '../../components/common/Button.jsx';
import { LoadingState, ErrorState, EmptyState } from '../../components/common/StateFeedback.jsx';

export default function ProductDetailPage() {
  const { productId } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useDocumentTitle(
    product ? `${product.name} (${product.scaleType || 'Weighing Scale'})` : 'Product Details',
    product
      ? `${product.name} specifications and enquiry at ${BUSINESS_INFO.name}, ${BUSINESS_INFO.location}.`
      : ''
  );

  useEffect(() => {
    let active = true;
    if (!isFirebaseConfigured) {
      setLoading(false);
      return () => {};
    }
    setLoading(true);
    setError(null);

    getProductById(productId)
      .then((item) => {
        if (!active) return;
        if (!item || !item.isPublished) {
          setProduct(null);
        } else {
          setProduct(item);
        }
        setLoading(false);
      })
      .catch((err) => {
        if (!active) return;
        if (err?.code === 'permission-denied') {
          setProduct(null);
        } else {
          setError(err?.message || 'Could not load product details.');
        }
        setLoading(false);
      });

    return () => {
      active = false;
    };
  }, [productId]);

  if (loading) {
    return (
      <div className="container section">
        <LoadingState message="Loading product details…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container section">
        <ErrorState title="Error loading product" message={error} />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container section">
        <EmptyState
          title="Product not found or unpublished"
          description="This weighing scale may have been removed from the public catalogue or the link is invalid."
          actionLabel="Back to Product Catalogue"
          actionTo="/products"
        />
      </div>
    );
  }

  const capacityDisplay = product.maximumCapacityValue
    ? `${product.maximumCapacityValue} ${product.maximumCapacityUnit || 'kg'}`
    : null;

  const readabilityDisplay = product.readabilityValue
    ? `${product.readabilityValue} ${product.readabilityUnit || 'g'}`
    : null;

  const directWhatsAppHref = buildBusinessWhatsAppUrl(
    `Hello ${BUSINESS_INFO.name}, I am viewing "${product.name}" (ID: ${product.id}) on your website and would like to ask about pricing and availability.`
  );

  return (
    <div className="container section">
      <div style={{ marginBottom: '1rem' }}>
        <Link to="/products">&larr; Back to Product Catalogue</Link>
      </div>

      <div className="grid-2">
        <div>
          <ProductImageGallery
            imagePaths={product.imagePaths}
            mainImagePath={product.mainImagePath}
            productName={product.name}
          />
        </div>

        <div className="card">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem', marginBottom: '0.5rem' }}>
            <span style={{ fontSize: '0.85rem', fontWeight: 700, color: 'var(--color-text-muted)' }}>
              {product.scaleType}
            </span>
            <StatusBadge
              status={product.availabilityStatus}
              label={formatAvailabilityLabel(product.availabilityStatus)}
            />
          </div>

          <h1 style={{ margin: '0 0 0.35rem 0', color: 'var(--color-navy)', fontSize: '1.75rem' }}>
            {product.name}
          </h1>
          <p style={{ margin: '0 0 1rem 0', fontSize: '0.82rem', color: 'var(--color-text-muted)' }}>
            Product ID: <code>{product.id}</code>
          </p>

          <div
            style={{
              backgroundColor: 'var(--color-bg)',
              padding: '1rem',
              borderRadius: 'var(--radius-sm)',
              marginBottom: '1.25rem',
              border: '1px solid var(--color-border)'
            }}
          >
            <div style={{ fontSize: '0.84rem', color: 'var(--color-text-muted)', fontWeight: 700 }}>
              {product.pricingMode === 'fixed' ? 'Displayed Reference Price' : 'Pricing Mode'}
            </div>
            <div style={{ fontSize: '1.5rem', fontWeight: 800, color: 'var(--color-navy)', marginTop: '0.2rem' }}>
              {product.pricingMode === 'fixed' && product.displayPricePaise
                ? formatPaiseToINR(product.displayPricePaise)
                : 'Request Price / Quotation'}
            </div>
            <div style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)', marginTop: '0.25rem' }}>
              {product.pricingMode === 'fixed'
                ? 'Displayed figure is a reference price. Final price depends on configuration, quantity, and current stock.'
                : 'Submit an enquiry or contact us for a quotation tailored to your capacity and quantity requirements.'}
            </div>
          </div>

          {/* Only render technical specifications that have actually been supplied */}
          <h2 style={{ fontSize: '1.1rem', color: 'var(--color-navy)', marginBottom: '0.5rem' }}>
            Verified Product Specifications
          </h2>
          <table className="data-table" style={{ marginBottom: '1.25rem' }}>
            <tbody>
              {product.brand && (
                <tr>
                  <th style={{ width: '42%' }}>Brand</th>
                  <td>{product.brand}</td>
                </tr>
              )}
              {product.model && (
                <tr>
                  <th>Model</th>
                  <td>{product.model}</td>
                </tr>
              )}
              {product.scaleType && (
                <tr>
                  <th>Scale Type</th>
                  <td>{product.scaleType}</td>
                </tr>
              )}
              {capacityDisplay && (
                <tr>
                  <th>Maximum Capacity</th>
                  <td>{capacityDisplay}</td>
                </tr>
              )}
              {readabilityDisplay && (
                <tr>
                  <th>Readability / Division</th>
                  <td>{readabilityDisplay}</td>
                </tr>
              )}
              {product.platformDimensions && (
                <tr>
                  <th>Platform Dimensions</th>
                  <td>{product.platformDimensions}</td>
                </tr>
              )}
              {product.powerSupply && (
                <tr>
                  <th>Power Supply</th>
                  <td>{product.powerSupply}</td>
                </tr>
              )}
            </tbody>
          </table>

          {product.specifications && (
            <div style={{ marginBottom: '1.25rem' }}>
              <h3 style={{ fontSize: '1rem', color: 'var(--color-navy)', margin: '0 0 0.35rem 0' }}>
                Additional Technical Specifications
              </h3>
              <p style={{ margin: 0, whiteSpace: 'pre-line', color: 'var(--color-text)' }}>
                {product.specifications}
              </p>
            </div>
          )}

          {product.description && (
            <div style={{ marginBottom: '1.5rem' }}>
              <h3 style={{ fontSize: '1rem', color: 'var(--color-navy)', margin: '0 0 0.35rem 0' }}>
                Product Description
              </h3>
              <p style={{ margin: 0, whiteSpace: 'pre-line', color: 'var(--color-text)' }}>
                {product.description}
              </p>
            </div>
          )}

          <div className="cta-row">
            <Button variant="primary" to={`/product-enquiry/${product.id}`}>
              I Want to Buy / Request a Quote
            </Button>
            <Button
              variant="whatsapp"
              href={directWhatsAppHref}
              target="_blank"
              rel="noopener noreferrer"
            >
              Ask on WhatsApp
            </Button>
            <Button variant="secondary" href={BUSINESS_INFO.phoneHref}>
              Call {BUSINESS_INFO.phoneDisplay}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
