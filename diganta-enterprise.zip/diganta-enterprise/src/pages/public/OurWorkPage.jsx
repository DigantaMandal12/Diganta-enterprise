import React from 'react';
import { BUSINESS_INFO, REPAIR_VIDEOS } from '../../config/businessConfig.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import { EmptyState } from '../../components/common/StateFeedback.jsx';
import Button from '../../components/common/Button.jsx';

/**
 * Extracts a safe 11-character YouTube video ID from a URL or raw ID string.
 */
function extractYouTubeId(urlOrId) {
  if (!urlOrId || typeof urlOrId !== 'string') return null;
  const trimmed = urlOrId.trim();
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    return trimmed;
  }
  try {
    const parsed = new URL(trimmed);
    if (parsed.hostname.includes('youtu.be')) {
      const id = parsed.pathname.replace('/', '').slice(0, 11);
      return /^[a-zA-Z0-9_-]{11}$/.test(id) ? id : null;
    }
    if (parsed.hostname.includes('youtube.com')) {
      const vParam = parsed.searchParams.get('v');
      if (vParam && /^[a-zA-Z0-9_-]{11}$/.test(vParam)) return vParam;
      const pathParts = parsed.pathname.split('/').filter(Boolean);
      const candidate = pathParts[pathParts.length - 1];
      if (candidate && /^[a-zA-Z0-9_-]{11}$/.test(candidate)) return candidate;
    }
  } catch {
    return null;
  }
  return null;
}

export default function OurWorkPage() {
  useDocumentTitle(
    'Repair Videos & Our Work',
    `Watch genuine weighing-scale repair, PCB troubleshooting, and calibration videos from ${BUSINESS_INFO.name} in ${BUSINESS_INFO.location}.`
  );

  const validVideos = (REPAIR_VIDEOS || [])
    .map((item, idx) => ({
      ...item,
      key: item.id || `video-${idx}`,
      videoId: extractYouTubeId(item.youtubeUrlOrId)
    }))
    .filter((item) => Boolean(item.videoId));

  return (
    <div className="container section">
      <div className="section-header">
        <h1 className="section-title">Repair Videos &amp; Our Work</h1>
        <p className="section-subtitle">
          Genuine weighing-scale repair demonstrations, PCB and transformer diagnostics, and workshop
          testing from {BUSINESS_INFO.name}.
        </p>
      </div>

      {validVideos.length === 0 ? (
        <EmptyState
          title="Repair videos will be added soon"
          description={`We only display genuine repair footage from ${BUSINESS_INFO.name}. No YouTube video links are currently configured in src/config/businessConfig.js. Contact us by phone or WhatsApp to discuss your weighing scale issue directly.`}
          actionLabel={`Call ${BUSINESS_INFO.phoneDisplay}`}
          onAction={() => {
            window.location.href = BUSINESS_INFO.phoneHref;
          }}
        />
      ) : (
        <div className="grid-2">
          {validVideos.map((video) => (
            <article key={video.key} className="card">
              <div className="video-embed-container" style={{ marginBottom: '0.9rem' }}>
                <iframe
                  src={`https://www.youtube-nocookie.com/embed/${video.videoId}?rel=0`}
                  title={video.title || 'Diganta Enterprise Weighing Scale Repair Video'}
                  loading="lazy"
                  allow="accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              </div>
              <h2 style={{ margin: '0 0 0.4rem 0', fontSize: '1.2rem', color: 'var(--color-navy)' }}>
                {video.title}
              </h2>
              {video.description && (
                <p style={{ margin: 0, color: 'var(--color-text-muted)', fontSize: '0.93rem' }}>
                  {video.description}
                </p>
              )}
            </article>
          ))}
        </div>
      )}

      <div className="card" style={{ marginTop: '2rem' }}>
        <h2 style={{ marginTop: 0, color: 'var(--color-navy)', fontSize: '1.25rem' }}>
          Have a Weighing Scale Fault?
        </h2>
        <p style={{ color: 'var(--color-text-muted)' }}>
          Whether your scale has a dead display, drifting weight readings, or a faulty transformer
          or motherboard, reach out by phone or WhatsApp during business hours ({BUSINESS_INFO.businessHours}).
        </p>
        <div className="cta-row">
          <Button variant="primary" href={BUSINESS_INFO.phoneHref}>
            Call {BUSINESS_INFO.phoneDisplay}
          </Button>
          <Button
            variant="whatsapp"
            href={BUSINESS_INFO.whatsappBaseUrl}
            target="_blank"
            rel="noopener noreferrer"
          >
            WhatsApp {BUSINESS_INFO.whatsappDisplay}
          </Button>
        </div>
      </div>
    </div>
  );
}
