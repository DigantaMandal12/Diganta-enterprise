import React from 'react';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import Button from '../../components/common/Button.jsx';

export default function AboutPage() {
  useDocumentTitle(
    `About ${BUSINESS_INFO.name}`,
    `Learn about ${BUSINESS_INFO.name} — Weighing Scale Repair & Sales in ${BUSINESS_INFO.location}.`
  );

  return (
    <div className="container section">
      <div className="section-header">
        <h1 className="section-title">About {BUSINESS_INFO.name}</h1>
        <p className="section-subtitle">
          Local weighing-scale repair and sales in {BUSINESS_INFO.location}.
        </p>
      </div>

      <div className="grid-2">
        <div className="card">
          <h2 style={{ marginTop: 0, color: 'var(--color-navy)' }}>What We Do</h2>
          <p>
            <strong>{BUSINESS_INFO.name}</strong> is a local weighing-scale repair and sales business
            based in <strong>{BUSINESS_INFO.location}</strong>. We focus on practical, component-level
            repair and maintenance of commercial and industrial weighing scales, as well as supplying
            new weighing equipment for local businesses, shopkeepers, and traders.
          </p>
          <p>
            Our technical work covers electronic weighing-scale troubleshooting, PCB and motherboard
            repair or fabrication where appropriate, and transformer repair or fabrication where
            appropriate.
          </p>
          <p style={{ marginBottom: 0 }}>
            We work with weighing scales across common capacities including{' '}
            <strong>{BUSINESS_INFO.supportedCapacities.join(', ')}</strong>, and handle known brands
            such as <strong>{BUSINESS_INFO.knownBrands.join(', ')}</strong> alongside other
            compatible commercial scale models.
          </p>
        </div>

        <div className="card">
          <h2 style={{ marginTop: 0, color: 'var(--color-navy)' }}>How We Work With Customers</h2>
          <ul style={{ paddingLeft: '1.2rem', lineHeight: '1.75', margin: '0 0 1.25rem 0' }}>
            <li>
              <strong>Direct Communication:</strong> Customers speak directly with the workshop via
              phone or WhatsApp ({BUSINESS_INFO.phoneDisplay}) during opening hours ({BUSINESS_INFO.businessHours}).
            </li>
            <li>
              <strong>Workshop &amp; On-Site Options:</strong> Portable scales can be brought to our
              workshop in Mohonpur, Ariabāṛā. For larger scales within approximately 10–20 km, on-site
              weighing-scale repair visits can be discussed based on the job and location.
            </li>
            <li>
              <strong>Clear Product Enquiries:</strong> When you enquire about purchasing a scale
              through our website, we review your capacity and readability requirements and respond
              with current availability and a quotation.
            </li>
          </ul>

          <div className="cta-row">
            <Button variant="primary" to="/services">
              Our Repair Services
            </Button>
            <Button variant="secondary" to="/products">
              Browse Products
            </Button>
            <Button variant="whatsapp" href={BUSINESS_INFO.whatsappBaseUrl} target="_blank" rel="noopener noreferrer">
              WhatsApp Us
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
