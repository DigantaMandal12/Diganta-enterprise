import React from 'react';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import { EmptyState } from '../../components/common/StateFeedback.jsx';

export default function NotFoundPage() {
  useDocumentTitle('Page Not Found (404)');

  return (
    <div className="container section">
      <EmptyState
        title="Page Not Found (404)"
        description="The page you requested does not exist or may have been moved."
        actionLabel="Return to Homepage"
        actionTo="/"
      />
    </div>
  );
}
