import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import { getProductById } from '../../services/productService.js';
import { getPublicProductImageUrl } from '../../services/storageService.js';
import { submitPublicProductEnquiry, buildProductSpecsSnapshot } from '../../services/enquiryService.js';
import { validateProductEnquiryForm } from '../../utils/validation.js';
import { buildEnquiryWhatsAppUrl } from '../../utils/whatsapp.js';
import { formatPaiseToINR } from '../../utils/currency.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import FormField from '../../components/forms/FormField.jsx';
import Button from '../../components/common/Button.jsx';
import { LoadingState, ErrorState, EmptyState } from '../../components/common/StateFeedback.jsx';

export default function ProductEnquiryPage() {
  const { productId } = useParams();
  useDocumentTitle('Request a Product Quote / Enquiry');

  const [product, setProduct] = useState(null);
  const [productImageUrl, setProductImageUrl] = useState('');
  const [loadingProduct, setLoadingProduct] = useState(true);
  const [loadError, setLoadError] = useState(null);

  const [formData, setFormData] = useState({
    customerName: '',
    phone: '',
    quantity: 1,
    preferredContactMethod: 'WhatsApp',
    requiredCapacity: '',
    requiredReadability: '',
    additionalRequirements: '',
    customerMessage: '',
    companyWebsiteHoneypot: '' // Honeypot field for automated bot filtering
  });

  const [fieldErrors, setFieldErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [submittedEnquiry, setSubmittedEnquiry] = useState(null);

  useEffect(() => {
    let active = true;
    setLoadingProduct(true);
    setLoadError(null);

    getProductById(productId)
      .then(async (item) => {
        if (!active) return;
        if (!item || !item.isPublished) {
          setProduct(null);
          setLoadingProduct(false);
          return;
        }
        setProduct(item);
        const defaultCap = item.maximumCapacityValue
          ? `${item.maximumCapacityValue} ${item.maximumCapacityUnit || 'kg'}`
          : '';
        const defaultRead = item.readabilityValue
          ? `${item.readabilityValue} ${item.readabilityUnit || 'g'}`
          : '';
        setFormData((prev) => ({
          ...prev,
          requiredCapacity: prev.requiredCapacity || defaultCap,
          requiredReadability: prev.requiredReadability || defaultRead
        }));

        const mainPath =
          item.mainImagePath ||
          (Array.isArray(item.imagePaths) && item.imagePaths.length > 0 ? item.imagePaths[0] : '');
        if (mainPath) {
          try {
            const url = await getPublicProductImageUrl(mainPath);
            if (active && url) setProductImageUrl(url);
          } catch {
            // Optional image URL snapshot; ignore if unavailable
          }
        }
        setLoadingProduct(false);
      })
      .catch((err) => {
        if (!active) return;
        setLoadError(err?.message || 'Unable to load the selected product.');
        setLoadingProduct(false);
      });

    return () => {
      active = false;
    };
  }, [productId]);

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    if (fieldErrors[field]) {
      setFieldErrors((prev) => ({ ...prev, [field]: null }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSubmitting) return;

    setSubmitError(null);

    // Honeypot check: reject automated bots filling the hidden trap field
    if (formData.companyWebsiteHoneypot && formData.companyWebsiteHoneypot.trim() !== '') {
      setSubmitError('Submission rejected by spam filter.');
      return;
    }

    const validation = validateProductEnquiryForm(formData, product);
    if (!validation.isValid) {
      setFieldErrors(validation.errors);
      return;
    }

    setFieldErrors({});
    setIsSubmitting(true);

    try {
      const saved = await submitPublicProductEnquiry({
        product,
        productImageUrl,
        sanitizedInput: validation.sanitized
      });
      setSubmittedEnquiry(saved);
    } catch (err) {
      setSubmitError(
        err?.message ||
          'Your product enquiry could not be confirmed as saved. Your form entries have been preserved — please retry or contact us via phone/WhatsApp.'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loadingProduct) {
    return (
      <div className="container section">
        <LoadingState message="Loading selected product details…" />
      </div>
    );
  }

  if (loadError) {
    return (
      <div className="container section">
        <ErrorState title="Could not load product" message={loadError} />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container section">
        <EmptyState
          title="Selected product is unavailable"
          description="Product enquiries can only be submitted for published weighing scales in our catalogue."
          actionLabel="Browse Published Products"
          actionTo="/products"
        />
      </div>
    );
  }

  // Confirmation view shown ONLY after Firestore write succeeds
  if (submittedEnquiry) {
    const whatsappHref = buildEnquiryWhatsAppUrl({
      enquiryId: submittedEnquiry.enquiryId,
      productName: product.name,
      productBrand: product.brand,
      productModel: product.model,
      productSpecifications: buildProductSpecsSnapshot(product),
      productImageUrl,
      quantity: submittedEnquiry.quantity,
      customerName: submittedEnquiry.customerName,
      phone: submittedEnquiry.phone,
      preferredContactMethod: submittedEnquiry.preferredContactMethod,
      requiredCapacity: submittedEnquiry.requiredCapacity,
      requiredReadability: submittedEnquiry.requiredReadability,
      additionalRequirements: submittedEnquiry.additionalRequirements,
      quotedPricePaise: null
    });

    return (
      <div className="container section">
        <div className="card" style={{ maxWidth: '680px', margin: '0 auto', borderTop: '5px solid var(--color-success-text)' }}>
          <span className="badge badge-success" style={{ marginBottom: '0.75rem' }}>
            Enquiry Saved
          </span>
          <h1 style={{ marginTop: 0, color: 'var(--color-navy)', fontSize: '1.65rem' }}>
            Product Enquiry Received
          </h1>
          <p>
            Thank you, <strong>{submittedEnquiry.customerName}</strong>. Your product enquiry for{' '}
            <strong>{product.name}</strong> (Quantity: {submittedEnquiry.quantity}) has been saved.
          </p>

          <div
            style={{
              backgroundColor: 'var(--color-bg)',
              padding: '1rem',
              borderRadius: 'var(--radius-sm)',
              border: '1px solid var(--color-border)',
              marginBottom: '1.25rem'
            }}
          >
            <div style={{ fontSize: '0.84rem', color: 'var(--color-text-muted)' }}>
              Enquiry Reference ID (Keep for your records):
            </div>
            <div style={{ fontSize: '1.3rem', fontWeight: 800, color: 'var(--color-navy)', fontFamily: 'monospace' }}>
              {submittedEnquiry.enquiryId}
            </div>
          </div>

          <div className="alert alert-info">
            <strong>Important Note:</strong> Submitting this enquiry is a request for availability
            and pricing — it is <strong>not</strong> a confirmed order or payment. You can also send
            the prefilled enquiry details directly to our WhatsApp below for a faster response
            (remember to tap Send inside WhatsApp).
          </div>

          <div className="cta-row" style={{ marginTop: '1.25rem' }}>
            <Button
              variant="whatsapp"
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
            >
              Send Enquiry Details via WhatsApp
            </Button>
            <Button variant="primary" href={BUSINESS_INFO.phoneHref}>
              Call {BUSINESS_INFO.phoneDisplay}
            </Button>
            <Button variant="secondary" to={`/products/${product.id}`}>
              Back to Product Page
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container section">
      <div style={{ marginBottom: '1rem' }}>
        <Link to={`/products/${product.id}`}>&larr; Back to {product.name}</Link>
      </div>

      <div className="grid-2">
        {/* Selected Product Summary Card */}
        <div>
          <div className="card">
            <h2 style={{ marginTop: 0, color: 'var(--color-navy)', fontSize: '1.25rem' }}>
              Selected Product
            </h2>
            {productImageUrl && (
              <div className="product-photo-box" style={{ maxHeight: '220px' }}>
                <img src={productImageUrl} alt={product.name} />
              </div>
            )}
            <h3 style={{ margin: '0 0 0.35rem 0', color: 'var(--color-navy)' }}>{product.name}</h3>
            <p style={{ margin: '0 0 0.75rem 0', fontSize: '0.86rem', color: 'var(--color-text-muted)' }}>
              Product ID: <code>{product.id}</code>
            </p>
            <ul style={{ paddingLeft: '1.15rem', fontSize: '0.92rem', margin: '0 0 1rem 0' }}>
              {product.scaleType && <li>Scale Type: <strong>{product.scaleType}</strong></li>}
              {product.brand && <li>Brand: <strong>{product.brand}</strong></li>}
              {product.model && <li>Model: <strong>{product.model}</strong></li>}
              {product.maximumCapacityValue && (
                <li>
                  Maximum Capacity:{' '}
                  <strong>
                    {product.maximumCapacityValue} {product.maximumCapacityUnit || 'kg'}
                  </strong>
                </li>
              )}
              {product.readabilityValue && (
                <li>
                  Readability / Division:{' '}
                  <strong>
                    {product.readabilityValue} {product.readabilityUnit || 'g'}
                  </strong>
                </li>
              )}
              {product.platformDimensions && <li>Platform: {product.platformDimensions}</li>}
              {product.pricingMode === 'fixed' && product.displayPricePaise && (
                <li>
                  Reference Price: <strong>{formatPaiseToINR(product.displayPricePaise)}</strong>
                </li>
              )}
            </ul>
            <p style={{ fontSize: '0.84rem', color: 'var(--color-text-muted)', margin: 0 }}>
              Need weighing-scale repair instead of purchasing a product? Please call or WhatsApp{' '}
              <a href={BUSINESS_INFO.phoneHref}>{BUSINESS_INFO.phoneDisplay}</a> directly.
            </p>
          </div>
        </div>

        {/* Customer Enquiry Form */}
        <div className="card">
          <h1 style={{ marginTop: 0, color: 'var(--color-navy)', fontSize: '1.5rem' }}>
            Request Price &amp; Availability
          </h1>
          <p style={{ color: 'var(--color-text-muted)', fontSize: '0.92rem', marginBottom: '1.25rem' }}>
            Complete the form below to save your product enquiry with {BUSINESS_INFO.name}.
            After saving, you will receive a reference number and an option to message us on WhatsApp.
          </p>

          {submitError && (
            <div className="alert alert-error" role="alert">
              <strong>Enquiry Not Saved:</strong> {submitError}
            </div>
          )}

          <form onSubmit={handleSubmit} noValidate>
            {/* Unobtrusive Honeypot Field */}
            <div className="hp-trap" aria-hidden="true">
              <label htmlFor="company-website-hp">Company Website (leave blank)</label>
              <input
                id="company-website-hp"
                type="text"
                tabIndex={-1}
                autoComplete="off"
                value={formData.companyWebsiteHoneypot}
                onChange={(e) => handleChange('companyWebsiteHoneypot', e.target.value)}
              />
            </div>

            <FormField
              id="enquiry-customer-name"
              label="Your Name"
              required
              error={fieldErrors.customerName}
            >
              <input
                id="enquiry-customer-name"
                type="text"
                className="form-input"
                required
                value={formData.customerName}
                onChange={(e) => handleChange('customerName', e.target.value)}
                placeholder="Enter your full name"
              />
            </FormField>

            <FormField
              id="enquiry-phone"
              label="Phone / WhatsApp Number"
              required
              hint="Indian 10-digit mobile number (spaces or +91 allowed)"
              error={fieldErrors.phone}
            >
              <input
                id="enquiry-phone"
                type="tel"
                className="form-input"
                required
                value={formData.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
                placeholder="e.g. +91 98765 43210"
              />
            </FormField>

            <div className="grid-2">
              <FormField
                id="enquiry-quantity"
                label="Quantity"
                required
                error={fieldErrors.quantity}
              >
                <input
                  id="enquiry-quantity"
                  type="number"
                  min="1"
                  max="1000"
                  className="form-input"
                  required
                  value={formData.quantity}
                  onChange={(e) => handleChange('quantity', e.target.value)}
                />
              </FormField>

              <FormField
                id="enquiry-contact-method"
                label="Preferred Contact Method"
                required
                error={fieldErrors.preferredContactMethod}
              >
                <select
                  id="enquiry-contact-method"
                  className="form-select"
                  value={formData.preferredContactMethod}
                  onChange={(e) => handleChange('preferredContactMethod', e.target.value)}
                >
                  <option value="WhatsApp">WhatsApp</option>
                  <option value="Phone Call">Phone Call</option>
                  <option value="Either">Either Phone or WhatsApp</option>
                </select>
              </FormField>
            </div>

            <div className="grid-2">
              <FormField
                id="enquiry-capacity"
                label="Required Maximum Capacity (Optional)"
                error={fieldErrors.requiredCapacity}
              >
                <input
                  id="enquiry-capacity"
                  type="text"
                  className="form-input"
                  value={formData.requiredCapacity}
                  onChange={(e) => handleChange('requiredCapacity', e.target.value)}
                  placeholder="e.g. 30 kg or 100 kg"
                />
              </FormField>

              <FormField
                id="enquiry-readability"
                label="Required Readability (Optional)"
                error={fieldErrors.requiredReadability}
              >
                <input
                  id="enquiry-readability"
                  type="text"
                  className="form-input"
                  value={formData.requiredReadability}
                  onChange={(e) => handleChange('requiredReadability', e.target.value)}
                  placeholder="e.g. 1 g, 5 g, 10 g"
                />
              </FormField>
            </div>

            <FormField
              id="enquiry-additional"
              label="Additional Technical Requirements (Optional)"
              error={fieldErrors.additionalRequirements}
            >
              <input
                id="enquiry-additional"
                type="text"
                className="form-input"
                value={formData.additionalRequirements}
                onChange={(e) => handleChange('additionalRequirements', e.target.value)}
                placeholder="e.g. Platform size preference, pole display, battery backup"
              />
            </FormField>

            <FormField
              id="enquiry-message"
              label="Message or Questions (Optional)"
            >
              <textarea
                id="enquiry-message"
                className="form-textarea"
                value={formData.customerMessage}
                onChange={(e) => handleChange('customerMessage', e.target.value)}
                placeholder="Any questions regarding delivery, pickup from Mohonpur, or usage"
              />
            </FormField>

            <div className="cta-row" style={{ marginTop: '1.25rem' }}>
              <Button type="submit" variant="primary" disabled={isSubmitting}>
                {isSubmitting ? 'Saving Enquiry…' : 'Submit Product Enquiry'}
              </Button>
              <Button variant="secondary" href={BUSINESS_INFO.phoneHref}>
                Or Call {BUSINESS_INFO.phoneDisplay}
              </Button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
