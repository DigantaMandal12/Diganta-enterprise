import React from 'react';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';

export default function PrivacyPage() {
  useDocumentTitle(
    'Privacy Notice',
    `Privacy Notice for ${BUSINESS_INFO.name} — how customer product enquiries and repair records are handled.`
  );

  return (
    <div className="container section">
      <div className="card" style={{ maxWidth: '820px', margin: '0 auto' }}>
        <h1 style={{ marginTop: 0, color: 'var(--color-navy)' }}>Privacy Notice</h1>
        <p style={{ color: 'var(--color-text-muted)' }}>
          Effective for {BUSINESS_INFO.name} — {BUSINESS_INFO.tagline} ({BUSINESS_INFO.location}).
        </p>

        <h2 style={{ fontSize: '1.2rem', color: 'var(--color-navy)' }}>
          1. Information We Collect
        </h2>
        <p>
          When you submit a product enquiry on our website, we collect your name, phone number,
          preferred contact method, selected product details, quantity, and any capacity or technical
          requirements you choose to share. When you bring or schedule a weighing scale for repair,
          the business administrator records your name, phone number, scale details, repair work,
          and payment history in our private repair management system.
        </p>

        <h2 style={{ fontSize: '1.2rem', color: 'var(--color-navy)' }}>
          2. How Your Information Is Used
        </h2>
        <p>
          We use your contact and equipment details strictly to respond to your product enquiries,
          provide price quotations, perform weighing-scale repairs, and maintain accurate service
          and payment records for {BUSINESS_INFO.name}.
        </p>

        <h2 style={{ fontSize: '1.2rem', color: 'var(--color-navy)' }}>
          3. Data Storage &amp; Access Controls
        </h2>
        <p>
          Customer product enquiries, repair records, payment logs, and equipment photographs are
          stored in Google Firebase (Cloud Firestore and Cloud Storage) protected by security rules
          that restrict access to the authorised business administrator. Equipment photographs taken
          during repairs are kept private and are not published on the public catalogue.
        </p>

        <h2 style={{ fontSize: '1.2rem', color: 'var(--color-navy)' }}>
          4. Third-Party Services (WhatsApp &amp; YouTube)
        </h2>
        <p>
          When you click a WhatsApp link (`wa.me`), you are directed to WhatsApp to review and send
          your message under WhatsApp&apos;s own privacy terms. Embedded repair videos on our{' '}
          <em>Our Work</em> page use YouTube&apos;s privacy-enhanced embed mode (`youtube-nocookie.com`).
        </p>

        <h2 style={{ fontSize: '1.2rem', color: 'var(--color-navy)' }}>
          5. Contact Us
        </h2>
        <p style={{ marginBottom: 0 }}>
          For any questions about your enquiry or repair records, contact {BUSINESS_INFO.name} at{' '}
          <a href={BUSINESS_INFO.phoneHref}>{BUSINESS_INFO.phoneDisplay}</a> during business hours (
          {BUSINESS_INFO.businessHours}).
        </p>
      </div>
    </div>
  );
}
