import React from 'react';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import { buildBusinessWhatsAppUrl } from '../../utils/whatsapp.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import Button from '../../components/common/Button.jsx';

export default function ContactPage() {
  useDocumentTitle(
    'Contact Us',
    `Contact ${BUSINESS_INFO.name} in ${BUSINESS_INFO.location}. Call or WhatsApp ${BUSINESS_INFO.phoneDisplay}, Monday–Sunday, 10:00 AM–10:00 PM.`
  );

  const whatsappHref = buildBusinessWhatsAppUrl(
    `Hello ${BUSINESS_INFO.name}, I would like to get in touch regarding weighing scale repair or sales.`
  );

  return (
    <div className="container section">
      <div className="section-header">
        <h1 className="section-title">
          Contact {BUSINESS_INFO.name} — {BUSINESS_INFO.tagline}
        </h1>
        <p className="section-subtitle">
          Reach out by telephone or WhatsApp for weighing-scale repair enquiries, workshop drop-off,
          on-site scale visit discussions, or product sales.
        </p>
      </div>

      <div className="grid-2">
        <div className="card" style={{ borderTop: '4px solid var(--color-orange)' }}>
          <h2 style={{ marginTop: 0, color: 'var(--color-navy)' }}>Verified Contact Information</h2>
          <table className="data-table" style={{ marginBottom: '1.25rem' }}>
            <tbody>
              <tr>
                <th style={{ width: '38%' }}>Business Name</th>
                <td>{BUSINESS_INFO.name} — {BUSINESS_INFO.tagline}</td>
              </tr>
              <tr>
                <th>Phone</th>
                <td>
                  <a href={BUSINESS_INFO.phoneHref} style={{ fontWeight: 700 }}>
                    {BUSINESS_INFO.phoneDisplay}
                  </a>
                </td>
              </tr>
              <tr>
                <th>WhatsApp</th>
                <td>
                  <a
                    href={BUSINESS_INFO.whatsappBaseUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    style={{ fontWeight: 700 }}
                  >
                    {BUSINESS_INFO.whatsappDisplay}
                  </a>
                </td>
              </tr>
              <tr>
                <th>Location</th>
                <td>{BUSINESS_INFO.location}</td>
              </tr>
              <tr>
                <th>Service Radius</th>
                <td>{BUSINESS_INFO.serviceRadius}</td>
              </tr>
              <tr>
                <th>Opening Hours</th>
                <td>{BUSINESS_INFO.businessHours}</td>
              </tr>
            </tbody>
          </table>

          <div className="cta-row">
            <Button variant="primary" href={BUSINESS_INFO.phoneHref}>
              Call {BUSINESS_INFO.phoneDisplay}
            </Button>
            <Button
              variant="whatsapp"
              href={whatsappHref}
              target="_blank"
              rel="noopener noreferrer"
            >
              Chat on WhatsApp
            </Button>
          </div>
        </div>

        <div className="card">
          <h2 style={{ marginTop: 0, color: 'var(--color-navy)' }}>
            Enquiry Guidelines
          </h2>
          <h3 style={{ fontSize: '1.05rem', color: 'var(--color-navy)', marginBottom: '0.35rem' }}>
            For Weighing-Scale Repairs
          </h3>
          <p style={{ color: 'var(--color-text-muted)', marginTop: 0 }}>
            Please call or message on WhatsApp directly. Tell us the scale&apos;s capacity (e.g.
            10 kg, 30 kg, 100 kg, 150–300 kg), brand, and the issue you are experiencing. We will
            advise whether to bring the scale to our workshop in {BUSINESS_INFO.location} or whether
            an on-site weighing-scale repair visit within {BUSINESS_INFO.serviceRadius.toLowerCase()}{' '}
            is appropriate.
          </p>

          <h3 style={{ fontSize: '1.05rem', color: 'var(--color-navy)', marginBottom: '0.35rem' }}>
            For Purchasing a Weighing Scale
          </h3>
          <p style={{ color: 'var(--color-text-muted)', marginTop: 0 }}>
            Browse our <a href="/products">Product Catalogue</a> and select{' '}
            <strong>Request Quote</strong> on any published scale to save a product enquiry, or call
            / WhatsApp us directly.
          </p>
        </div>
      </div>
    </div>
  );
}
