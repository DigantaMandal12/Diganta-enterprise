import React from 'react';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import { buildBusinessWhatsAppUrl } from '../../utils/whatsapp.js';
import { useDocumentTitle } from '../../hooks/useDocumentTitle.js';
import Button from '../../components/common/Button.jsx';

export default function ServicesPage() {
  useDocumentTitle(
    'Weighing-Scale Repair Services',
    `Electronic weighing-scale repair, PCB and motherboard repair, transformer repair, workshop service, and on-site scale repair in ${BUSINESS_INFO.location}.`
  );

  const repairWhatsappUrl = buildBusinessWhatsAppUrl(
    `Hello ${BUSINESS_INFO.name}, I need help with a weighing scale repair.`
  );

  return (
    <div className="container section">
      <div className="section-header">
        <h1 className="section-title">Weighing-Scale Repair Services</h1>
        <p className="section-subtitle">
          Dedicated repair and electronic troubleshooting for commercial, retail, and platform
          weighing scales in {BUSINESS_INFO.location} ({BUSINESS_INFO.serviceRadius} radius).
        </p>
      </div>

      <div className="alert alert-info">
        <strong>Clear Scope of Work:</strong> {BUSINESS_INFO.name} repairs electronic and mechanical
        weighing scales only. &ldquo;On-site service&rdquo; means travelling to a customer&apos;s
        premise to repair weighing scales. We do <strong>not</strong> repair mobile phones.
      </div>

      <div className="grid-2" style={{ marginBottom: '2rem' }}>
        <div className="card">
          <h2 style={{ marginTop: 0, color: 'var(--color-navy)', fontSize: '1.25rem' }}>
            1. Electronic Weighing-Scale Troubleshooting
          </h2>
          <p style={{ color: 'var(--color-text-muted)' }}>
            Diagnosis and repair of common and complex weighing-scale faults across capacities
            including {BUSINESS_INFO.supportedCapacities.join(', ')}:
          </p>
          <ul style={{ paddingLeft: '1.2rem', margin: 0 }}>
            <li>Drifting, unstable, or inaccurate weight readings</li>
            <li>Load-cell wiring, connector, and sensor signal troubleshooting</li>
            <li>LED / LCD display segment failures and indicator board issues</li>
            <li>Keypad / membrane switch unresponsiveness</li>
            <li>Battery charging circuit and power-supply faults</li>
          </ul>
        </div>

        <div className="card">
          <h2 style={{ marginTop: 0, color: 'var(--color-navy)', fontSize: '1.25rem' }}>
            2. PCB, Motherboard &amp; Transformer Repair
          </h2>
          <p style={{ color: 'var(--color-text-muted)' }}>
            Rather than replacing entire assemblies unnecessarily, we inspect internal scale electronics:
          </p>
          <ul style={{ paddingLeft: '1.2rem', margin: 0 }}>
            <li>Weighing-scale PCB and motherboard fault isolation and soldering</li>
            <li>PCB repair or fabrication where appropriate for the scale model</li>
            <li>Transformer testing, repair, or fabrication where appropriate</li>
            <li>Voltage regulator, bridge rectifier, and filter capacitor replacement</li>
            <li>Replacement of damaged internal harnesses and connectors</li>
          </ul>
        </div>

        <div className="card">
          <h2 style={{ marginTop: 0, color: 'var(--color-navy)', fontSize: '1.25rem' }}>
            3. Workshop Repair Service
          </h2>
          <p style={{ color: 'var(--color-text-muted)', marginBottom: 0 }}>
            Customers can bring portable tabletop, price-computing, bench, and compact platform scales
            directly to our workshop in <strong>{BUSINESS_INFO.location}</strong> during business
            hours ({BUSINESS_INFO.businessHours}). We inspect the equipment, explain the fault, and
            discuss estimated repair costs before proceeding with major component work.
          </p>
        </div>

        <div className="card">
          <h2 style={{ marginTop: 0, color: 'var(--color-navy)', fontSize: '1.25rem' }}>
            4. On-Site Weighing-Scale Repair Visits
          </h2>
          <p style={{ color: 'var(--color-text-muted)', marginBottom: 0 }}>
            For heavy platform scales or stationary commercial weighing equipment within{' '}
            <strong>{BUSINESS_INFO.serviceRadius.toLowerCase()}</strong> of {BUSINESS_INFO.location},
            we can travel to your location depending on the nature of the fault and distance. Please
            call or message on WhatsApp first to describe the scale capacity, brand/model, and fault
            symptoms so we can confirm availability and applicable visit charges.
          </p>
        </div>
      </div>

      {/* How to Request a Repair */}
      <div className="card" style={{ borderTop: '4px solid var(--color-orange)' }}>
        <h2 style={{ marginTop: 0, color: 'var(--color-navy)' }}>
          How to Arrange a Weighing-Scale Repair
        </h2>
        <p style={{ color: 'var(--color-text-muted)' }}>
          To keep repair coordination fast and clear, all repair enquiries are handled directly by
          telephone or WhatsApp rather than an automated web queue. When you contact us, it helps to
          share:
        </p>
        <ol style={{ paddingLeft: '1.25rem', marginBottom: '1.25rem' }}>
          <li>Scale capacity (for example: 10 kg, 30 kg, 100 kg, or 300 kg) and brand (such as Vison Tech or others).</li>
          <li>What fault you are seeing (for example: scale not powering on, wrong weight reading, display error).</li>
          <li>Whether you plan to bring the scale to Mohonpur or are asking about an on-site visit within ~10–20 km.</li>
        </ol>

        <div className="cta-row">
          <Button variant="primary" href={BUSINESS_INFO.phoneHref}>
            Call {BUSINESS_INFO.phoneDisplay}
          </Button>
          <Button
            variant="whatsapp"
            href={repairWhatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
          >
            WhatsApp {BUSINESS_INFO.whatsappDisplay}
          </Button>
          <Button variant="secondary" to="/products">
            Looking to Buy a Scale? Browse Catalogue
          </Button>
        </div>
      </div>
    </div>
  );
}
