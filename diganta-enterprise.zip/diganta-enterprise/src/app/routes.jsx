import React from 'react';
import { Routes, Route } from 'react-router-dom';

import PublicLayout from '../components/layout/PublicLayout.jsx';
import AdminLayout from '../components/layout/AdminLayout.jsx';
import ProtectedRoute from '../components/layout/ProtectedRoute.jsx';

import HomePage from '../pages/public/HomePage.jsx';
import ServicesPage from '../pages/public/ServicesPage.jsx';
import ProductsPage from '../pages/public/ProductsPage.jsx';
import ProductDetailPage from '../pages/public/ProductDetailPage.jsx';
import ProductEnquiryPage from '../pages/public/ProductEnquiryPage.jsx';
import OurWorkPage from '../pages/public/OurWorkPage.jsx';
import AboutPage from '../pages/public/AboutPage.jsx';
import ContactPage from '../pages/public/ContactPage.jsx';
import PrivacyPage from '../pages/public/PrivacyPage.jsx';
import NotFoundPage from '../pages/public/NotFoundPage.jsx';

import AdminLoginPage from '../pages/admin/AdminLoginPage.jsx';
import AdminDashboardPage from '../pages/admin/AdminDashboardPage.jsx';
import AdminRepairsPage from '../pages/admin/AdminRepairsPage.jsx';
import AdminRepairFormPage from '../pages/admin/AdminRepairFormPage.jsx';
import AdminProductsPage from '../pages/admin/AdminProductsPage.jsx';
import AdminProductFormPage from '../pages/admin/AdminProductFormPage.jsx';
import AdminEnquiriesPage from '../pages/admin/AdminEnquiriesPage.jsx';
import AdminEnquiryDetailPage from '../pages/admin/AdminEnquiryDetailPage.jsx';
import AdminExpensesPage from '../pages/admin/AdminExpensesPage.jsx';
import AdminReportsPage from '../pages/admin/AdminReportsPage.jsx';

export default function AppRoutes() {
  return (
    <Routes>
      {/* Public Website Routes */}
      <Route element={<PublicLayout />}>
        <Route path="/" element={<HomePage />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/products" element={<ProductsPage />} />
        <Route path="/products/:productId" element={<ProductDetailPage />} />
        <Route path="/product-enquiry/:productId" element={<ProductEnquiryPage />} />
        <Route path="/our-work" element={<OurWorkPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/privacy" element={<PrivacyPage />} />
        <Route path="/admin/login" element={<AdminLoginPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Route>

      {/* Protected Administrator Routes */}
      <Route
        path="/admin"
        element={
          <ProtectedRoute>
            <AdminLayout />
          </ProtectedRoute>
        }
      >
        <Route index element={<AdminDashboardPage />} />
        <Route path="repairs" element={<AdminRepairsPage />} />
        <Route path="repairs/new" element={<AdminRepairFormPage />} />
        <Route path="repairs/:repairId" element={<AdminRepairFormPage />} />
        <Route path="products" element={<AdminProductsPage />} />
        <Route path="products/new" element={<AdminProductFormPage />} />
        <Route path="products/:productId/edit" element={<AdminProductFormPage />} />
        <Route path="enquiries" element={<AdminEnquiriesPage />} />
        <Route path="enquiries/:enquiryId" element={<AdminEnquiryDetailPage />} />
        <Route path="expenses" element={<AdminExpensesPage />} />
        <Route path="reports" element={<AdminReportsPage />} />
      </Route>
    </Routes>
  );
}
