import React, { useEffect, useState } from 'react';
import { getPublicProductImageUrl } from '../../services/storageService.js';

export default function ProductImageGallery({ imagePaths = [], mainImagePath = '', productName = 'Product' }) {
  const [resolvedUrls, setResolvedUrls] = useState([]);
  const [selectedUrl, setSelectedUrl] = useState(null);

  useEffect(() => {
    let active = true;
    const orderedPaths = [];
    if (mainImagePath) orderedPaths.push(mainImagePath);
    (imagePaths || []).forEach((p) => {
      if (p && !orderedPaths.includes(p)) orderedPaths.push(p);
    });

    if (orderedPaths.length === 0) {
      setResolvedUrls([]);
      setSelectedUrl(null);
      return () => {};
    }

    Promise.all(
      orderedPaths.map(async (p) => {
        try {
          const url = await getPublicProductImageUrl(p);
          return { path: p, url };
        } catch {
          return null;
        }
      })
    ).then((items) => {
      if (!active) return;
      const valid = items.filter((item) => item && item.url);
      setResolvedUrls(valid);
      setSelectedUrl(valid.length > 0 ? valid[0].url : null);
    });

    return () => {
      active = false;
    };
  }, [imagePaths, mainImagePath]);

  if (resolvedUrls.length === 0) {
    return (
      <div className="product-photo-box" style={{ minHeight: '260px' }}>
        <div className="photo-placeholder">Product photo not added</div>
      </div>
    );
  }

  return (
    <div>
      <div className="product-photo-box" style={{ minHeight: '280px' }}>
        <img src={selectedUrl} alt={`${productName} photograph`} />
      </div>
      {resolvedUrls.length > 1 && (
        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
          {resolvedUrls.map((item, idx) => (
            <button
              key={item.path}
              type="button"
              onClick={() => setSelectedUrl(item.url)}
              style={{
                width: '72px',
                height: '56px',
                padding: 0,
                border: selectedUrl === item.url ? '2px solid var(--color-orange)' : '1px solid var(--color-border)',
                borderRadius: '4px',
                overflow: 'hidden',
                cursor: 'pointer',
                background: '#fff'
              }}
              aria-label={`View product photo ${idx + 1}`}
            >
              <img
                src={item.url}
                alt={`${productName} thumbnail ${idx + 1}`}
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
