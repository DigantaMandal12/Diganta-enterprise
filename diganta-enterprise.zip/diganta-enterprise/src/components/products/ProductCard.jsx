import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import Button from '../common/Button.jsx';
import StatusBadge, { formatAvailabilityLabel } from '../common/StatusBadge.jsx';
import { formatPaiseToINR } from '../../utils/currency.js';
import { getPublicProductImageUrl } from '../../services/storageService.js';

export default function ProductCard({ product }) {
  const [imageUrl, setImageUrl] = useState(null);

  const primaryPath =
    product.mainImagePath ||
    (Array.isArray(product.imagePaths) && product.imagePaths.length > 0 ? product.imagePaths[0] : '');

  useEffect(() => {
    let active = true;
    if (!primaryPath) {
      setImageUrl(null);
      return () => {};
    }
    getPublicProductImageUrl(primaryPath)
      .then((url) => {
        if (active) setImageUrl(url);
      })
      .catch(() => {
        if (active) setImageUrl(null);
      });
    return () => {
      active = false;
    };
  }, [primaryPath]);

  const capacityText = product.maximumCapacityValue
    ? `${product.maximumCapacityValue} ${product.maximumCapacityUnit || 'kg'}`
    : null;

  const readabilityText = product.readabilityValue
    ? `${product.readabilityValue} ${product.readabilityUnit || 'g'}`
    : null;

  return (
    <article className="card product-card">
      <div>
        <div className="product-photo-box">
          {imageUrl ? (
            <img
              src={imageUrl}
              alt={`${product.name} weighing scale`}
              loading="lazy"
            />
          ) : (
            <div className="photo-placeholder">Product photo not added</div>
          )}
        </div>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
          <span style={{ fontSize: '0.8rem', fontWeight: 700, color: 'var(--color-text-muted)' }}>
            {product.scaleType || 'Weighing Scale'}
          </span>
          <StatusBadge
            status={product.availabilityStatus}
            label={formatAvailabilityLabel(product.availabilityStatus)}
          />
        </div>

        <h3 style={{ margin: '0 0 0.35rem 0', fontSize: '1.15rem', color: 'var(--color-navy)' }}>
          <Link to={`/products/${product.id}`} style={{ textDecoration: 'none' }}>
            {product.name}
          </Link>
        </h3>

        {(product.brand || product.model) && (
          <p style={{ margin: '0 0 0.5rem 0', fontSize: '0.88rem', color: 'var(--color-text-muted)' }}>
            {[product.brand && `Brand: ${product.brand}`, product.model && `Model: ${product.model}`]
              .filter(Boolean)
              .join(' • ')}
          </p>
        )}

        <ul style={{ margin: '0 0 0.9rem 0', paddingLeft: '1.1rem', fontSize: '0.9rem', color: 'var(--color-text)' }}>
          {capacityText && <li>Max Capacity: <strong>{capacityText}</strong></li>}
          {readabilityText && <li>Readability: <strong>{readabilityText}</strong></li>}
          {product.platformDimensions && <li>Platform: {product.platformDimensions}</li>}
        </ul>
      </div>

      <div>
        <div
          style={{
            padding: '0.6rem 0',
            borderTop: '1px solid var(--color-border)',
            marginBottom: '0.75rem',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'baseline'
          }}
        >
          <span style={{ fontSize: '0.82rem', color: 'var(--color-text-muted)' }}>
            {product.pricingMode === 'fixed' ? 'Reference Price:' : 'Pricing:'}
          </span>
          <strong style={{ fontSize: '1.1rem', color: 'var(--color-navy)' }}>
            {product.pricingMode === 'fixed' && product.displayPricePaise
              ? formatPaiseToINR(product.displayPricePaise, { compactWhole: true })
              : 'Request Price'}
          </strong>
        </div>

        <div className="cta-row">
          <Button variant="secondary" size="sm" to={`/products/${product.id}`} style={{ flex: 1 }}>
            View Details
          </Button>
          <Button variant="primary" size="sm" to={`/product-enquiry/${product.id}`} style={{ flex: 1 }}>
            Request Quote
          </Button>
        </div>
      </div>
    </article>
  );
}
