import React from 'react';
import { usePrivateStorageImage } from '../../hooks/usePrivateStorageImage.js';
import Button from '../common/Button.jsx';

function PrivatePhotoTile({ storagePath, onRemove, disabled }) {
  const { objectUrl, loading, error } = usePrivateStorageImage(storagePath);

  return (
    <div className="card" style={{ padding: '0.6rem' }}>
      <div className="product-photo-box" style={{ marginBottom: '0.5rem', aspectRatio: '4 / 3' }}>
        {loading && <div className="photo-placeholder">Loading private photo…</div>}
        {error && <div className="photo-placeholder" style={{ color: 'var(--color-error-text)' }}>{error}</div>}
        {!loading && !error && objectUrl && (
          <img src={objectUrl} alt="Private repair record photograph" />
        )}
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '0.5rem' }}>
        <span style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', wordBreak: 'break-all' }}>
          {storagePath.split('/').pop()}
        </span>
        {onRemove && (
          <Button
            variant="danger"
            size="sm"
            onClick={() => onRemove(storagePath)}
            disabled={disabled}
          >
            Remove
          </Button>
        )}
      </div>
    </div>
  );
}

export default function PrivateRepairPhotoGrid({ photoPaths = [], onRemovePhoto, disabled = false }) {
  if (!Array.isArray(photoPaths) || photoPaths.length === 0) {
    return (
      <p style={{ color: 'var(--color-text-muted)', fontSize: '0.9rem', margin: '0.5rem 0' }}>
        No private repair photographs attached to this record.
      </p>
    );
  }

  return (
    <div className="grid-3" style={{ marginTop: '0.75rem' }}>
      {photoPaths.map((path) => (
        <PrivatePhotoTile
          key={path}
          storagePath={path}
          onRemove={onRemovePhoto}
          disabled={disabled}
        />
      ))}
    </div>
  );
}
