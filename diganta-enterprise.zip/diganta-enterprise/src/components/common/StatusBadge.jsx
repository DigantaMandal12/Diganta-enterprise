import React from 'react';
import { BUSINESS_INFO } from '../../config/businessConfig.js';

const STATUS_STYLE_MAP = {
  // Availability
  available: 'badge-success',
  'order-based': 'badge-info',
  unavailable: 'badge-error',
  unknown: 'badge-neutral',

  // Repair statuses
  Received: 'badge-info',
  Diagnosing: 'badge-warning',
  'Waiting for Parts': 'badge-warning',
  Repairing: 'badge-info',
  Completed: 'badge-success',
  Delivered: 'badge-success',

  // Payment statuses
  Paid: 'badge-success',
  'Partially Paid': 'badge-warning',
  Unpaid: 'badge-error',
  'Not Yet Charged': 'badge-neutral',
  'Advance Collected (Final Charge Pending)': 'badge-info',
  'Overpaid / Customer Credit': 'badge-warning',
  'No Charge (₹0)': 'badge-neutral',

  // Enquiry statuses
  New: 'badge-warning',
  Contacted: 'badge-info',
  'Quotation Sent': 'badge-info',
  Converted: 'badge-success',
  Closed: 'badge-neutral'
};

export function formatAvailabilityLabel(statusValue) {
  const match = BUSINESS_INFO.availabilityStatuses.find((s) => s.value === statusValue);
  return match ? match.label : 'Check Availability';
}

export default function StatusBadge({ status, label }) {
  const badgeClass = STATUS_STYLE_MAP[status] || 'badge-neutral';
  const displayLabel = label || status || 'Unknown';
  return <span className={`badge ${badgeClass}`}>{displayLabel}</span>;
}
