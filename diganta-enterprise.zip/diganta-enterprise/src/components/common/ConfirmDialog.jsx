import React from 'react';
import Button from './Button.jsx';

export default function ConfirmDialog({
  isOpen,
  title,
  message,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  variant = 'danger',
  isProcessing = false,
  onConfirm,
  onCancel
}) {
  if (!isOpen) return null;

  return (
    <div className="modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="confirm-dialog-title">
      <div className="modal-card">
        <h3 id="confirm-dialog-title" style={{ marginTop: 0, color: 'var(--color-navy)' }}>
          {title}
        </h3>
        <p style={{ color: 'var(--color-text-muted)', marginBottom: '1.5rem' }}>{message}</p>
        <div className="cta-row" style={{ justifyContent: 'flex-end' }}>
          <Button variant="secondary" onClick={onCancel} disabled={isProcessing}>
            {cancelLabel}
          </Button>
          <Button variant={variant} onClick={onConfirm} disabled={isProcessing}>
            {isProcessing ? 'Working…' : confirmLabel}
          </Button>
        </div>
      </div>
    </div>
  );
}
