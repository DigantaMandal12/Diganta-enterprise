import React from 'react';
import Button from './Button.jsx';

export function LoadingState({ message = 'Loading data…' }) {
  return (
    <div className="card" role="status" aria-live="polite" style={{ textAlign: 'center', padding: '2rem' }}>
      <p style={{ fontWeight: 700, color: 'var(--color-navy)', margin: 0 }}>{message}</p>
    </div>
  );
}

export function ErrorState({ title = 'Could not load data', message, onRetry }) {
  return (
    <div className="alert alert-error" role="alert">
      <strong style={{ display: 'block', marginBottom: '0.25rem' }}>{title}</strong>
      <p style={{ margin: '0 0 0.75rem 0' }}>{message || 'An unexpected error occurred.'}</p>
      {onRetry && (
        <Button variant="secondary" size="sm" onClick={onRetry}>
          Try Again
        </Button>
      )}
    </div>
  );
}

export function EmptyState({ title, description, actionLabel, actionTo, onAction }) {
  return (
    <div className="card" style={{ textAlign: 'center', padding: '2.25rem 1.25rem' }}>
      <h3 style={{ margin: '0 0 0.5rem 0', color: 'var(--color-navy)' }}>{title}</h3>
      {description && (
        <p style={{ margin: '0 auto 1.1rem auto', maxWidth: '540px', color: 'var(--color-text-muted)' }}>
          {description}
        </p>
      )}
      {actionLabel && (actionTo || onAction) && (
        <Button variant="primary" to={actionTo} onClick={onAction}>
          {actionLabel}
        </Button>
      )}
    </div>
  );
}
