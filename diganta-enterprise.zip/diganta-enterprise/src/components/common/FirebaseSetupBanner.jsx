import React, { useState } from 'react';
import {
  isFirebaseConfigured,
  missingFirebaseConfigKeys,
  isAppCheckConfigured,
  firebaseConfig,
  saveRuntimeFirebaseConfig
} from '../../services/firebase.js';
import Button from './Button.jsx';

/**
 * Parses a pasted Firebase SDK snippet or JSON object into config keys.
 */
function parseFirebaseSnippet(text) {
  const keys = [
    'apiKey',
    'authDomain',
    'projectId',
    'storageBucket',
    'messagingSenderId',
    'appId'
  ];
  const extracted = {};
  keys.forEach((k) => {
    const regex = new RegExp(`${k}\\s*:\\s*["']([^"']+)["']`);
    const match = text.match(regex);
    if (match && match[1]) {
      extracted[k] = match[1].trim();
    }
  });
  return extracted;
}

export default function FirebaseSetupBanner({ showAppCheckNotice = false }) {
  const [showModal, setShowModal] = useState(false);
  const [snippetText, setSnippetText] = useState('');
  const [fields, setFields] = useState({
    apiKey: firebaseConfig.apiKey.startsWith('your_') ? '' : firebaseConfig.apiKey,
    authDomain: firebaseConfig.authDomain.startsWith('your-') ? '' : firebaseConfig.authDomain,
    projectId: firebaseConfig.projectId.startsWith('your-') ? '' : firebaseConfig.projectId,
    storageBucket: firebaseConfig.storageBucket.startsWith('your-') ? '' : firebaseConfig.storageBucket,
    messagingSenderId:
      firebaseConfig.messagingSenderId === '000000000000' ? '' : firebaseConfig.messagingSenderId,
    appId:
      firebaseConfig.appId === '1:000000000000:web:0000000000000000' ? '' : firebaseConfig.appId
  });
  const [formError, setFormError] = useState(null);

  const handleParseSnippet = (raw) => {
    setSnippetText(raw);
    const parsed = parseFirebaseSnippet(raw);
    if (Object.keys(parsed).length > 0) {
      setFields((prev) => ({ ...prev, ...parsed }));
      setFormError(null);
    }
  };

  const handleSaveConfig = (e) => {
    e.preventDefault();
    const required = ['apiKey', 'authDomain', 'projectId', 'storageBucket', 'messagingSenderId', 'appId'];
    const missing = required.filter((k) => !fields[k] || !fields[k].trim());
    if (missing.length > 0) {
      setFormError(`Please fill in all required Firebase Web App fields: ${missing.join(', ')}`);
      return;
    }
    saveRuntimeFirebaseConfig({
      apiKey: fields.apiKey.trim(),
      authDomain: fields.authDomain.trim(),
      projectId: fields.projectId.trim(),
      storageBucket: fields.storageBucket.trim(),
      messagingSenderId: fields.messagingSenderId.trim(),
      appId: fields.appId.trim()
    });
  };

  const generatedEnvContent = [
    `VITE_FIREBASE_API_KEY=${fields.apiKey || 'your_firebase_web_api_key_here'}`,
    `VITE_FIREBASE_AUTH_DOMAIN=${fields.authDomain || 'your-project-id.firebaseapp.com'}`,
    `VITE_FIREBASE_PROJECT_ID=${fields.projectId || 'your-project-id'}`,
    `VITE_FIREBASE_STORAGE_BUCKET=${fields.storageBucket || 'your-project-id.firebasestorage.app'}`,
    `VITE_FIREBASE_MESSAGING_SENDER_ID=${fields.messagingSenderId || '000000000000'}`,
    `VITE_FIREBASE_APP_ID=${fields.appId || '1:000000000000:web:0000000000000000'}`,
    'VITE_FIREBASE_APPCHECK_SITE_KEY=',
    'VITE_USE_FIREBASE_EMULATOR=false'
  ].join('\n');

  if (!isFirebaseConfigured) {
    return (
      <div className="alert alert-warning" role="alert">
        <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '0.75rem' }}>
          <div>
            <strong>Firebase Configuration Needed:</strong> Copy <code>.env.example</code> to{' '}
            <code>.env.local</code> and supply your Firebase Web App credentials (or paste them
            below). Missing keys: <code>{missingFirebaseConfigKeys.join(', ')}</code>.
          </div>
          <Button variant="navy" size="sm" onClick={() => setShowModal(true)}>
            Configure Firebase Credentials
          </Button>
        </div>

        {showModal && (
          <div className="modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="fb-setup-title">
            <div className="modal-card" style={{ maxWidth: '640px', maxHeight: '90vh', overflowY: 'auto' }}>
              <h3 id="fb-setup-title" style={{ marginTop: 0, color: 'var(--color-navy)' }}>
                Connect Your Firebase Web App
              </h3>
              <p style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)' }}>
                In the <strong>Firebase Console &rarr; Project Settings (Gear Icon) &rarr; General &rarr; Your apps</strong>,
                copy your <code>firebaseConfig</code> object and paste it below, or fill in the individual fields.
              </p>

              {formError && <div className="alert alert-error">{formError}</div>}

              <form onSubmit={handleSaveConfig}>
                <div className="form-group">
                  <label htmlFor="fb-snippet" className="form-label">
                    Quick Paste: Paste <code>const firebaseConfig = &#123; ... &#125;</code> from Firebase Console
                  </label>
                  <textarea
                    id="fb-snippet"
                    className="form-textarea"
                    style={{ minHeight: '72px', fontFamily: 'monospace', fontSize: '0.82rem' }}
                    placeholder={'const firebaseConfig = {
  apiKey: "AIzaSy...",
  authDomain: "diganta-enterprise.firebaseapp.com",
  projectId: "diganta-enterprise",
  storageBucket: "diganta-enterprise.firebasestorage.app",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};'}
                    value={snippetText}
                    onChange={(e) => handleParseSnippet(e.target.value)}
                  />
                </div>

                <div className="grid-2">
                  <div className="form-group">
                    <label htmlFor="fb-apikey" className="form-label">apiKey *</label>
                    <input
                      id="fb-apikey"
                      type="text"
                      className="form-input"
                      value={fields.apiKey}
                      onChange={(e) => setFields((p) => ({ ...p, apiKey: e.target.value }))}
                      placeholder="AIzaSy..."
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="fb-authdomain" className="form-label">authDomain *</label>
                    <input
                      id="fb-authdomain"
                      type="text"
                      className="form-input"
                      value={fields.authDomain}
                      onChange={(e) => setFields((p) => ({ ...p, authDomain: e.target.value }))}
                      placeholder="your-project.firebaseapp.com"
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="fb-projectid" className="form-label">projectId *</label>
                    <input
                      id="fb-projectid"
                      type="text"
                      className="form-input"
                      value={fields.projectId}
                      onChange={(e) => setFields((p) => ({ ...p, projectId: e.target.value }))}
                      placeholder="your-project"
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="fb-bucket" className="form-label">storageBucket *</label>
                    <input
                      id="fb-bucket"
                      type="text"
                      className="form-input"
                      value={fields.storageBucket}
                      onChange={(e) => setFields((p) => ({ ...p, storageBucket: e.target.value }))}
                      placeholder="your-project.firebasestorage.app"
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="fb-sender" className="form-label">messagingSenderId *</label>
                    <input
                      id="fb-sender"
                      type="text"
                      className="form-input"
                      value={fields.messagingSenderId}
                      onChange={(e) => setFields((p) => ({ ...p, messagingSenderId: e.target.value }))}
                      placeholder="1234567890"
                    />
                  </div>
                  <div className="form-group">
                    <label htmlFor="fb-appid" className="form-label">appId *</label>
                    <input
                      id="fb-appid"
                      type="text"
                      className="form-input"
                      value={fields.appId}
                      onChange={(e) => setFields((p) => ({ ...p, appId: e.target.value }))}
                      placeholder="1:1234567890:web:abcdef"
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">Generated <code>.env.local</code> Content (Copy to your project root)</label>
                  <pre
                    style={{
                      backgroundColor: '#0D1B2A',
                      color: '#F8FAFC',
                      padding: '0.75rem',
                      borderRadius: '6px',
                      fontSize: '0.78rem',
                      overflowX: 'auto',
                      margin: 0
                    }}
                  >
                    <code>{generatedEnvContent}</code>
                  </pre>
                </div>

                <div className="cta-row" style={{ justifyContent: 'flex-end', marginTop: '1rem' }}>
                  <Button variant="secondary" size="sm" onClick={() => setShowModal(false)}>
                    Close
                  </Button>
                  <Button type="submit" variant="primary" size="sm">
                    Save &amp; Connect Firebase Now
                  </Button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (showAppCheckNotice && !isAppCheckConfigured) {
    return (
      <div className="alert alert-info" role="status">
        <strong>App Check Setup Reminder:</strong>{' '}
        <code>VITE_FIREBASE_APPCHECK_SITE_KEY</code> is not configured in <code>.env.local</code>.
        Configure your reCAPTCHA v3 site key and test before enabling App Check enforcement in Firebase Console.
      </div>
    );
  }

  return null;
}
