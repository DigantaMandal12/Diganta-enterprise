import React from 'react';
import { Link } from 'react-router-dom';

export default function Button({
  children,
  variant = 'primary',
  size = 'md',
  to,
  href,
  type = 'button',
  disabled = false,
  onClick,
  className = '',
  target,
  rel,
  ...rest
}) {
  const variantClass = {
    primary: 'btn-primary',
    navy: 'btn-navy',
    secondary: 'btn-secondary',
    whatsapp: 'btn-whatsapp',
    danger: 'btn-danger'
  }[variant] || 'btn-primary';

  const sizeClass = size === 'sm' ? 'btn-sm' : '';
  const combined = `btn ${variantClass} ${sizeClass} ${className}`.trim();

  if (to) {
    return (
      <Link to={to} className={combined} {...rest}>
        {children}
      </Link>
    );
  }

  if (href) {
    return (
      <a href={href} className={combined} target={target} rel={rel} {...rest}>
        {children}
      </a>
    );
  }

  return (
    <button
      type={type}
      className={combined}
      disabled={disabled}
      onClick={onClick}
      {...rest}
    >
      {children}
    </button>
  );
}
