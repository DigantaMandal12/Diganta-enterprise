import React from 'react';

export default function MetricCard({ title, value, subtitle, tone = 'default' }) {
  const borderColors = {
    default: 'var(--color-navy)',
    accent: 'var(--color-orange)',
    success: 'var(--color-success-text)',
    warning: 'var(--color-warning-text)',
    danger: 'var(--color-error-text)'
  };

  return (
    <div
      className="card"
      style={{
        borderTop: `4px solid ${borderColors[tone] || borderColors.default}`,
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'space-between'
      }}
    >
      <div>
        <div style={{ fontSize: '0.84rem', fontWeight: 700, color: 'var(--color-text-muted)', textTransform: 'uppercase' }}>
          {title}
        </div>
        <div style={{ fontSize: '1.55rem', fontWeight: 800, color: 'var(--color-navy)', margin: '0.35rem 0' }}>
          {value}
        </div>
      </div>
      {subtitle && (
        <div style={{ fontSize: '0.8rem', color: 'var(--color-text-muted)' }}>
          {subtitle}
        </div>
      )}
    </div>
  );
}
