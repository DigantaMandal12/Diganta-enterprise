import React from 'react';
import Button from './Button.jsx';

export default function Pagination({ currentPage, totalItems, pageSize, onPageChange }) {
  const totalPages = Math.max(1, Math.ceil(totalItems / pageSize));
  if (totalPages <= 1) return null;

  const startIdx = (currentPage - 1) * pageSize + 1;
  const endIdx = Math.min(totalItems, currentPage * pageSize);

  return (
    <div
      style={{
        display: 'flex',
        flexWrap: 'wrap',
        justifyContent: 'space-between',
        alignItems: 'center',
        gap: '0.75rem',
        marginTop: '1rem',
        paddingTop: '0.75rem',
        borderTop: '1px solid var(--color-border)'
      }}
    >
      <span style={{ fontSize: '0.88rem', color: 'var(--color-text-muted)' }}>
        Showing {startIdx}–{endIdx} of {totalItems} records
      </span>
      <div className="cta-row">
        <Button
          variant="secondary"
          size="sm"
          disabled={currentPage <= 1}
          onClick={() => onPageChange(currentPage - 1)}
        >
          Previous
        </Button>
        <span style={{ fontSize: '0.9rem', fontWeight: 700 }}>
          Page {currentPage} of {totalPages}
        </span>
        <Button
          variant="secondary"
          size="sm"
          disabled={currentPage >= totalPages}
          onClick={() => onPageChange(currentPage + 1)}
        >
          Next
        </Button>
      </div>
    </div>
  );
}
