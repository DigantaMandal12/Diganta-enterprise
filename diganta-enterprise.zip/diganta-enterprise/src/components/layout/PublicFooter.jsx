import React from 'react';
import { Link } from 'react-router-dom';
import { BUSINESS_INFO } from '../../config/businessConfig.js';

export default function PublicFooter() {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="grid-3">
          <div>
            <h3 style={{ color: '#ffffff', marginTop: 0 }}>{BUSINESS_INFO.name}</h3>
            <p style={{ color: 'var(--color-orange)', fontWeight: 700, margin: '0 0 0.5rem 0' }}>
              {BUSINESS_INFO.tagline}
            </p>
            <p style={{ fontSize: '0.92rem', margin: 0 }}>
              {BUSINESS_INFO.shortDescription}
            </p>
          </div>

          <div>
            <h4 style={{ color: '#ffffff', marginTop: 0 }}>Verified Business Details</h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, fontSize: '0.92rem', lineHeight: '1.8' }}>
              <li><strong>Location:</strong> {BUSINESS_INFO.location}</li>
              <li><strong>Service Area:</strong> {BUSINESS_INFO.serviceRadius}</li>
              <li>
                <strong>Phone:</strong>{' '}
                <a href={BUSINESS_INFO.phoneHref}>{BUSINESS_INFO.phoneDisplay}</a>
              </li>
              <li>
                <strong>WhatsApp:</strong>{' '}
                <a href={BUSINESS_INFO.whatsappBaseUrl} target="_blank" rel="noopener noreferrer">
                  {BUSINESS_INFO.whatsappDisplay}
                </a>
              </li>
              <li><strong>Opening Hours:</strong> {BUSINESS_INFO.businessHours}</li>
            </ul>
          </div>

          <div>
            <h4 style={{ color: '#ffffff', marginTop: 0 }}>Quick Links</h4>
            <ul style={{ listStyle: 'none', padding: 0, margin: 0, fontSize: '0.92rem', lineHeight: '1.9' }}>
              <li><Link to="/services">Weighing-Scale Repair Services</Link></li>
              <li><Link to="/products">Weighing-Scale Catalogue</Link></li>
              <li><Link to="/our-work">Repair Videos / Our Work</Link></li>
              <li><Link to="/about">About {BUSINESS_INFO.name}</Link></li>
              <li><Link to="/contact">Contact &amp; Service Area</Link></li>
              <li><Link to="/privacy">Privacy Notice</Link></li>
              <li><Link to="/admin">Owner Admin Portal</Link></li>
            </ul>
          </div>
        </div>

        <div
          style={{
            marginTop: '2rem',
            paddingTop: '1rem',
            borderTop: '1px solid rgba(255,255,255,0.15)',
            fontSize: '0.84rem',
            display: 'flex',
            flexWrap: 'wrap',
            justifyContent: 'space-between',
            gap: '0.5rem'
          }}
        >
          <span>
            &copy; {new Date().getFullYear()} {BUSINESS_INFO.name}. All rights reserved.
          </span>
          <span>
            Weighing Scale Repair &amp; Sales — {BUSINESS_INFO.location}
          </span>
        </div>
      </div>
    </footer>
  );
}
