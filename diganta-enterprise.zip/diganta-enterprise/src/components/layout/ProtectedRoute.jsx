import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import { LoadingState } from '../common/StateFeedback.jsx';
import Button from '../common/Button.jsx';

/**
 * Route guard for administrator pages.
 * Note: This guard improves UI navigation; actual data security is enforced by
 * Firestore and Storage Security Rules using `admins/{request.auth.uid}`.
 */
export default function ProtectedRoute({ children }) {
  const { user, isAdmin, loading, signOutUser } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="container section">
        <LoadingState message="Verifying administrator authorisation…" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/admin/login" state={{ from: location }} replace />;
  }

  if (!isAdmin) {
    return (
      <div className="container section">
        <div className="card" style={{ maxWidth: '580px', margin: '2rem auto', borderTop: '4px solid var(--color-error-text)' }}>
          <h1 style={{ marginTop: 0, color: 'var(--color-error-text)', fontSize: '1.5rem' }}>
            Access Denied — Unauthorised Account
          </h1>
          <p>
            You are signed in as <strong>{user.email}</strong> (UID: <code>{user.uid}</code>),
            but this account is not listed in the Firestore <code>admins/{'{uid}'}</code> allowlist
            with <code>role: &quot;admin&quot;</code>.
          </p>
          <p style={{ color: 'var(--color-text-muted)', fontSize: '0.92rem' }}>
            Private business data, repair records, enquiries, and expenses remain restricted by
            Firebase Security Rules.
          </p>
          <div className="cta-row" style={{ marginTop: '1.25rem' }}>
            <Button variant="danger" onClick={signOutUser}>
              Sign Out
            </Button>
            <Button variant="secondary" to="/">
              Return to Public Website
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return children;
}
