import React from 'react';
import { NavLink, Outlet, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext.jsx';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import Button from '../common/Button.jsx';
import FirebaseSetupBanner from '../common/FirebaseSetupBanner.jsx';

export default function AdminLayout() {
  const { user, signOutUser } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await signOutUser();
    navigate('/admin/login', { replace: true });
  };

  return (
    <div className="admin-shell">
      <aside className="admin-sidebar" aria-label="Administrator Navigation">
        <div>
          <Link to="/admin" className="brand-wordmark">
            <span className="brand-title">{BUSINESS_INFO.name}</span>
            <span className="brand-subtitle">Admin &amp; Repair System</span>
          </Link>
          {user && (
            <div style={{ fontSize: '0.78rem', color: '#cbd5e1', marginTop: '0.5rem', wordBreak: 'break-all' }}>
              Signed in: {user.email}
            </div>
          )}
        </div>

        <ul className="admin-nav-list">
          <li>
            <NavLink to="/admin" end className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}>
              Dashboard Overview
            </NavLink>
          </li>
          <li>
            <NavLink to="/admin/repairs" className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}>
              Repair Management
            </NavLink>
          </li>
          <li>
            <NavLink to="/admin/products" className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}>
              Product Catalogue
            </NavLink>
          </li>
          <li>
            <NavLink to="/admin/enquiries" className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}>
              Product Enquiries
            </NavLink>
          </li>
          <li>
            <NavLink to="/admin/expenses" className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}>
              General Expenses
            </NavLink>
          </li>
          <li>
            <NavLink to="/admin/reports" className={({ isActive }) => `admin-nav-link ${isActive ? 'active' : ''}`}>
              Financial Summary
            </NavLink>
          </li>
        </ul>

        <div style={{ marginTop: '1.5rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          <Button variant="secondary" size="sm" to="/">
            View Public Website
          </Button>
          <Button variant="danger" size="sm" onClick={handleLogout}>
            Sign Out
          </Button>
        </div>
      </aside>

      <main className="admin-main">
        <FirebaseSetupBanner showAppCheckNotice />
        <Outlet />
      </main>
    </div>
  );
}
