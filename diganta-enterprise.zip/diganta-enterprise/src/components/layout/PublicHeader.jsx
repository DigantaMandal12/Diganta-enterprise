import React from 'react';
import { NavLink, Link } from 'react-router-dom';
import { BUSINESS_INFO } from '../../config/businessConfig.js';
import Button from '../common/Button.jsx';

export default function PublicHeader() {
  return (
    <header className="site-header">
      <div className="header-topbar">
        <div className="container header-topbar-inner">
          <span>
            {BUSINESS_INFO.location} ({BUSINESS_INFO.serviceRadius} service radius)
          </span>
          <span>Hours: {BUSINESS_INFO.businessHours}</span>
        </div>
      </div>

      <div className="container header-main">
        <Link to="/" className="brand-wordmark">
          <span className="brand-title">{BUSINESS_INFO.name}</span>
          <span className="brand-subtitle">{BUSINESS_INFO.tagline}</span>
        </Link>

        <nav className="nav-links" aria-label="Main Navigation">
          <NavLink to="/" end className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            Home
          </NavLink>
          <NavLink to="/services" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            Repair Services
          </NavLink>
          <NavLink to="/products" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            Products
          </NavLink>
          <NavLink to="/our-work" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            Our Work
          </NavLink>
          <NavLink to="/about" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            About
          </NavLink>
          <NavLink to="/contact" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
            Contact
          </NavLink>
        </nav>

        <div className="cta-row">
          <Button variant="primary" size="sm" href={BUSINESS_INFO.phoneHref}>
            Call {BUSINESS_INFO.phoneDisplay}
          </Button>
          <Button
            variant="whatsapp"
            size="sm"
            href={BUSINESS_INFO.whatsappBaseUrl}
            target="_blank"
            rel="noopener noreferrer"
          >
            WhatsApp
          </Button>
        </div>
      </div>
    </header>
  );
}
