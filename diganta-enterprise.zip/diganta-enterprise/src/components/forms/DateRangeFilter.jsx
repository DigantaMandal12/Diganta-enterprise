import React from 'react';
import Button from '../common/Button.jsx';

export default function DateRangeFilter({
  startDate,
  endDate,
  onStartDateChange,
  onEndDateChange,
  onClear,
  label = 'Filter by Date Range'
}) {
  return (
    <div className="card" style={{ marginBottom: '1.25rem', padding: '1rem' }}>
      <div
        style={{
          display: 'flex',
          flexWrap: 'wrap',
          gap: '1rem',
          alignItems: 'flex-end'
        }}
      >
        <div>
          <label htmlFor="filter-start-date" className="form-label">
            {label} — From
          </label>
          <input
            id="filter-start-date"
            type="date"
            className="form-input"
            value={startDate}
            onChange={(e) => onStartDateChange(e.target.value)}
          />
        </div>
        <div>
          <label htmlFor="filter-end-date" className="form-label">
            To
          </label>
          <input
            id="filter-end-date"
            type="date"
            className="form-input"
            value={endDate}
            onChange={(e) => onEndDateChange(e.target.value)}
          />
        </div>
        {(startDate || endDate) && (
          <Button variant="secondary" size="sm" onClick={onClear}>
            Clear Dates
          </Button>
        )}
      </div>
    </div>
  );
}
