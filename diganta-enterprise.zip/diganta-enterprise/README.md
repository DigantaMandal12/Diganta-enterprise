# Diganta Enterprise — Weighing Scale Repair & Sales

Complete public business website and private administrator repair-management, product-catalogue, customer-enquiry, and financial-tracking system for **Diganta Enterprise** (Mohonpur, Ariabāṛā, West Bengal, India).

---

## Verified Business Profile

- **Business Name**: Diganta Enterprise
- **Business Type**: Weighing Scale Repair & Sales (Electronic troubleshooting, PCB/motherboard repair or fabrication where appropriate, transformer repair or fabrication where appropriate, workshop repair, and on-site weighing-scale repair visits)
- **Location**: Mohonpur, Ariabāṛā, West Bengal, India
- **Service Radius**: Approximately 10–20 km
- **Public Telephone**: `+91 93302 50245` (`tel:+919330250245`)
- **Public WhatsApp**: `+91 93302 50245` (`https://wa.me/919330250245`)
- **Business Hours**: Monday–Sunday, 10:00 AM–10:00 PM
- **Known Brand**: Vison Tech (alongside other supported commercial weighing scales)
- **Supported Capacities**: 10 kg, 20 kg, 30 kg, 50 kg, 100 kg, 150–300 kg, and other capacities where supported

> **Scope Note**: The public website explicitly states that "on-site service" means travelling to a customer's location to repair weighing scales, and that the business does **not** repair mobile phones.

---

## Step 1: Install Required Developer Tools

1. **Node.js (Active LTS)**:
   - Install **Node.js 20 LTS or 22 LTS** from [https://nodejs.org/](https://nodejs.org/).
   - `npm` is installed automatically with Node.js.
   - Verify in your terminal:
     ```bash
     node -v
     npm -v
     ```
2. **Firebase CLI**:
   - Install the official Firebase command-line tool globally:
     ```bash
     npm install -g firebase-tools
     ```
   - Verify installation:
     ```bash
     firebase --version
     ```
3. **Java Runtime (Required only for local Firestore/Storage Emulator rule tests)**:
   - The [Firebase Local Emulator Suite](https://firebase.google.com/docs/emulator-suite) requires OpenJDK / Java 11+ (`java -version`).
4. **Code Editor**:
   - Install [Visual Studio Code](https://code.visualstudio.com/).

---

## Step 2: Create and Configure the Firebase Project

1. Open the [Firebase Console](https://console.firebase.google.com/) and click **Create a project** (for example, `diganta-enterprise-prod`).
2. **Add a Web Application**:
   - In Project Overview, click the **Web (`</>`)** icon, register the app as `Diganta Enterprise Web`, and copy the `firebaseConfig` values.
3. **Enable Firebase Authentication**:
   - Go to **Build → Authentication → Get started**.
   - Under the **Sign-in method** tab, enable **Email/Password** (leave "Email link / passwordless" disabled).
   - Reference: [Firebase Authentication Documentation](https://firebase.google.com/docs/auth).
4. **Create Cloud Firestore Database**:
   - Go to **Build → Firestore Database → Create database**.
   - Select **Start in production mode**.
   - **Choose a Region Deliberately**: Select `asia-south1` (**Mumbai, India**) or `asia-south2` (**Delhi, India**) for low latency from West Bengal, India.
     - *Region Trade-off Note*: While US multi-regions (`nam5`) are sometimes listed first in tutorials, choosing `asia-south1` significantly reduces database round-trip latency for customers in West Bengal. Check [Cloud Firestore Pricing](https://cloud.google.com/firestore/pricing) for current regional pricing and no-cost quota allowances.
5. **Enable Firebase Cloud Storage (Blaze Plan Requirement)**:
   - Go to **Build → Storage → Get started**.
   - Per [Default bucket and billing requirements for Cloud Storage (announced Sept 2024)](https://firebase.google.com/docs/storage/faqs-storage-changes-announced-sept-2024), provisioning and using Cloud Storage for Firebase requires upgrading the project to the pay-as-you-go **Blaze pricing plan**.
   - Select the same region (`asia-south1`) when prompted so cross-service rules and uploads operate with minimal latency.
6. **Configure Billing Budgets & Alerts Immediately**:
   - See the **Firebase Billing & Cost Controls** section below to set up a monthly budget alert in Google Cloud Billing before uploading production data.

---

## Step 3: Configure Local Environment Variables

1. In the `diganta-enterprise/` folder, copy `.env.example` to `.env.local`:
   ```bash
   cp .env.example .env.local
   ```
2. Open `.env.local` and fill in your Firebase Web App values:
   ```env
   VITE_FIREBASE_API_KEY=AIzaSy...
   VITE_FIREBASE_AUTH_DOMAIN=your-project-id.firebaseapp.com
   VITE_FIREBASE_PROJECT_ID=your-project-id
   VITE_FIREBASE_STORAGE_BUCKET=your-project-id.firebasestorage.app
   VITE_FIREBASE_MESSAGING_SENDER_ID=1234567890
   VITE_FIREBASE_APP_ID=1:1234567890:web:abcdef123456
   VITE_FIREBASE_APPCHECK_SITE_KEY=
   VITE_PUBLIC_SITE_URL=https://your-project-id.web.app
   VITE_USE_FIREBASE_EMULATOR=false
   ```
3. **Security Rules for Credentials**:
   - The `VITE_FIREBASE_*` keys above are public browser project identifiers; security is enforced by `firestore.rules` and `storage.rules`.
   - **NEVER** place Firebase Admin SDK service-account JSON keys, reCAPTCHA **secret** keys, or GitHub tokens inside `.env.local` or any frontend file.
   - `.env.local` and `.firebaserc` are ignored by `.gitignore` and must never be committed to Git.

---

## Step 4: Provision the Single Administrator Account

There is no public sign-up page. You must provision the single administrator account manually in the Firebase Console:

1. **Create the User in Firebase Authentication**:
   - Open **Firebase Console → Build → Authentication → Users → Add user**.
   - Enter the owner's email address and a strong password, then click **Add user**.
2. **Copy the User UID**:
   - In the Users table, copy the generated **User UID** string (for example, `k8Jp9...`).
3. **Create the Allowlist Document in Cloud Firestore**:
   - Open **Firebase Console → Build → Firestore Database → Data**.
   - Click **+ Start collection** and enter the Collection ID: `admins`
   - Paste the copied **User UID** as the **Document ID**.
   - Add two fields to `admins/{uid}`:
     - Field `role` (type `string`): `admin`
     - Field `createdAt` (type `timestamp`): select current date/time.
   - Click **Save**.
4. **Verify Access Control**:
   - Sign in at `/admin/login` with the administrator email/password — you should reach the Admin Dashboard (`/admin`).
   - If you create a second test user in Firebase Authentication *without* adding their UID to `admins/{uid}`, signing in will display **Access Denied — Unauthorised Account** and Firestore/Storage rules will block all private reads and writes.

---

## Step 5: Run the Project Locally

1. Install dependencies:
   ```bash
   npm install
   ```
2. Start the local Vite development server:
   ```bash
   npm run dev
   ```
3. Open the local URL shown in the terminal (default `http://localhost:5173`).
4. **Populating Real Business Data (No Fake Data Required)**:
   - Sign in at `http://localhost:5173/admin/login`.
   - Go to **Product Catalogue (`/admin/products/new`)** to add actual weighing scales, upload real product photos, and tick **Publish in Public Catalogue** when ready.
   - To add genuine YouTube repair videos, open `src/config/businessConfig.js` and add your video entries to `REPAIR_VIDEOS`.

---

## Step 6: Run Tests & Build Verification

1. **Verify Project Structure & Import Integrity**:
   ```bash
   npm run verify:structure
   ```
2. **Run Financial Calculation & Validation Unit Tests** (paise conversions, parts totals, partial/full/unpaid repairs, refunds, overpayments, missing quotes/charges, zero expenses, phone/form validation):
   ```bash
   npm test
   ```
3. **Run Firebase Security Rules Unit Tests Against Local Emulator**:
   - Ensure Java 11+ and `firebase-tools` are installed, then run:
     ```bash
     npm run test:rules
     ```
   - See [Build unit tests for Firebase Security Rules](https://firebase.google.com/docs/rules/unit-tests).
4. **Create Production Build**:
   ```bash
   npm run build
   ```

---

## Step 7: Deploy to Firebase (Rules, Indexes, Storage, Hosting)

1. **Authenticate Firebase CLI and Link Project**:
   ```bash
   firebase login
   cp .firebaserc.example .firebaserc
   ```
   Edit `.firebaserc` and replace `"your-firebase-project-id"` with your actual Firebase Project ID (or run `firebase use --add`).
2. **Deploy Firestore Security Rules & Indexes**:
   ```bash
   firebase deploy --only firestore:rules,firestore:indexes
   ```
3. **Deploy Cloud Storage Security Rules**:
   ```bash
   firebase deploy --only storage
   ```
   - *Cross-Service Rules Note*: Because `storage.rules` calls `firestore.exists()` and `firestore.get()` to verify `admins/$(request.auth.uid)`, the Firebase CLI or Console may prompt you on first deployment to grant the Firebase Storage service agent permission to read Firestore. Accept the prompt and verify that deployment succeeds. See [Use conditions in Firebase Cloud Storage Security Rules](https://firebase.google.com/docs/storage/security/rules-conditions).
4. **Build and Deploy Frontend to Firebase Hosting**:
   ```bash
   npm run build
   firebase deploy --only hosting
   ```
   - Reference: [Firebase Hosting Documentation](https://firebase.google.com/docs/hosting).
5. **Post-Deployment Verification**:
   - Open your live Hosting URL in an incognito browser window.
   - Verify that `/`, `/services`, `/products`, `/our-work`, `/about`, `/contact`, and `/privacy` load cleanly.
   - Verify that navigating to `/admin` redirects to `/admin/login`.
   - Submit a test product enquiry on a published product and verify that it appears in `/admin/enquiries`.

---

## Step 8: Firebase Billing, Cost Controls & App Check Guide

### Why the Blaze Plan Is Required
Under [Google's September 2024 Cloud Storage updates](https://firebase.google.com/docs/storage/faqs-storage-changes-announced-sept-2024), creating and accessing Cloud Storage buckets requires the pay-as-you-go **Blaze plan**. No-cost usage tiers still apply on Blaze within Google's published monthly/daily allowances, but any usage beyond no-cost quotas is billed. Always review current figures on [Firebase Pricing](https://firebase.google.com/pricing) and [Cloud Firestore Pricing](https://cloud.google.com/firestore/pricing) before deployment.

### What Contributes to Usage & Potential Charges
1. **Cloud Storage**: Total GiB stored (`products/` and `repairs/` photos), Class A/B operations (uploads/reads), and network egress bandwidth when visitors view product photos. Note: `firestore.exists()` / `firestore.get()` calls inside `storage.rules` also count as Firestore document reads.
2. **Cloud Firestore**: Document reads, writes, deletes, and index storage.
3. **Firebase Hosting**: Storage of built static assets (`dist/`) and outbound data transfer.

### How to Configure a Billing Budget & Alert
1. Open the [Google Cloud Billing Console](https://console.cloud.google.com/billing) for your project.
2. Go to **Budgets & alerts → Create budget**.
3. Set a small monthly threshold appropriate for a local shop (for example, ₹100 or $2 USD) with email alerts at **50%, 90%, and 100%**.
4. **CRITICAL WARNING**: Google Cloud budget alerts **only send notification emails — they do NOT automatically cap or stop spending**. Keep the 5 MiB upload limit in `storage.rules`, compress photos before uploading, and delete unused images through the Admin panel.

### Configuring Firebase App Check
1. Review [Get started using App Check with reCAPTCHA v3 in web apps](https://firebase.google.com/docs/app-check/web/recaptcha-provider).
2. Register your domain in the Google reCAPTCHA v3 Admin Console to obtain a **Site Key** (public) and **Secret Key** (private).
3. In **Firebase Console → Build → App Check → Apps**, register your web app with the **Secret Key**.
4. Put the public **Site Key** in `.env.local` as `VITE_FIREBASE_APPCHECK_SITE_KEY=...`, rebuild, and deploy.
5. Monitor App Check metrics in the Firebase Console before clicking **Enforce** on Firestore and Cloud Storage so legitimate customers are not blocked. (Standard reCAPTCHA v3 is free up to Google's published monthly assessment limits; check reCAPTCHA pricing before switching to Enterprise tiers.)

### Client-Side Rendering (SPA) & Local SEO Note
Because this application is built with React and Vite as a client-rendered Single-Page Application (SPA), `index.html` includes complete `LocalBusiness` JSON-LD structured data, Open Graph tags, and verified contact details in the initial HTML payload, while `useDocumentTitle.js` updates page titles and meta descriptions on route transitions.

---

## Step 9: Ongoing Maintenance & Operations

- **Updating Phone Number or Business Info**: Edit `src/config/businessConfig.js`, run `npm run build`, and `firebase deploy --only hosting`.
- **Adding/Updating YouTube Repair Videos**: Add video objects to `REPAIR_VIDEOS` in `src/config/businessConfig.js` and redeploy Hosting.
- **Exporting / Backing Up Business Data**: Because automated Firestore backups are a paid Google Cloud feature (`$0.00004 per GiB-hour` plus restore fees), periodically review and record monthly summaries from `/admin/reports`, or use `gcloud firestore export` if you choose to enable a backup bucket.
- **Recovering a Lost Administrator Password**: Use **Firebase Console → Authentication → Users**, click the three-dot menu next to the administrator email, and select **Reset password** to send a password reset email.


---

## Deploying Frontend on Vercel (with Firebase Backend)

This project includes a pre-configured `vercel.json` file that sets `"framework": "vite"`, `"outputDirectory": "dist"`, and rewrites all React Router paths (`/(.*) -> /index.html`) so refreshing `/services`, `/products`, or `/admin` on Vercel never causes a 404 error.

### Step 1: Deploy to Vercel
- **Option A (GitHub / Git Integration)**:
  1. Push the `diganta-enterprise` folder to a private GitHub repository.
  2. Import the repository in the Vercel Dashboard.
  3. Vercel automatically detects Vite (`npm run build`, output `dist`) and uses the included `.env.production` / `src/services/firebase.js` defaults for `diganta-enterprise`. (You can also add the `VITE_FIREBASE_*` variables under **Vercel Project Settings → Environment Variables**.)
  4. Click **Deploy**.
- **Option B (Vercel CLI)**:
  ```bash
  npx vercel --prod
  ```

### Step 2: Add Your Vercel Domain in Firebase Authentication
1. Copy your live Vercel domain (for example, `diganta-enterprise.vercel.app`).
2. Open **Firebase Console → Build → Authentication → Settings → Authorized domains**.
3. Click **Add domain** and add your `.vercel.app` domain so administrator sign-in works from Vercel.

### Step 3: Publish Firestore & Storage Security Rules in Firebase
Even when the frontend is hosted on Vercel, your database and image storage run on Firebase (`diganta-enterprise`):
1. Run `npm run deploy:rules` locally (`npx firebase-tools deploy --only firestore:rules,firestore:indexes,storage`), **OR**
2. Copy the contents of `firestore.rules` into **Firebase Console → Firestore Database → Rules** and `storage.rules` into **Firebase Console → Storage → Rules** and click **Publish**.
