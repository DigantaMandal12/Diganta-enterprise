/**
 * Firestore Security Rules Test Suite (`tests/firestore.rules.test.js`).
 *
 * When executed inside `firebase emulators:exec --only firestore,storage`, this suite
 * runs all 14 live emulator security-rule tests using `@firebase/rules-unit-testing`.
 * When executed without a running Java emulator, it runs deterministic static policy
 * verification against `firestore.rules` and logs instructions for running the live emulator.
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rulesPath = path.resolve(__dirname, '../firestore.rules');
const rulesContent = fs.readFileSync(rulesPath, 'utf8');

const isEmulatorRunning = Boolean(process.env.FIRESTORE_EMULATOR_HOST);

test('Firestore Rules Policy Verification — Static Rule Structure & Invariants', () => {
  assert.ok(rulesContent.includes("rules_version = '2';"), 'Must use rules_version 2');
  assert.ok(
    rulesContent.includes('exists(/databases/$(database)/documents/admins/$(request.auth.uid))'),
    'Must verify admin UID existence in admins collection'
  );
  assert.ok(
    rulesContent.includes('get(/databases/$(database)/documents/admins/$(request.auth.uid)).data.role == "admin"'),
    'Must verify admin role == "admin"'
  );
  assert.ok(
    rulesContent.includes('allow get, list: if resource.data.isPublished == true || isAdmin();'),
    'Public users can only read published products'
  );
  assert.ok(
    rulesContent.includes("data.status == 'New'"),
    'Public enquiry creation must enforce status == New'
  );
  assert.ok(
    rulesContent.includes('get(productPath).data.isPublished == true'),
    'Public enquiry creation must verify referenced product exists and is published'
  );
  assert.ok(
    rulesContent.includes('allow create, update, delete: if false;'),
    'Clients must never create, modify, or delete admin allowlist documents'
  );
});

if (isEmulatorRunning) {
  test('Firestore Emulator Live Security Rules Suite (14 Scenarios)', async (t) => {
    const {
      initializeTestEnvironment,
      assertSucceeds,
      assertFails
    } = await import('@firebase/rules-unit-testing');
    const {
      doc,
      getDoc,
      getDocs,
      setDoc,
      updateDoc,
      collection,
      query,
      where,
      serverTimestamp
    } = await import('firebase/firestore');

    const [host, portStr] = process.env.FIRESTORE_EMULATOR_HOST.split(':');
    const testEnv = await initializeTestEnvironment({
      projectId: 'diganta-enterprise-test',
      firestore: {
        host,
        port: Number(portStr),
        rules: rulesContent
      }
    });

    try {
      await testEnv.clearFirestore();

      // Seed admin allowlist and sample published/unpublished products via security-rules-disabled context
      await testEnv.withSecurityRulesDisabled(async (context) => {
        const adminDb = context.firestore();
        await setDoc(doc(adminDb, 'admins', 'admin-uid-1'), {
          role: 'admin',
          createdAt: new Date()
        });
        await setDoc(doc(adminDb, 'products', 'prod-published'), {
          name: 'Vison Tech 30 kg Scale',
          scaleType: 'Tabletop Scale',
          pricingMode: 'fixed',
          displayPricePaise: 280000,
          availabilityStatus: 'available',
          isPublished: true,
          imagePaths: [],
          createdAt: new Date(),
          updatedAt: new Date()
        });
        await setDoc(doc(adminDb, 'products', 'prod-hidden'), {
          name: 'Draft 100 kg Scale',
          scaleType: 'Platform Scale',
          pricingMode: 'request',
          displayPricePaise: null,
          availabilityStatus: 'unknown',
          isPublished: false,
          imagePaths: [],
          createdAt: new Date(),
          updatedAt: new Date()
        });
      });

      const anonDb = testEnv.unauthenticatedContext().firestore();
      const nonAdminDb = testEnv.authenticatedContext('random-user-uid').firestore();
      const adminDb = testEnv.authenticatedContext('admin-uid-1').firestore();

      // 1. Anonymous users can read published products
      await assertSucceeds(getDoc(doc(anonDb, 'products', 'prod-published')));

      // 2. Anonymous users cannot read unpublished product documents
      await assertFails(getDoc(doc(anonDb, 'products', 'prod-hidden')));

      // 3. Anonymous users cannot create or modify products
      await assertFails(
        setDoc(doc(anonDb, 'products', 'hacked-prod'), {
          name: 'Unauthorized',
          isPublished: true
        })
      );

      // 4. Anonymous users can create a valid product enquiry referencing a published product
      await assertSucceeds(
        setDoc(doc(anonDb, 'enquiries', 'enq-valid-1'), {
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          customerName: 'Subrata Ghosh',
          phone: '+91 98765 43210',
          preferredContactMethod: 'WhatsApp',
          productId: 'prod-published',
          productNameSnapshot: 'Vison Tech 30 kg Scale',
          productBrandSnapshot: 'Vison Tech',
          productModelSnapshot: 'VT-30',
          productSpecificationsSnapshot: 'Max Capacity: 30 kg',
          productImageUrlSnapshot: '',
          quantity: 1,
          requiredCapacity: '30 kg',
          requiredReadability: '2 g',
          additionalRequirements: '',
          status: 'New',
          quotedPricePaise: null,
          notes: ''
        })
      );

      // 5. Anonymous users cannot create malformed enquiries or reference unpublished products
      await assertFails(
        setDoc(doc(anonDb, 'enquiries', 'enq-bad-product'), {
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          customerName: 'Subrata Ghosh',
          phone: '+91 98765 43210',
          preferredContactMethod: 'WhatsApp',
          productId: 'prod-hidden',
          productNameSnapshot: 'Draft 100 kg Scale',
          quantity: 1,
          status: 'New'
        })
      );

      // 6. Anonymous users cannot set privileged enquiry fields (quotedPricePaise, status != New)
      await assertFails(
        setDoc(doc(anonDb, 'enquiries', 'enq-privileged'), {
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
          customerName: 'Subrata Ghosh',
          phone: '+91 98765 43210',
          preferredContactMethod: 'WhatsApp',
          productId: 'prod-published',
          productNameSnapshot: 'Vison Tech 30 kg Scale',
          quantity: 1,
          status: 'Converted',
          quotedPricePaise: 10000,
          notes: 'Admin override'
        })
      );

      // 7. Anonymous users cannot read or list enquiries
      await assertFails(getDoc(doc(anonDb, 'enquiries', 'enq-valid-1')));
      await assertFails(getDocs(collection(anonDb, 'enquiries')));

      // 8. Anonymous users cannot read or modify repairs
      await assertFails(getDoc(doc(anonDb, 'repairs', 'rep-1')));

      // 9. Anonymous users cannot read or modify payments
      await assertFails(getDoc(doc(anonDb, 'repairs', 'rep-1', 'payments', 'pay-1')));

      // 10. Anonymous users cannot read or modify expenses
      await assertFails(getDoc(doc(anonDb, 'expenses', 'exp-1')));

      // 11. Authenticated non-admin users are denied private access
      await assertFails(getDoc(doc(nonAdminDb, 'enquiries', 'enq-valid-1')));
      await assertFails(getDoc(doc(nonAdminDb, 'repairs', 'rep-1')));
      await assertFails(getDoc(doc(nonAdminDb, 'expenses', 'exp-1')));

      // 12. Authorised administrator can manage intended records
      await assertSucceeds(getDoc(doc(adminDb, 'enquiries', 'enq-valid-1')));
      await assertSucceeds(
        updateDoc(doc(adminDb, 'enquiries', 'enq-valid-1'), {
          status: 'Quotation Sent',
          quotedPricePaise: 275000,
          notes: 'Quoted via WhatsApp',
          updatedAt: serverTimestamp()
        })
      );

      // 13. Clients cannot create or change their own administrator allowlist record
      await assertFails(
        setDoc(doc(nonAdminDb, 'admins', 'random-user-uid'), { role: 'admin' })
      );
      await assertFails(
        updateDoc(doc(adminDb, 'admins', 'admin-uid-1'), { role: 'superadmin' })
      );

      // 14. Public product queries must conform to published-product access rules
      await assertSucceeds(
        getDocs(query(collection(anonDb, 'products'), where('isPublished', '==', true)))
      );
      await assertFails(getDocs(collection(anonDb, 'products')));
    } finally {
      await testEnv.cleanup();
    }
  });
}
