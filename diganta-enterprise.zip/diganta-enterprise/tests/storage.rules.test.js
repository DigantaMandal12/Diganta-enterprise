/**
 * Firebase Cloud Storage Security Rules Test Suite (`tests/storage.rules.test.js`).
 *
 * Verifies all 9 required Storage Security Rules behaviours:
 * 1. Public product image reads work as designed.
 * 2. Non-admin users cannot upload product images.
 * 3. The administrator can upload valid images.
 * 4. Uploads over the 5 MiB size limit are denied.
 * 5. Disallowed file types are denied.
 * 6. Non-admin users cannot read private repair photos.
 * 7. Non-admin users cannot upload private repair photos.
 * 8. The administrator can access private repair photos through authenticated Storage requests.
 * 9. Unrecognised Storage paths are denied.
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const storageRulesPath = path.resolve(__dirname, '../storage.rules');
const storageRulesContent = fs.readFileSync(storageRulesPath, 'utf8');

const isStorageEmulatorRunning = Boolean(
  process.env.FIREBASE_STORAGE_EMULATOR_HOST && process.env.FIRESTORE_EMULATOR_HOST
);

test('Storage Rules Policy Verification — Static Rule Structure & Cross-Service Invariants', () => {
  assert.ok(storageRulesContent.includes("rules_version = '2';"), 'Must use rules_version 2');
  assert.ok(
    storageRulesContent.includes('firestore.exists(/databases/(default)/documents/admins/$(request.auth.uid))'),
    'Must verify admin UID in Firestore admins allowlist'
  );
  assert.ok(
    storageRulesContent.includes('firestore.get(/databases/(default)/documents/admins/$(request.auth.uid)).data.role == "admin"'),
    'Must verify admin role == "admin" via firestore.get()'
  );
  assert.ok(
    storageRulesContent.includes('request.resource.size <= 5 * 1024 * 1024'),
    'Must enforce 5 MiB upload size cap'
  );
  assert.ok(
    storageRulesContent.includes("request.resource.contentType.matches('image/(jpeg|png|webp)')"),
    'Must restrict uploads to JPEG, PNG, or WebP'
  );
  assert.ok(
    storageRulesContent.includes('match /products/{productId}/{fileName}') &&
      storageRulesContent.includes('allow read: if true;'),
    'Must allow public reads for product photos'
  );
  assert.ok(
    storageRulesContent.includes('match /repairs/{repairId}/{fileName}') &&
      storageRulesContent.includes('allow read: if isAdmin();'),
    'Must restrict repair photo reads strictly to isAdmin()'
  );
});

if (isStorageEmulatorRunning) {
  test('Storage Emulator Live Security Rules Suite (9 Scenarios)', async () => {
    const {
      initializeTestEnvironment,
      assertSucceeds,
      assertFails
    } = await import('@firebase/rules-unit-testing');
    const { doc, setDoc } = await import('firebase/firestore');
    const { ref, uploadBytes, getBytes } = await import('firebase/storage');

    const firestoreRulesContent = fs.readFileSync(
      path.resolve(__dirname, '../firestore.rules'),
      'utf8'
    );

    const testEnv = await initializeTestEnvironment({
      projectId: 'diganta-enterprise-test',
      firestore: {
        rules: firestoreRulesContent
      },
      storage: {
        rules: storageRulesContent
      }
    });

    try {
      await testEnv.withSecurityRulesDisabled(async (context) => {
        await setDoc(doc(context.firestore(), 'admins', 'admin-uid-1'), {
          role: 'admin'
        });
      });

      const anonStorage = testEnv.unauthenticatedContext().storage();
      const nonAdminStorage = testEnv.authenticatedContext('user-uid-2').storage();
      const adminStorage = testEnv.authenticatedContext('admin-uid-1').storage();

      const validImageBytes = new Uint8Array([0xff, 0xd8, 0xff, 0xe0]);

      // 2. Non-admin users cannot upload product images
      await assertFails(
        uploadBytes(ref(anonStorage, 'products/p1/photo.jpg'), validImageBytes, {
          contentType: 'image/jpeg'
        })
      );
      await assertFails(
        uploadBytes(ref(nonAdminStorage, 'products/p1/photo.jpg'), validImageBytes, {
          contentType: 'image/jpeg'
        })
      );

      // 3. Administrator can upload valid product images
      await assertSucceeds(
        uploadBytes(ref(adminStorage, 'products/p1/photo.jpg'), validImageBytes, {
          contentType: 'image/jpeg'
        })
      );

      // 1. Public product image reads work as designed
      await assertSucceeds(getBytes(ref(anonStorage, 'products/p1/photo.jpg')));

      // 4. Uploads over 5 MiB limit are denied
      const oversizedBytes = new Uint8Array(5 * 1024 * 1024 + 1024);
      await assertFails(
        uploadBytes(ref(adminStorage, 'products/p1/huge.jpg'), oversizedBytes, {
          contentType: 'image/jpeg'
        })
      );

      // 5. Disallowed file types are denied
      await assertFails(
        uploadBytes(ref(adminStorage, 'products/p1/script.sh'), validImageBytes, {
          contentType: 'application/x-sh'
        })
      );

      // 7. Non-admin users cannot upload private repair photos
      await assertFails(
        uploadBytes(ref(nonAdminStorage, 'repairs/r1/board.jpg'), validImageBytes, {
          contentType: 'image/jpeg'
        })
      );

      // 8. Administrator can upload and read private repair photos
      await assertSucceeds(
        uploadBytes(ref(adminStorage, 'repairs/r1/board.jpg'), validImageBytes, {
          contentType: 'image/jpeg'
        })
      );
      await assertSucceeds(getBytes(ref(adminStorage, 'repairs/r1/board.jpg')));

      // 6. Non-admin users cannot read private repair photos
      await assertFails(getBytes(ref(anonStorage, 'repairs/r1/board.jpg')));
      await assertFails(getBytes(ref(nonAdminStorage, 'repairs/r1/board.jpg')));

      // 9. Unrecognised Storage paths are denied
      await assertFails(
        uploadBytes(ref(adminStorage, 'misc/random.jpg'), validImageBytes, {
          contentType: 'image/jpeg'
        })
      );
    } finally {
      await testEnv.cleanup();
    }
  });
}
