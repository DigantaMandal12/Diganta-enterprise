import test from 'node:test';
import assert from 'node:assert/strict';

import {
  rupeesToPaise,
  paiseToRupeesInput,
  formatPaiseToINR,
  calculatePartsTotalPaise,
  calculateDirectRepairCost,
  calculateRepairPaymentSummary,
  calculateRepairFinancials,
  calculateBusinessSummary
} from '../src/utils/currency.js';

import {
  validateAndNormalizePhone,
  validateProductEnquiryForm,
  validateProductForm,
  validateRepairForm,
  validatePaymentForm,
  validateExpenseForm
} from '../src/utils/validation.js';

import { buildEnquiryWhatsAppUrl } from '../src/utils/whatsapp.js';

test('1. Money conversion between rupees and integer paise avoids floating-point errors', () => {
  assert.equal(rupeesToPaise('100'), 10000);
  assert.equal(rupeesToPaise(125.5), 12550);
  assert.equal(rupeesToPaise('19.99'), 1999);
  assert.equal(rupeesToPaise('0', { allowZero: true }), 0);
  assert.equal(rupeesToPaise('', { allowNull: true }), null);

  assert.equal(paiseToRupeesInput(10000), '100');
  assert.equal(paiseToRupeesInput(12550), '125.50');
  assert.ok(formatPaiseToINR(12550).includes('125.50'));

  // Reject negative and malformed prices
  assert.throws(() => rupeesToPaise('-50'), /negative/i);
  assert.throws(() => rupeesToPaise('12.345'), /2 decimal places/i);
  assert.throws(() => rupeesToPaise('abc'), /valid INR amount/i);
  assert.throws(() => rupeesToPaise('0', { allowZero: false }), /greater than zero/i);
});

test('2. Empty parts lists and repairs with no recorded expenses', () => {
  assert.equal(calculatePartsTotalPaise([]), 0);

  const emptyRepairCost = calculateDirectRepairCost({
    partsUsed: [],
    labourAllocationPaise: 0,
    travelExpensePaise: 0,
    otherDirectExpensesPaise: 0
  });

  assert.equal(emptyRepairCost.partsCostPaise, 0);
  assert.equal(emptyRepairCost.totalCostPaise, 0);
});

test('3. Multiple parts and direct repair cost components', () => {
  const parts = [
    { partName: '9V Transformer', quantity: 1, unitCostPaise: 18500 },
    { partName: 'Display LED Segment', quantity: 2, unitCostPaise: 6550 },
    { partName: 'Tactile Switch', quantity: 4, unitCostPaise: 1000 }
  ];
  // 18500 + 13100 + 4000 = 35600 paise (₹356.00)
  assert.equal(calculatePartsTotalPaise(parts), 35600);

  const cost = calculateDirectRepairCost({
    partsUsed: parts,
    labourAllocationPaise: 15000,
    travelExpensePaise: 5000,
    otherDirectExpensesPaise: 2000
  });

  assert.equal(cost.partsCostPaise, 35600);
  assert.equal(cost.labourAllocationPaise, 15000);
  assert.equal(cost.travelExpensePaise, 5000);
  assert.equal(cost.otherDirectExpensesPaise, 2000);
  assert.equal(cost.totalCostPaise, 57600);
});

test('4. Unpaid repairs — Completed or Delivered status never marks a repair Paid', () => {
  const repair = {
    status: 'Delivered',
    quotedAmountPaise: 65000,
    finalAmountChargedPaise: 70000,
    partsUsed: [{ partName: 'Load cell cable', quantity: 1, unitCostPaise: 12000 }],
    labourAllocationPaise: 10000,
    travelExpensePaise: 0,
    otherDirectExpensesPaise: 0
  };

  const fin = calculateRepairFinancials(repair, []);
  assert.equal(fin.netCollectedPaise, 0);
  assert.equal(fin.outstandingBalancePaise, 70000);
  assert.equal(fin.paymentStatus, 'Unpaid');
  // Estimated collection profit is negative (-22000 paise) until payment is collected
  assert.equal(fin.estimatedCollectionProfitPaise, -22000);
  // Billed margin is +48000 paise
  assert.equal(fin.billedMarginPaise, 48000);
});

test('5. Partial payment calculation', () => {
  const repair = {
    status: 'Repairing',
    finalAmountChargedPaise: 80000,
    partsUsed: [{ partName: 'Main PCB', quantity: 1, unitCostPaise: 30000 }],
    labourAllocationPaise: 10000,
    travelExpensePaise: 0,
    otherDirectExpensesPaise: 0
  };
  const payments = [
    { type: 'received', amountPaise: 30000, paymentDate: '2026-10-10', paymentMethod: 'Cash' }
  ];

  const fin = calculateRepairFinancials(repair, payments);
  assert.equal(fin.netCollectedPaise, 30000);
  assert.equal(fin.outstandingBalancePaise, 50000);
  assert.equal(fin.overpaymentCreditPaise, 0);
  assert.equal(fin.paymentStatus, 'Partially Paid');
  assert.equal(fin.estimatedCollectionProfitPaise, -10000);
});

test('6. Full payment calculation', () => {
  const repair = {
    status: 'Completed',
    finalAmountChargedPaise: 80000,
    partsUsed: [{ partName: 'Main PCB', quantity: 1, unitCostPaise: 30000 }],
    labourAllocationPaise: 10000,
    travelExpensePaise: 5000,
    otherDirectExpensesPaise: 0
  };
  const payments = [
    { type: 'received', amountPaise: 30000, paymentDate: '2026-10-10', paymentMethod: 'Cash' },
    { type: 'received', amountPaise: 50000, paymentDate: '2026-10-12', paymentMethod: 'UPI' }
  ];

  const fin = calculateRepairFinancials(repair, payments);
  assert.equal(fin.netCollectedPaise, 80000);
  assert.equal(fin.outstandingBalancePaise, 0);
  assert.equal(fin.overpaymentCreditPaise, 0);
  assert.equal(fin.paymentStatus, 'Paid');
  assert.equal(fin.totalCostPaise, 45000);
  assert.equal(fin.estimatedCollectionProfitPaise, 35000);
});

test('7. Refunds reduce net collections and update balance accurately', () => {
  const repair = {
    status: 'Delivered',
    finalAmountChargedPaise: 50000,
    partsUsed: [],
    labourAllocationPaise: 15000,
    travelExpensePaise: 0,
    otherDirectExpensesPaise: 0
  };
  const payments = [
    { type: 'received', amountPaise: 60000, paymentDate: '2026-10-05', paymentMethod: 'UPI' },
    { type: 'refund', amountPaise: 10000, paymentDate: '2026-10-06', paymentMethod: 'Cash' }
  ];

  const fin = calculateRepairFinancials(repair, payments);
  assert.equal(fin.totalReceivedPaise, 60000);
  assert.equal(fin.totalRefundedPaise, 10000);
  assert.equal(fin.netCollectedPaise, 50000);
  assert.equal(fin.outstandingBalancePaise, 0);
  assert.equal(fin.paymentStatus, 'Paid');
  assert.equal(fin.estimatedCollectionProfitPaise, 35000);
});

test('8. Overpayments show customer credit rather than negative outstanding debt', () => {
  const repair = {
    status: 'Completed',
    finalAmountChargedPaise: 45000,
    partsUsed: [],
    labourAllocationPaise: 10000,
    travelExpensePaise: 0,
    otherDirectExpensesPaise: 0
  };
  const payments = [
    { type: 'received', amountPaise: 50000, paymentDate: '2026-10-15', paymentMethod: 'Cash' }
  ];

  const fin = calculateRepairFinancials(repair, payments);
  assert.equal(fin.netCollectedPaise, 50000);
  assert.equal(fin.outstandingBalancePaise, 0);
  assert.equal(fin.overpaymentCreditPaise, 5000);
  assert.equal(fin.paymentStatus, 'Overpaid / Customer Credit');
});

test('9. Missing quotations and missing final charges — quotes never count as collections', () => {
  const unbilledRepair = {
    status: 'Diagnosing',
    quotedAmountPaise: 55000,
    finalAmountChargedPaise: null,
    partsUsed: [],
    labourAllocationPaise: 0,
    travelExpensePaise: 0,
    otherDirectExpensesPaise: 0
  };

  const summaryNoPayments = calculateRepairPaymentSummary(unbilledRepair, []);
  assert.equal(summaryNoPayments.netCollectedPaise, 0);
  assert.equal(summaryNoPayments.outstandingBalancePaise, 0);
  assert.equal(summaryNoPayments.paymentStatus, 'Not Yet Charged');

  const summaryWithAdvance = calculateRepairPaymentSummary(unbilledRepair, [
    { type: 'received', amountPaise: 20000, paymentDate: '2026-10-18', paymentMethod: 'Cash' }
  ]);
  assert.equal(summaryWithAdvance.netCollectedPaise, 20000);
  assert.equal(summaryWithAdvance.paymentStatus, 'Advance Collected (Final Charge Pending)');
});

test('10. Zero-valued expenses and general business summary without double-counting', () => {
  const repairs = [
    {
      id: 'rep-1',
      repairDate: '2026-10-05',
      status: 'Delivered',
      finalAmountChargedPaise: 90000,
      partsUsed: [{ partName: 'Transformer', quantity: 1, unitCostPaise: 20000 }],
      labourAllocationPaise: 10000,
      travelExpensePaise: 5000,
      otherDirectExpensesPaise: 0
    },
    {
      id: 'rep-2',
      repairDate: '2026-10-12',
      status: 'Repairing',
      finalAmountChargedPaise: 50000,
      partsUsed: [],
      labourAllocationPaise: 10000,
      travelExpensePaise: 0,
      otherDirectExpensesPaise: 0
    }
  ];

  const paymentsByRepairId = {
    'rep-1': [
      { type: 'received', amountPaise: 90000, paymentDate: '2026-10-06', paymentMethod: 'UPI' }
    ],
    'rep-2': [
      { type: 'received', amountPaise: 20000, paymentDate: '2026-10-12', paymentMethod: 'Cash' }
    ]
  };

  const expenses = [
    { id: 'exp-1', date: '2026-10-08', category: 'Utilities', description: 'Electricity', amountPaise: 15000 },
    { id: 'exp-2', date: '2026-10-09', category: 'Workshop supplies', description: 'Zero cost sample', amountPaise: 0 }
  ];

  const business = calculateBusinessSummary({
    repairs,
    paymentsByRepairId,
    expenses
  });

  assert.equal(business.totalRepairsCount, 2);
  assert.equal(business.completedRepairsCount, 1);
  assert.equal(business.pendingRepairsCount, 1);
  assert.equal(business.totalChargedPaise, 140000);
  assert.equal(business.netCustomerCollectionsPaise, 110000);
  assert.equal(business.totalOutstandingBalancePaise, 30000);
  // Direct repair costs: (20000 + 10000 + 5000) + 10000 = 45000
  assert.equal(business.totalDirectRepairCostPaise, 45000);
  // General expenses: 15000 + 0 = 15000
  assert.equal(business.totalGeneralExpensesPaise, 15000);
  // Estimated repair profit: 110000 - 45000 = 65000
  assert.equal(business.estimatedRepairProfitPaise, 65000);
  // Estimated business result: 110000 - 45000 - 15000 = 50000
  assert.equal(business.estimatedBusinessResultPaise, 50000);
});

test('11. Validation rejects invalid quantities, negative costs, invalid dates, and malformed inputs', () => {
  // Phone normalisation accepts spaces, parentheses, and +91
  const phoneValid = validateAndNormalizePhone('+91 (93302) 50245');
  assert.equal(phoneValid.isValid, true);
  assert.equal(phoneValid.normalized, '+91 93302 50245');

  const phoneInvalid = validateAndNormalizePhone('12345');
  assert.equal(phoneInvalid.isValid, false);

  // Enquiry validation
  const badEnquiry = validateProductEnquiryForm(
    { customerName: 'A', phone: '123', quantity: 0, preferredContactMethod: 'Invalid' },
    { id: 'p1', isPublished: false }
  );
  assert.equal(badEnquiry.isValid, false);
  assert.ok(badEnquiry.errors.product);
  assert.ok(badEnquiry.errors.customerName);
  assert.ok(badEnquiry.errors.phone);
  assert.ok(badEnquiry.errors.quantity);

  // Product validation
  const badProduct = validateProductForm({
    name: '',
    scaleType: '',
    pricingMode: 'fixed',
    displayPriceRupees: '-100',
    availabilityStatus: 'invalid',
    isPublished: true
  });
  assert.equal(badProduct.isValid, false);
  assert.ok(badProduct.errors.name);
  assert.ok(badProduct.errors.displayPriceRupees);

  // Payment validation
  const badPayment = validatePaymentForm({
    paymentDate: '2026-02-31',
    type: 'invalid',
    amountRupees: '0',
    paymentMethod: 'Crypto'
  });
  assert.equal(badPayment.isValid, false);
  assert.ok(badPayment.errors.paymentDate);
  assert.ok(badPayment.errors.type);
  assert.ok(badPayment.errors.amountRupees);
  assert.ok(badPayment.errors.paymentMethod);

  // Expense validation
  const badExpense = validateExpenseForm({
    date: 'not-a-date',
    category: 'Unknown',
    description: 'X',
    amountRupees: '-10'
  });
  assert.equal(badExpense.isValid, false);
});

test('12. WhatsApp enquiry message builder includes reference and never claims confirmed order', () => {
  const url = buildEnquiryWhatsAppUrl({
    enquiryId: 'ENQ-998877',
    productName: 'Vison Tech 100 kg Platform Scale',
    productBrand: 'Vison Tech',
    productModel: 'VT-100P',
    productSpecifications: 'Type: Platform Scale | Max Capacity: 100 kg',
    quantity: 2,
    customerName: 'Ramesh Das',
    phone: '+91 98765 43210',
    preferredContactMethod: 'WhatsApp',
    requiredCapacity: '100 kg',
    requiredReadability: '10 g',
    additionalRequirements: 'Need SS platter'
  });

  assert.ok(url.startsWith('https://wa.me/919330250245?text='));
  const decoded = decodeURIComponent(url.split('?text=')[1]);
  assert.ok(decoded.includes('ENQ-998877'));
  assert.ok(decoded.includes('Vison Tech 100 kg Platform Scale'));
  assert.ok(!decoded.toLowerCase().includes('confirmed order'));
});
