# Security Architecture & Policy — Diganta Enterprise

This document describes the security architecture, access-control rules, privacy boundaries, and operational safeguards implemented for **Diganta Enterprise — Weighing Scale Repair & Sales**.

## 1. Threat Model & Core Principles

1. **Frontend Code Is Public**: Browser JavaScript, React Router route guards (`ProtectedRoute.jsx`), and Vite `VITE_FIREBASE_*` environment variables identify the Firebase project to the browser. They are **never** relied upon as an access-control boundary.
2. **Backend Enforcement via Firebase Security Rules**: All authorisation and schema validation is enforced independently by [Cloud Firestore Security Rules](https://firebase.google.com/docs/firestore/security/get-started) (`firestore.rules`) and [Cloud Storage Security Rules](https://firebase.google.com/docs/storage/security) (`storage.rules`).
3. **Zero Privileged Secrets in the Repository**: Neither the frontend nor the repository contains Firebase Admin SDK credentials, service-account JSON keys, or private server tokens.

## 2. Single-Administrator Allowlist (`admins/{uid}`)

- **Authentication vs. Authorisation**: Signing in via [Firebase Authentication](https://firebase.google.com/docs/auth) (email/password) only proves identity (`request.auth.uid`). It does **not** grant administrator privileges.
- **Allowlist Collection**: A user is recognised as the authorised administrator if and only if a document exists at `admins/{request.auth.uid}` in Cloud Firestore with `role == "admin"`.
- **Rule Helper (`firestore.rules`)**:
  ```javascript
  function isAdmin() {
    return request.auth != null
      && exists(/databases/$(database)/documents/admins/$(request.auth.uid))
      && get(/databases/$(database)/documents/admins/$(request.auth.uid)).data.role == "admin";
  }
  ```
- **Cross-Service Rule Helper (`storage.rules`)**:
  Using [Cloud Storage cross-service rules conditions](https://firebase.google.com/docs/storage/security/rules-conditions):
  ```javascript
  function isAdmin() {
    return request.auth != null
      && firestore.exists(/databases/(default)/documents/admins/$(request.auth.uid))
      && firestore.get(/databases/(default)/documents/admins/$(request.auth.uid)).data.role == "admin";
  }
  ```
- **Immutable from Clients**: `allow create, update, delete: if false;` and `allow list: if false;` are enforced on `admins/{adminUid}`. An authenticated user can only `get` their own `admins/{request.auth.uid}` document to verify their own role. No user can promote themselves or enumerate administrators from the browser.

## 3. Collection-by-Collection Firestore Authorisation Policy

| Collection Path | Public / Anonymous Users | Authenticated Non-Admin Users | Authorised Administrator (`isAdmin()`) |
| :--- | :--- | :--- | :--- |
| `admins/{adminUid}` | Denied (`read`, `write`) | `get` own UID doc only; `list` and `write` denied | `get` own UID doc only; client `write` denied (Console-provisioned) |
| `products/{productId}` | `get`, `list` **only** when `resource.data.isPublished == true` | `get`, `list` **only** when `resource.data.isPublished == true` | Full `get`, `list`, `create`, `update`, `delete` (validated schema) |
| `enquiries/{enquiryId}` | `create` **only** (strictly validated; cannot `get` or `list`) | `create` only (`read`, `update`, `delete` denied) | Full `get`, `list`, `update`, `delete` |
| `repairs/{repairId}` | Denied (`read`, `write`) | Denied (`read`, `write`) | Full `get`, `list`, `create`, `update`, `delete` |
| `repairs/{repairId}/payments/{paymentId}` | Denied (`read`, `write`) | Denied (`read`, `write`) | Full `get`, `list`, `create`, `update`, `delete` (requires parent repair to exist) |
| `expenses/{expenseId}` | Denied (`read`, `write`) | Denied (`read`, `write`) | Full `get`, `list`, `create`, `update`, `delete` |
| `/{document=**}` (All other paths) | Denied (`read`, `write`) | Denied (`read`, `write`) | Denied (`read`, `write`) |

### Important Note on Firestore Rules and Queries
As documented in [Writing conditions for Cloud Firestore Security Rules](https://firebase.google.com/docs/firestore/security/rules-conditions), **security rules are not filters**. Every public query against `products` in `src/services/productService.js` explicitly includes `where('isPublished', '==', true)`. Unfiltered public queries against `products` are rejected by Firestore Rules.

### Public Enquiry Creation Validation (`isValidPublicEnquiryCreate`)
When a customer submits a product enquiry:
1. Only allowed fields may be submitted (`hasOnly` and `hasAll` checks).
2. `customerName` (2–120 chars), `phone` (10–20 chars matching valid phone pattern), `preferredContactMethod` (`WhatsApp`, `Phone Call`, or `Either`), and integer `quantity` (1–1,000) are validated.
3. `status` **must** equal `'New'`.
4. Privileged administrator fields (`quotedPricePaise` and `notes`) must be `null` or empty.
5. `createdAt == request.time` and `updatedAt == request.time` enforce server timestamps.
6. The referenced `products/$(data.productId)` document must exist in Firestore, have `isPublished == true`, and its `name` must match `data.productNameSnapshot`.

## 4. Cloud Storage Privacy & Access Policy

| Storage Object Path | Public Read | Admin Read | Admin Write / Delete | Constraints |
| :--- | :--- | :--- | :--- | :--- |
| `products/{productId}/{fileName}` | Allowed (`allow read: if true`) | Allowed | Allowed (`isAdmin()`) | Max `5 MiB`, MIME `image/jpeg`, `image/png`, or `image/webp` |
| `repairs/{repairId}/{fileName}` | **Denied** | Allowed (`isAdmin()`) | Allowed (`isAdmin()`) | Max `5 MiB`, MIME `image/jpeg`, `image/png`, or `image/webp` |
| `/{allPaths=**}` | **Denied** | **Denied** | **Denied** | Default deny |

### Private Repair Photograph Handling
- Repair photographs may show customer equipment, serial numbers, or workshop notes.
- They are stored under `repairs/{repairId}/{uniqueFileName}` and are **never** converted into public download URLs (`getDownloadURL` is never called for repair photos).
- Instead, `src/services/storageService.js` uses authenticated `getBlob()` requests governed by Storage Security Rules and creates temporary browser `blob:` URLs via `URL.createObjectURL()`, which `src/hooks/usePrivateStorageImage.js` revokes immediately when the component unmounts or the image changes.

## 5. Abuse Protection & Firebase App Check

1. **Client & Rule Validation**: Every form validates inputs before submission and is backed by server-side Firestore/Storage rule constraints.
2. **Honeypot Trap**: `ProductEnquiryPage.jsx` includes an off-screen honeypot field (`companyWebsiteHoneypot`) and submission-in-progress lock (`isSubmitting`) to prevent accidental double-clicks and basic automated spam bots.
3. **Firebase App Check**: `src/services/firebase.js` initialises [Firebase App Check with reCAPTCHA v3](https://firebase.google.com/docs/app-check/web/recaptcha-provider) when `VITE_FIREBASE_APPCHECK_SITE_KEY` is provided.
   - **Limitation Disclosure**: Neither a honeypot nor App Check guarantees hard per-IP rate limiting against determined abuse. If high-volume spam ever targets the public enquiry collection, the recommended V2 upgrade is a single Cloud Function callable endpoint with IP/token rate limiting.
