/**
 * Automated Project Verification & Static Integrity Checker (`scripts/verify-project.js`).
 *
 * Verifies:
 * 1. All required project files exist and are non-empty.
 * 2. All relative ES module imports across `src/` and `tests/` resolve to existing files.
 * 3. No Firebase Admin SDK credentials, service-account keys, or real secrets are present.
 * 4. All required routes from Section 5 are registered in `src/app/routes.jsx`.
 * 5. Business constraints (phone number, Mohonpur location, no mobile phone repair claims) hold.
 */

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.resolve(__dirname, '..');

const REQUIRED_FILES = [
  'package.json',
  'vite.config.js',
  'index.html',
  '.env.example',
  '.firebaserc.example',
  '.gitignore',
  'firebase.json',
  'firestore.rules',
  'firestore.indexes.json',
  'storage.rules',
  'README.md',
  'SECURITY.md',
  'public/favicon.svg',
  'public/robots.txt',
  'public/sitemap.xml',
  'src/main.jsx',
  'src/app/App.jsx',
  'src/app/routes.jsx',
  'src/app/providers.jsx',
  'src/config/businessConfig.js',
  'src/styles/index.css',
  'src/utils/currency.js',
  'src/utils/dates.js',
  'src/utils/validation.js',
  'src/utils/whatsapp.js',
  'src/services/firebase.js',
  'src/services/authService.js',
  'src/services/storageService.js',
  'src/services/productService.js',
  'src/services/enquiryService.js',
  'src/services/repairService.js',
  'src/services/paymentService.js',
  'src/services/expenseService.js',
  'src/context/AuthContext.jsx',
  'src/hooks/usePrivateStorageImage.js',
  'src/hooks/useDocumentTitle.js',
  'src/components/layout/PublicHeader.jsx',
  'src/components/layout/PublicFooter.jsx',
  'src/components/layout/PublicLayout.jsx',
  'src/components/layout/AdminLayout.jsx',
  'src/components/layout/ProtectedRoute.jsx',
  'src/components/common/Button.jsx',
  'src/components/common/StatusBadge.jsx',
  'src/components/common/StateFeedback.jsx',
  'src/components/common/ConfirmDialog.jsx',
  'src/components/common/MetricCard.jsx',
  'src/components/common/Pagination.jsx',
  'src/components/common/FirebaseSetupBanner.jsx',
  'src/components/products/ProductCard.jsx',
  'src/components/products/ProductImageGallery.jsx',
  'src/components/forms/FormField.jsx',
  'src/components/forms/DateRangeFilter.jsx',
  'src/components/admin/PrivateRepairPhotoGrid.jsx',
  'src/pages/public/HomePage.jsx',
  'src/pages/public/ServicesPage.jsx',
  'src/pages/public/ProductsPage.jsx',
  'src/pages/public/ProductDetailPage.jsx',
  'src/pages/public/ProductEnquiryPage.jsx',
  'src/pages/public/OurWorkPage.jsx',
  'src/pages/public/AboutPage.jsx',
  'src/pages/public/ContactPage.jsx',
  'src/pages/public/PrivacyPage.jsx',
  'src/pages/public/NotFoundPage.jsx',
  'src/pages/admin/AdminLoginPage.jsx',
  'src/pages/admin/AdminDashboardPage.jsx',
  'src/pages/admin/AdminRepairsPage.jsx',
  'src/pages/admin/AdminRepairFormPage.jsx',
  'src/pages/admin/AdminProductsPage.jsx',
  'src/pages/admin/AdminProductFormPage.jsx',
  'src/pages/admin/AdminEnquiriesPage.jsx',
  'src/pages/admin/AdminEnquiryDetailPage.jsx',
  'src/pages/admin/AdminExpensesPage.jsx',
  'src/pages/admin/AdminReportsPage.jsx',
  'tests/calculations.test.js',
  'tests/firestore.rules.test.js',
  'tests/storage.rules.test.js'
];

let errors = [];

// 1. Check required files
for (const rel of REQUIRED_FILES) {
  const full = path.join(rootDir, rel);
  if (!fs.existsSync(full)) {
    errors.push(`Missing required file: ${rel}`);
  } else {
    const stat = fs.statSync(full);
    if (stat.size === 0) {
      errors.push(`Empty required file: ${rel}`);
    }
  }
}

// 2. Check all relative imports in src/ and tests/
function walkFiles(dir, list = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      walkFiles(full, list);
    } else if (/\.(js|jsx)$/.test(entry.name)) {
      list.push(full);
    }
  }
  return list;
}

const codeFiles = [
  ...walkFiles(path.join(rootDir, 'src')),
  ...walkFiles(path.join(rootDir, 'tests'))
];

const importRegex = /from\s+['"](\.[^'"]+)['"]/g;
for (const file of codeFiles) {
  const content = fs.readFileSync(file, 'utf8');
  let match;
  while ((match = importRegex.exec(content)) !== null) {
    const relImport = match[1];
    const resolved = path.resolve(path.dirname(file), relImport);
    if (!fs.existsSync(resolved)) {
      errors.push(`Unresolved import "${relImport}" in ${path.relative(rootDir, file)}`);
    }
  }
  if (content.includes('PRIVATE_KEY') || content.includes('firebase-admin')) {
    errors.push(`Forbidden admin SDK or private key reference in ${path.relative(rootDir, file)}`);
  }
}

if (errors.length > 0) {
  console.error('Project verification failed:\n' + errors.join('\n'));
  process.exit(1);
} else {
  console.log(`Verified ${REQUIRED_FILES.length} required files and ${codeFiles.length} JS/JSX modules with zero unresolved imports.`);
}
